	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
	.protected	_Z15lds_read_kernelPjjj ; -- Begin function _Z15lds_read_kernelPjjj
	.globl	_Z15lds_read_kernelPjjj
	.p2align	8
	.type	_Z15lds_read_kernelPjjj,@function
_Z15lds_read_kernelPjjj:                ; @_Z15lds_read_kernelPjjj
; %bb.0:
	s_mov_b64 s[2:3], src_shared_base
	v_or_b32_e32 v1, 0xffffff00, v0
	v_lshlrev_b32_e32 v2, 2, v0
	s_mov_b64 s[0:1], 0
	s_movk_i32 s2, 0x1fff
.LBB0_1:                                ; =>This Inner Loop Header: Depth=1
	v_add_u32_e32 v5, 0x101, v1
	v_mov_b32_e32 v3, s3
	v_add_u32_e32 v1, 0x100, v1
	v_cmp_ne_u32_e32 vcc, -1, v2
	v_cndmask_b32_e32 v4, 0, v3, vcc
	v_cndmask_b32_e32 v3, 0, v2, vcc
	v_cmp_lt_u32_e32 vcc, s2, v1
	v_add_u32_e32 v2, 0x400, v2
	s_or_b64 s[0:1], vcc, s[0:1]
	flat_store_dword v[3:4], v5
	s_waitcnt vmcnt(0)
	s_andn2_b64 exec, exec, s[0:1]
	s_cbranch_execnz .LBB0_1
; %bb.2:
	s_or_b64 exec, exec, s[0:1]
	s_load_dwordx2 s[0:1], s[4:5], 0x8
	v_lshrrev_b32_e32 v2, 5, v0
	v_and_b32_e32 v1, 31, v0
	v_mul_u32_u24_e32 v2, 0x420, v2
	s_mov_b64 s[2:3], 0
	s_waitcnt lgkmcnt(0)
	s_cmp_lt_i32 s0, 7
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_waitcnt lgkmcnt(0)
	s_cbranch_scc1 .LBB0_5
; %bb.3:                                ; %LeafBlock31
	s_cmp_eq_u32 s0, 7
	s_cbranch_scc0 .LBB0_6
; %bb.4:
	v_lshl_add_u32 v3, v1, 5, v2
	v_or_b32_e32 v3, v3, v1
	v_xor_b32_e32 v3, 7, v3
	s_mov_b64 s[8:9], 0
	s_branch .LBB0_7
.LBB0_5:
                                        ; implicit-def: $vgpr3
	s_mov_b64 s[8:9], 0
	s_cbranch_execnz .LBB0_8
	s_branch .LBB0_9
.LBB0_6:
	s_mov_b64 s[8:9], -1
                                        ; implicit-def: $vgpr3
.LBB0_7:                                ; %Flow33
	s_branch .LBB0_9
.LBB0_8:                                ; %LeafBlock
	s_cmp_lg_u32 s0, 6
	s_mov_b64 s[2:3], -1
	s_cselect_b64 s[8:9], -1, 0
                                        ; implicit-def: $vgpr3
.LBB0_9:                                ; %Flow34
	s_andn2_b64 vcc, exec, s[8:9]
	s_cbranch_vccz .LBB0_15
; %bb.10:                               ; %Flow35
	s_andn2_b64 vcc, exec, s[2:3]
	s_cbranch_vccnz .LBB0_12
.LBB0_11:
	v_mul_u32_u24_e32 v1, 33, v1
	v_add3_u32 v3, v1, v2, 7
.LBB0_12:                               ; %_Z10lds_offsetjjj.exit
	v_lshlrev_b32_e32 v1, 2, v3
	s_mov_b64 s[0:1], src_shared_base
	v_cmp_ne_u32_e32 vcc, -1, v1
	v_mov_b32_e32 v2, s1
	v_mov_b32_e32 v3, 0
	v_cndmask_b32_e32 v1, 0, v1, vcc
	v_cndmask_b32_e32 v2, 0, v2, vcc
	s_movk_i32 s0, 0x800
.LBB0_13:                               ; =>This Inner Loop Header: Depth=1
	flat_load_dword v4, v[1:2] glc
	s_waitcnt vmcnt(0)
	flat_load_dword v5, v[1:2] glc
	s_waitcnt vmcnt(0)
	flat_load_dword v6, v[1:2] glc
	s_waitcnt vmcnt(0)
	flat_load_dword v7, v[1:2] glc
	s_waitcnt vmcnt(0)
	s_add_i32 s0, s0, -4
	s_cmp_eq_u32 s0, 0
	s_waitcnt lgkmcnt(0)
	v_add3_u32 v3, v4, v3, v5
	v_add3_u32 v3, v3, v6, v7
	s_cbranch_scc0 .LBB0_13
; %bb.14:
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_lshl_or_b32 v0, s6, 8, v0
	v_mov_b32_e32 v1, 0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v2, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_store_dword v[0:1], v3, off
	s_endpgm
.LBB0_15:
	v_cvt_f32_u32_e32 v3, s1
	s_sub_i32 s0, 0, s1
	v_cvt_f32_ubyte0_e32 v5, v1
	v_rcp_iflag_f32_e32 v3, v3
	v_mul_f32_e32 v3, 0x4f7ffffe, v3
	v_cvt_u32_f32_e32 v3, v3
	v_readfirstlane_b32 s2, v3
	s_mul_i32 s0, s0, s2
	s_mul_hi_u32 s0, s2, s0
	s_add_i32 s2, s2, s0
	s_lshr_b32 s0, s2, 27
	s_mul_i32 s2, s0, s1
	s_sub_i32 s2, 32, s2
	s_add_i32 s3, s0, 1
	s_sub_i32 s7, s2, s1
	s_cmp_ge_u32 s2, s1
	s_cselect_b32 s0, s3, s0
	s_cselect_b32 s2, s7, s2
	s_add_i32 s3, s0, 1
	s_cmp_ge_u32 s2, s1
	s_cselect_b32 s0, s3, s0
	v_cvt_f32_ubyte0_e32 v3, s0
	s_nop 0
	v_rcp_iflag_f32_e32 v4, v3
	v_mul_f32_e32 v4, v5, v4
	v_trunc_f32_e32 v4, v4
	v_cvt_u32_f32_e32 v6, v4
	v_mad_f32 v4, -v4, v3, v5
	v_cmp_ge_f32_e64 vcc, |v4|, v3
	v_addc_co_u32_e32 v3, vcc, 0, v6, vcc
	v_and_b32_e32 v4, 0xff, v3
	v_mul_lo_u16_e32 v3, s0, v3
	v_sub_u16_e32 v3, v1, v3
	v_add_u16_e32 v3, 7, v3
	v_lshl_add_u32 v4, v4, 5, v2
	v_and_b32_e32 v3, 31, v3
	v_or_b32_sdwa v3, v4, v3 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:DWORD src1_sel:WORD_0
	s_cbranch_execz .LBB0_11
	s_branch .LBB0_12
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z15lds_read_kernelPjjj
		.amdhsa_group_segment_fixed_size 33792
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 8
		.amdhsa_next_free_sgpr 10
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z15lds_read_kernelPjjj, .Lfunc_end0-_Z15lds_read_kernelPjjj
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 600
; NumSgprs: 14
; NumVgprs: 8
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 33792 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 14
; NumVGPRsForWavesPerEU: 8
; Occupancy: 1
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.ident	"clang version 17.0.0"
	.section	".note.GNU-stack"
	.addrsig
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .offset:         8
        .size:           4
        .value_kind:     by_value
      - .offset:         12
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 33792
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z15lds_read_kernelPjjj
    .private_segment_fixed_size: 0
    .sgpr_count:     14
    .sgpr_spill_count: 0
    .symbol:         _Z15lds_read_kernelPjjj.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     8
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
