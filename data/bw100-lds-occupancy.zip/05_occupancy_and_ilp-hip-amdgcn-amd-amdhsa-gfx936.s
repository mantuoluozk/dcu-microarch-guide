	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
	.protected	_Z16initialize_ringsPjjj ; -- Begin function _Z16initialize_ringsPjjj
	.globl	_Z16initialize_ringsPjjj
	.p2align	8
	.type	_Z16initialize_ringsPjjj,@function
_Z16initialize_ringsPjjj:               ; @_Z16initialize_ringsPjjj
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	s_load_dword s7, s[4:5], 0x1c
	s_waitcnt lgkmcnt(0)
	v_cvt_f32_u32_e32 v1, s2
	s_sub_i32 s4, 0, s2
	v_mov_b32_e32 v5, s1
	v_rcp_iflag_f32_e32 v1, v1
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	v_mul_lo_u32 v2, s4, v1
	s_and_b32 s4, s7, 0xffff
	s_mul_i32 s6, s6, s4
	v_add_u32_e32 v0, s6, v0
	v_mul_hi_u32 v2, v1, v2
	v_add_u32_e32 v1, v1, v2
	v_mul_hi_u32 v2, v0, v1
	v_mov_b32_e32 v1, 0
	v_mul_lo_u32 v3, v2, s2
	v_add_u32_e32 v4, 1, v2
	v_sub_u32_e32 v3, v0, v3
	v_cmp_le_u32_e32 vcc, s2, v3
	v_cndmask_b32_e32 v2, v2, v4, vcc
	v_subrev_u32_e32 v4, s2, v3
	v_cndmask_b32_e32 v3, v3, v4, vcc
	v_add_u32_e32 v4, 1, v2
	v_cmp_le_u32_e32 vcc, s2, v3
	v_cndmask_b32_e32 v3, v2, v4, vcc
	v_mul_lo_u32 v4, v3, s2
	v_lshlrev_b64 v[1:2], 2, v[0:1]
	v_add_u32_e32 v3, s3, v3
	v_and_b32_e32 v3, 63, v3
	v_sub_u32_e32 v0, v0, v4
	v_mad_u64_u32 v[3:4], s[2:3], v3, s2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v1
	v_addc_co_u32_e32 v1, vcc, v5, v2, vcc
	global_store_dword v[0:1], v3, off
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z16initialize_ringsPjjj
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 272
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 6
		.amdhsa_next_free_sgpr 8
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z16initialize_ringsPjjj, .Lfunc_end0-_Z16initialize_ringsPjjj
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 200
; NumSgprs: 12
; NumVgprs: 6
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 12
; NumVGPRsForWavesPerEU: 6
; Occupancy: 10
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.section	.text._Z11chase_ringsILj1EEvPKjPjj,#alloc,#execinstr
	.protected	_Z11chase_ringsILj1EEvPKjPjj ; -- Begin function _Z11chase_ringsILj1EEvPKjPjj
	.globl	_Z11chase_ringsILj1EEvPKjPjj
	.p2align	8
	.type	_Z11chase_ringsILj1EEvPKjPjj,@function
_Z11chase_ringsILj1EEvPKjPjj:           ; @_Z11chase_ringsILj1EEvPKjPjj
; %bb.0:                                ; %.critedge
	s_load_dword s3, s[4:5], 0x24
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	s_mov_b32 s2, 64
	v_mov_b32_e32 v1, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s3, s3, 0xffff
	s_mul_i32 s6, s6, s3
	v_add_u32_e32 v2, s6, v0
	v_mov_b32_e32 v0, v2
.LBB1_1:                                ; %.critedge26
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(0)
	v_lshlrev_b64 v[3:4], 2, v[0:1]
	v_mov_b32_e32 v0, s1
	v_add_co_u32_e32 v3, vcc, s0, v3
	v_addc_co_u32_e32 v4, vcc, v0, v4, vcc
	global_load_dword v0, v[3:4], off
	s_add_i32 s2, s2, -1
	s_cmp_eq_u32 s2, 0
	s_cbranch_scc0 .LBB1_1
; %bb.2:                                ; %.preheader
	s_load_dwordx2 s[0:1], s[4:5], 0x8
	v_mov_b32_e32 v3, 0
	v_lshlrev_b64 v[1:2], 2, v[2:3]
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v3, s1
	v_add_co_u32_e32 v1, vcc, s0, v1
	v_addc_co_u32_e32 v2, vcc, v3, v2, vcc
	s_waitcnt vmcnt(0)
	global_store_dword v[1:2], v0, off
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z11chase_ringsILj1EEvPKjPjj
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 280
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 7
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._Z11chase_ringsILj1EEvPKjPjj,#alloc,#execinstr
.Lfunc_end1:
	.size	_Z11chase_ringsILj1EEvPKjPjj, .Lfunc_end1-_Z11chase_ringsILj1EEvPKjPjj
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 144
; NumSgprs: 11
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 11
; NumVGPRsForWavesPerEU: 5
; Occupancy: 10
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.section	.text._Z11chase_ringsILj2EEvPKjPjj,#alloc,#execinstr
	.protected	_Z11chase_ringsILj2EEvPKjPjj ; -- Begin function _Z11chase_ringsILj2EEvPKjPjj
	.globl	_Z11chase_ringsILj2EEvPKjPjj
	.p2align	8
	.type	_Z11chase_ringsILj2EEvPKjPjj,@function
_Z11chase_ringsILj2EEvPKjPjj:           ; @_Z11chase_ringsILj2EEvPKjPjj
; %bb.0:                                ; %.preheader28.preheader
	s_load_dword s2, s[4:5], 0x24
	s_load_dword s3, s[4:5], 0x10
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v2, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s2, s2, 0xffff
	s_mul_i32 s6, s6, s2
	v_add_u32_e32 v0, s6, v0
	v_add_u32_e32 v3, s3, v0
	s_mov_b32 s2, 32
	v_mov_b32_e32 v1, v0
.LBB2_1:                                ; %.preheader28
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(1)
	v_lshlrev_b64 v[4:5], 2, v[1:2]
	v_mov_b32_e32 v1, s1
	v_add_co_u32_e32 v6, vcc, s0, v4
	v_mov_b32_e32 v4, v2
	s_waitcnt vmcnt(0)
	v_lshlrev_b64 v[3:4], 2, v[3:4]
	v_addc_co_u32_e32 v7, vcc, v1, v5, vcc
	v_add_co_u32_e32 v8, vcc, s0, v3
	v_addc_co_u32_e32 v9, vcc, v1, v4, vcc
	global_load_dword v1, v[6:7], off
	global_load_dword v3, v[8:9], off
	s_add_i32 s2, s2, -1
	s_cmp_lg_u32 s2, 0
	s_cbranch_scc1 .LBB2_1
; %bb.2:                                ; %.preheader
	s_load_dwordx2 s[0:1], s[4:5], 0x8
	s_waitcnt vmcnt(0)
	v_add_u32_e32 v2, v3, v1
	v_mov_b32_e32 v1, 0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v3, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v3, v1, vcc
	global_store_dword v[0:1], v2, off
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z11chase_ringsILj2EEvPKjPjj
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 280
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 10
		.amdhsa_next_free_sgpr 7
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._Z11chase_ringsILj2EEvPKjPjj,#alloc,#execinstr
.Lfunc_end2:
	.size	_Z11chase_ringsILj2EEvPKjPjj, .Lfunc_end2-_Z11chase_ringsILj2EEvPKjPjj
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 192
; NumSgprs: 11
; NumVgprs: 10
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 2
; NumSGPRsForWavesPerEU: 11
; NumVGPRsForWavesPerEU: 10
; Occupancy: 10
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.section	.text._Z11chase_ringsILj4EEvPKjPjj,#alloc,#execinstr
	.protected	_Z11chase_ringsILj4EEvPKjPjj ; -- Begin function _Z11chase_ringsILj4EEvPKjPjj
	.globl	_Z11chase_ringsILj4EEvPKjPjj
	.p2align	8
	.type	_Z11chase_ringsILj4EEvPKjPjj,@function
_Z11chase_ringsILj4EEvPKjPjj:           ; @_Z11chase_ringsILj4EEvPKjPjj
; %bb.0:                                ; %.preheader28.preheader
	s_load_dword s2, s[4:5], 0x24
	s_load_dword s3, s[4:5], 0x10
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v2, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s2, s2, 0xffff
	s_mul_i32 s6, s6, s2
	v_add_u32_e32 v0, s6, v0
	v_add_u32_e32 v5, s3, v0
	v_add_u32_e32 v4, s3, v5
	v_add_u32_e32 v3, s3, v4
	s_mov_b32 s2, 16
	v_mov_b32_e32 v1, v0
.LBB3_1:                                ; %.preheader28
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(3)
	v_lshlrev_b64 v[6:7], 2, v[1:2]
	v_mov_b32_e32 v1, s1
	v_add_co_u32_e32 v8, vcc, s0, v6
	v_mov_b32_e32 v6, v2
	s_waitcnt vmcnt(2)
	v_lshlrev_b64 v[5:6], 2, v[5:6]
	v_addc_co_u32_e32 v9, vcc, v1, v7, vcc
	v_add_co_u32_e32 v10, vcc, s0, v5
	v_mov_b32_e32 v5, v2
	s_waitcnt vmcnt(1)
	v_lshlrev_b64 v[4:5], 2, v[4:5]
	v_addc_co_u32_e32 v11, vcc, v1, v6, vcc
	v_add_co_u32_e32 v6, vcc, s0, v4
	v_mov_b32_e32 v4, v2
	s_waitcnt vmcnt(0)
	v_lshlrev_b64 v[3:4], 2, v[3:4]
	v_addc_co_u32_e32 v7, vcc, v1, v5, vcc
	v_add_co_u32_e32 v12, vcc, s0, v3
	v_addc_co_u32_e32 v13, vcc, v1, v4, vcc
	global_load_dword v1, v[8:9], off
	global_load_dword v5, v[10:11], off
	global_load_dword v4, v[6:7], off
	global_load_dword v3, v[12:13], off
	s_add_i32 s2, s2, -1
	s_cmp_lg_u32 s2, 0
	s_cbranch_scc1 .LBB3_1
; %bb.2:                                ; %.preheader
	s_load_dwordx2 s[0:1], s[4:5], 0x8
	s_waitcnt vmcnt(2)
	v_add_u32_e32 v2, v5, v1
	v_mov_b32_e32 v1, 0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	s_waitcnt vmcnt(0)
	v_add3_u32 v2, v4, v2, v3
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v3, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v3, v1, vcc
	global_store_dword v[0:1], v2, off
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z11chase_ringsILj4EEvPKjPjj
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 280
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 14
		.amdhsa_next_free_sgpr 7
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._Z11chase_ringsILj4EEvPKjPjj,#alloc,#execinstr
.Lfunc_end3:
	.size	_Z11chase_ringsILj4EEvPKjPjj, .Lfunc_end3-_Z11chase_ringsILj4EEvPKjPjj
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 276
; NumSgprs: 11
; NumVgprs: 14
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 3
; NumSGPRsForWavesPerEU: 11
; NumVGPRsForWavesPerEU: 14
; Occupancy: 10
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.section	.text._Z11chase_ringsILj8EEvPKjPjj,#alloc,#execinstr
	.protected	_Z11chase_ringsILj8EEvPKjPjj ; -- Begin function _Z11chase_ringsILj8EEvPKjPjj
	.globl	_Z11chase_ringsILj8EEvPKjPjj
	.p2align	8
	.type	_Z11chase_ringsILj8EEvPKjPjj,@function
_Z11chase_ringsILj8EEvPKjPjj:           ; @_Z11chase_ringsILj8EEvPKjPjj
; %bb.0:                                ; %.preheader28.preheader
	s_load_dword s2, s[4:5], 0x24
	s_load_dword s3, s[4:5], 0x10
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v2, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s2, s2, 0xffff
	s_mul_i32 s6, s6, s2
	v_add_u32_e32 v0, s6, v0
	v_add_u32_e32 v9, s3, v0
	v_add_u32_e32 v8, s3, v9
	v_add_u32_e32 v7, s3, v8
	v_add_u32_e32 v6, s3, v7
	v_add_u32_e32 v5, s3, v6
	v_add_u32_e32 v4, s3, v5
	v_add_u32_e32 v3, s3, v4
	s_mov_b32 s2, 8
	v_mov_b32_e32 v1, v0
.LBB4_1:                                ; %.preheader28
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(7)
	v_lshlrev_b64 v[10:11], 2, v[1:2]
	v_mov_b32_e32 v1, s1
	v_add_co_u32_e32 v12, vcc, s0, v10
	v_mov_b32_e32 v10, v2
	s_waitcnt vmcnt(6)
	v_lshlrev_b64 v[9:10], 2, v[9:10]
	v_addc_co_u32_e32 v13, vcc, v1, v11, vcc
	v_add_co_u32_e32 v14, vcc, s0, v9
	v_mov_b32_e32 v9, v2
	s_waitcnt vmcnt(5)
	v_lshlrev_b64 v[8:9], 2, v[8:9]
	v_addc_co_u32_e32 v15, vcc, v1, v10, vcc
	v_add_co_u32_e32 v10, vcc, s0, v8
	v_mov_b32_e32 v8, v2
	s_waitcnt vmcnt(4)
	v_lshlrev_b64 v[7:8], 2, v[7:8]
	v_addc_co_u32_e32 v11, vcc, v1, v9, vcc
	v_add_co_u32_e32 v16, vcc, s0, v7
	v_mov_b32_e32 v7, v2
	s_waitcnt vmcnt(3)
	v_lshlrev_b64 v[6:7], 2, v[6:7]
	v_addc_co_u32_e32 v17, vcc, v1, v8, vcc
	v_add_co_u32_e32 v18, vcc, s0, v6
	v_mov_b32_e32 v6, v2
	s_waitcnt vmcnt(2)
	v_lshlrev_b64 v[5:6], 2, v[5:6]
	v_addc_co_u32_e32 v19, vcc, v1, v7, vcc
	v_add_co_u32_e32 v20, vcc, s0, v5
	v_mov_b32_e32 v5, v2
	s_waitcnt vmcnt(1)
	v_lshlrev_b64 v[4:5], 2, v[4:5]
	v_addc_co_u32_e32 v21, vcc, v1, v6, vcc
	v_add_co_u32_e32 v22, vcc, s0, v4
	v_mov_b32_e32 v4, v2
	s_waitcnt vmcnt(0)
	v_lshlrev_b64 v[3:4], 2, v[3:4]
	v_addc_co_u32_e32 v23, vcc, v1, v5, vcc
	v_add_co_u32_e32 v24, vcc, s0, v3
	v_addc_co_u32_e32 v25, vcc, v1, v4, vcc
	global_load_dword v1, v[12:13], off
	global_load_dword v9, v[14:15], off
	global_load_dword v8, v[10:11], off
	global_load_dword v7, v[16:17], off
	global_load_dword v6, v[18:19], off
	global_load_dword v5, v[20:21], off
	global_load_dword v4, v[22:23], off
	global_load_dword v3, v[24:25], off
	s_add_i32 s2, s2, -1
	s_cmp_lg_u32 s2, 0
	s_cbranch_scc1 .LBB4_1
; %bb.2:                                ; %.preheader
	s_waitcnt vmcnt(6)
	v_add_u32_e32 v1, v9, v1
	s_load_dwordx2 s[0:1], s[4:5], 0x8
	s_waitcnt vmcnt(4)
	v_add3_u32 v1, v8, v1, v7
	s_waitcnt vmcnt(2)
	v_add3_u32 v1, v6, v1, v5
	s_waitcnt vmcnt(0)
	v_add3_u32 v2, v4, v1, v3
	v_mov_b32_e32 v1, 0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v3, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v3, v1, vcc
	global_store_dword v[0:1], v2, off
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z11chase_ringsILj8EEvPKjPjj
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 280
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 26
		.amdhsa_next_free_sgpr 7
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._Z11chase_ringsILj8EEvPKjPjj,#alloc,#execinstr
.Lfunc_end4:
	.size	_Z11chase_ringsILj8EEvPKjPjj, .Lfunc_end4-_Z11chase_ringsILj8EEvPKjPjj
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 444
; NumSgprs: 11
; NumVgprs: 26
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 6
; NumSGPRsForWavesPerEU: 11
; NumVGPRsForWavesPerEU: 26
; Occupancy: 9
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.ident	"clang version 17.0.0"
	.section	".note.GNU-stack"
	.addrsig
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .offset:         8
        .size:           4
        .value_kind:     by_value
      - .offset:         12
        .size:           4
        .value_kind:     by_value
      - .offset:         16
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         20
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         24
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         28
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         30
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         32
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         34
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         36
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         38
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         56
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         64
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         72
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         80
        .size:           2
        .value_kind:     hidden_grid_dims
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 272
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z16initialize_ringsPjjj
    .private_segment_fixed_size: 0
    .sgpr_count:     12
    .sgpr_spill_count: 0
    .symbol:         _Z16initialize_ringsPjjj.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     6
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  read_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .offset:         16
        .size:           4
        .value_kind:     by_value
      - .offset:         24
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         28
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         32
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         36
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         38
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         40
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         42
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         44
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         46
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         64
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         72
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         80
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         88
        .size:           2
        .value_kind:     hidden_grid_dims
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 280
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z11chase_ringsILj1EEvPKjPjj
    .private_segment_fixed_size: 0
    .sgpr_count:     11
    .sgpr_spill_count: 0
    .symbol:         _Z11chase_ringsILj1EEvPKjPjj.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  read_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .offset:         16
        .size:           4
        .value_kind:     by_value
      - .offset:         24
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         28
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         32
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         36
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         38
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         40
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         42
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         44
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         46
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         64
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         72
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         80
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         88
        .size:           2
        .value_kind:     hidden_grid_dims
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 280
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z11chase_ringsILj2EEvPKjPjj
    .private_segment_fixed_size: 0
    .sgpr_count:     11
    .sgpr_spill_count: 0
    .symbol:         _Z11chase_ringsILj2EEvPKjPjj.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     10
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  read_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .offset:         16
        .size:           4
        .value_kind:     by_value
      - .offset:         24
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         28
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         32
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         36
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         38
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         40
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         42
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         44
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         46
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         64
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         72
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         80
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         88
        .size:           2
        .value_kind:     hidden_grid_dims
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 280
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z11chase_ringsILj4EEvPKjPjj
    .private_segment_fixed_size: 0
    .sgpr_count:     11
    .sgpr_spill_count: 0
    .symbol:         _Z11chase_ringsILj4EEvPKjPjj.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     14
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  read_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .offset:         16
        .size:           4
        .value_kind:     by_value
      - .offset:         24
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         28
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         32
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         36
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         38
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         40
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         42
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         44
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         46
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         64
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         72
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         80
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         88
        .size:           2
        .value_kind:     hidden_grid_dims
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 280
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z11chase_ringsILj8EEvPKjPjj
    .private_segment_fixed_size: 0
    .sgpr_count:     11
    .sgpr_spill_count: 0
    .symbol:         _Z11chase_ringsILj8EEvPKjPjj.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     26
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
