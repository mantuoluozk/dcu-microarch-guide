	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
	.protected	_Z16lds_chase_kernelPiPyii ; -- Begin function _Z16lds_chase_kernelPiPyii
	.globl	_Z16lds_chase_kernelPiPyii
	.p2align	8
	.type	_Z16lds_chase_kernelPiPyii,@function
_Z16lds_chase_kernelPiPyii:             ; @_Z16lds_chase_kernelPiPyii
; %bb.0:
	s_load_dwordx2 s[6:7], s[4:5], 0x10
	s_waitcnt lgkmcnt(0)
	s_cmp_lt_i32 s6, 1
	s_cbranch_scc1 .LBB0_12
; %bb.1:                                ; %.lr.ph.preheader
	s_cmp_eq_u32 s6, 1
	s_cbranch_scc1 .LBB0_9
; %bb.2:                                ; %vector.ph
	s_add_i32 s3, s6, -2
	s_lshr_b32 s2, s3, 1
	s_add_i32 s2, s2, 1
	s_mov_b32 s1, 0
	s_mov_b32 s0, 1
	s_cmp_lt_u32 s3, 14
	s_mov_b32 s3, s1
	s_cbranch_scc1 .LBB0_5
; %bb.3:                                ; %vector.ph.new
	s_ashr_i32 s1, s6, 31
	s_add_i32 s3, s1, s6
	s_xor_b32 s8, s3, s1
	v_cvt_f32_u32_e32 v0, s8
	s_and_b32 s9, s2, -8
	s_mov_b32 s10, 0
	s_mov_b32 s3, 0
	v_rcp_iflag_f32_e32 v0, v0
	s_mov_b32 s1, 0
	v_mul_f32_e32 v0, 0x4f7ffffe, v0
	v_cvt_u32_f32_e32 v0, v0
.LBB0_4:                                ; %vector.body
                                        ; =>This Inner Loop Header: Depth=1
	s_add_i32 s11, s1, 17
	v_readfirstlane_b32 s13, v0
	s_ashr_i32 s14, s11, 31
	s_mul_i32 s15, s8, s13
	s_add_i32 s11, s14, s11
	s_sub_i32 s15, 0, s15
	s_xor_b32 s16, s11, s14
	s_mul_hi_u32 s11, s15, s13
	s_add_i32 s11, s11, s13
	s_mul_hi_u32 s13, s16, s11
	s_mul_i32 s13, s13, s8
	s_sub_i32 s13, s16, s13
	s_add_i32 s12, s0, 17
	s_sub_i32 s15, s13, s8
	s_cmp_ge_u32 s13, s8
	s_cselect_b32 s13, s15, s13
	s_sub_i32 s15, s13, s8
	s_cmp_ge_u32 s13, s8
	s_cselect_b32 s13, s15, s13
	s_ashr_i32 s15, s12, 31
	s_add_i32 s12, s15, s12
	s_xor_b32 s13, s13, s14
	s_xor_b32 s12, s12, s15
	s_sub_i32 s13, s13, s14
	s_mul_hi_u32 s14, s12, s11
	s_mul_i32 s14, s14, s8
	s_sub_i32 s12, s12, s14
	v_mov_b32_e32 v1, s13
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_add_i32 s14, s1, 19
	s_ashr_i32 s16, s14, 31
	s_xor_b32 s12, s12, s15
	s_add_i32 s14, s16, s14
	s_sub_i32 s12, s12, s15
	s_xor_b32 s14, s14, s16
	v_mov_b32_e32 v2, s12
	s_mul_hi_u32 s12, s14, s11
	s_mul_i32 s12, s12, s8
	s_sub_i32 s12, s14, s12
	s_add_i32 s13, s0, 19
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_ashr_i32 s14, s13, 31
	s_add_i32 s13, s14, s13
	s_xor_b32 s13, s13, s14
	s_xor_b32 s12, s12, s16
	s_mul_hi_u32 s15, s13, s11
	s_sub_i32 s12, s12, s16
	s_mul_i32 s15, s15, s8
	v_mov_b32_e32 v3, s12
	s_sub_i32 s12, s13, s15
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_add_i32 s15, s1, 21
	s_xor_b32 s12, s12, s14
	s_ashr_i32 s16, s15, 31
	s_sub_i32 s12, s12, s14
	s_add_i32 s14, s16, s15
	v_mov_b32_e32 v4, s12
	s_xor_b32 s12, s14, s16
	s_mul_hi_u32 s14, s12, s11
	s_mul_i32 s14, s14, s8
	s_sub_i32 s12, s12, s14
	s_add_i32 s13, s0, 21
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_ashr_i32 s14, s13, 31
	s_add_i32 s13, s14, s13
	s_xor_b32 s13, s13, s14
	s_xor_b32 s12, s12, s16
	s_mul_hi_u32 s15, s13, s11
	v_mov_b32_e32 v5, s10
	s_sub_i32 s12, s12, s16
	s_mul_i32 s15, s15, s8
	ds_write_b128 v5, v[1:4]
	v_mov_b32_e32 v1, s12
	s_sub_i32 s12, s13, s15
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_add_i32 s15, s1, 23
	s_xor_b32 s12, s12, s14
	s_ashr_i32 s16, s15, 31
	s_sub_i32 s12, s12, s14
	s_add_i32 s14, s16, s15
	s_xor_b32 s14, s14, s16
	v_mov_b32_e32 v2, s12
	s_mul_hi_u32 s12, s14, s11
	s_mul_i32 s12, s12, s8
	s_sub_i32 s12, s14, s12
	s_add_i32 s13, s0, 23
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_ashr_i32 s14, s13, 31
	s_add_i32 s13, s14, s13
	s_xor_b32 s13, s13, s14
	s_xor_b32 s12, s12, s16
	s_mul_hi_u32 s15, s13, s11
	s_sub_i32 s12, s12, s16
	s_mul_i32 s15, s15, s8
	v_mov_b32_e32 v3, s12
	s_sub_i32 s12, s13, s15
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_add_i32 s15, s1, 25
	s_xor_b32 s12, s12, s14
	s_ashr_i32 s16, s15, 31
	s_sub_i32 s12, s12, s14
	s_add_i32 s14, s16, s15
	v_mov_b32_e32 v4, s12
	s_xor_b32 s12, s14, s16
	s_mul_hi_u32 s14, s12, s11
	s_mul_i32 s14, s14, s8
	s_sub_i32 s12, s12, s14
	s_add_i32 s13, s0, 25
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_ashr_i32 s14, s13, 31
	s_add_i32 s13, s14, s13
	s_xor_b32 s13, s13, s14
	s_xor_b32 s12, s12, s16
	s_mul_hi_u32 s15, s13, s11
	s_sub_i32 s12, s12, s16
	s_mul_i32 s15, s15, s8
	ds_write_b128 v5, v[1:4] offset:16
	v_mov_b32_e32 v1, s12
	s_sub_i32 s12, s13, s15
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_add_i32 s15, s1, 27
	s_xor_b32 s12, s12, s14
	s_ashr_i32 s16, s15, 31
	s_sub_i32 s12, s12, s14
	s_add_i32 s14, s16, s15
	s_xor_b32 s14, s14, s16
	v_mov_b32_e32 v2, s12
	s_mul_hi_u32 s12, s14, s11
	s_mul_i32 s12, s12, s8
	s_sub_i32 s12, s14, s12
	s_add_i32 s13, s0, 27
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_ashr_i32 s14, s13, 31
	s_add_i32 s13, s14, s13
	s_xor_b32 s13, s13, s14
	s_xor_b32 s12, s12, s16
	s_mul_hi_u32 s15, s13, s11
	s_sub_i32 s12, s12, s16
	s_mul_i32 s15, s15, s8
	v_mov_b32_e32 v3, s12
	s_sub_i32 s12, s13, s15
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_add_i32 s15, s1, 29
	s_xor_b32 s12, s12, s14
	s_ashr_i32 s16, s15, 31
	s_sub_i32 s12, s12, s14
	s_add_i32 s14, s16, s15
	v_mov_b32_e32 v4, s12
	s_xor_b32 s12, s14, s16
	s_mul_hi_u32 s14, s12, s11
	s_mul_i32 s14, s14, s8
	s_sub_i32 s12, s12, s14
	s_add_i32 s13, s0, 29
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_ashr_i32 s14, s13, 31
	s_add_i32 s13, s14, s13
	s_xor_b32 s13, s13, s14
	s_xor_b32 s12, s12, s16
	s_mul_hi_u32 s15, s13, s11
	s_sub_i32 s12, s12, s16
	s_mul_i32 s15, s15, s8
	ds_write_b128 v5, v[1:4] offset:32
	v_mov_b32_e32 v1, s12
	s_sub_i32 s12, s13, s15
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_sub_i32 s13, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s13, s12
	s_add_i32 s15, s1, 31
	s_xor_b32 s12, s12, s14
	s_ashr_i32 s16, s15, 31
	s_sub_i32 s12, s12, s14
	s_add_i32 s14, s16, s15
	s_xor_b32 s14, s14, s16
	v_mov_b32_e32 v2, s12
	s_mul_hi_u32 s12, s14, s11
	s_mul_i32 s12, s12, s8
	s_sub_i32 s12, s14, s12
	s_add_i32 s13, s0, 31
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_sub_i32 s14, s12, s8
	s_cmp_ge_u32 s12, s8
	s_cselect_b32 s12, s14, s12
	s_ashr_i32 s14, s13, 31
	s_add_i32 s13, s14, s13
	s_xor_b32 s13, s13, s14
	s_mul_hi_u32 s11, s13, s11
	s_xor_b32 s12, s12, s16
	s_mul_i32 s11, s11, s8
	s_sub_i32 s12, s12, s16
	s_sub_i32 s11, s13, s11
	v_mov_b32_e32 v3, s12
	s_sub_i32 s12, s11, s8
	s_cmp_ge_u32 s11, s8
	s_cselect_b32 s11, s12, s11
	s_sub_i32 s12, s11, s8
	s_cmp_ge_u32 s11, s8
	s_cselect_b32 s11, s12, s11
	s_xor_b32 s11, s11, s14
	s_add_i32 s3, s3, 16
	s_add_i32 s0, s0, 16
	s_add_i32 s1, s1, 16
	s_add_i32 s10, s10, 64
	s_add_i32 s9, s9, -8
	s_sub_i32 s11, s11, s14
	v_mov_b32_e32 v4, s11
	s_cmp_lg_u32 s9, 0
	ds_write_b128 v5, v[1:4] offset:48
	s_cbranch_scc1 .LBB0_4
.LBB0_5:                                ; %middle.block.unr-lcssa
	s_and_b32 s2, s2, 7
	s_cmp_eq_u32 s2, 0
	s_cbranch_scc1 .LBB0_8
; %bb.6:                                ; %vector.body.epil.preheader
	s_ashr_i32 s8, s6, 31
	s_add_i32 s9, s8, s6
	s_xor_b32 s8, s9, s8
	v_cvt_f32_u32_e32 v0, s8
	s_lshl_b32 s3, s3, 2
	v_rcp_iflag_f32_e32 v0, v0
	v_mul_f32_e32 v0, 0x4f7ffffe, v0
	v_cvt_u32_f32_e32 v0, v0
.LBB0_7:                                ; %vector.body.epil
                                        ; =>This Inner Loop Header: Depth=1
	v_readfirstlane_b32 s11, v0
	s_add_i32 s10, s1, 17
	s_mul_i32 s13, s8, s11
	s_ashr_i32 s12, s10, 31
	s_sub_i32 s13, 0, s13
	s_add_i32 s10, s12, s10
	s_mul_hi_u32 s13, s13, s11
	s_xor_b32 s10, s10, s12
	s_add_i32 s13, s13, s11
	s_mul_hi_u32 s11, s10, s13
	s_mul_i32 s11, s11, s8
	s_sub_i32 s10, s10, s11
	s_add_i32 s9, s0, 17
	s_sub_i32 s11, s10, s8
	s_cmp_ge_u32 s10, s8
	s_cselect_b32 s10, s11, s10
	s_sub_i32 s11, s10, s8
	s_cmp_ge_u32 s10, s8
	s_cselect_b32 s10, s11, s10
	s_ashr_i32 s11, s9, 31
	s_add_i32 s9, s11, s9
	s_xor_b32 s10, s10, s12
	s_xor_b32 s9, s9, s11
	s_sub_i32 s10, s10, s12
	s_mul_hi_u32 s12, s9, s13
	s_mul_i32 s12, s12, s8
	s_sub_i32 s9, s9, s12
	v_mov_b32_e32 v1, s10
	s_sub_i32 s10, s9, s8
	s_cmp_ge_u32 s9, s8
	s_cselect_b32 s9, s10, s9
	s_sub_i32 s10, s9, s8
	s_cmp_ge_u32 s9, s8
	s_cselect_b32 s9, s10, s9
	s_xor_b32 s9, s9, s11
	v_mov_b32_e32 v3, s3
	s_add_i32 s0, s0, 2
	s_add_i32 s1, s1, 2
	s_add_i32 s3, s3, 8
	s_add_i32 s2, s2, -1
	s_sub_i32 s9, s9, s11
	v_mov_b32_e32 v2, s9
	s_cmp_lg_u32 s2, 0
	ds_write_b64 v3, v[1:2]
	s_cbranch_scc1 .LBB0_7
.LBB0_8:                                ; %middle.block
	s_and_b32 s2, s6, -2
	s_cmp_lg_u32 s2, s6
	s_cselect_b64 s[0:1], -1, 0
	s_and_b64 vcc, exec, s[0:1]
	s_cbranch_vccnz .LBB0_10
	s_branch .LBB0_12
.LBB0_9:
	s_mov_b32 s2, 0
	s_cbranch_execz .LBB0_12
.LBB0_10:                               ; %.lr.ph.preheader42
	s_ashr_i32 s0, s6, 31
	s_add_i32 s1, s0, s6
	s_xor_b32 s0, s1, s0
	v_cvt_f32_u32_e32 v0, s0
	s_lshl_b32 s1, s2, 2
	v_rcp_iflag_f32_e32 v0, v0
	v_mul_f32_e32 v0, 0x4f7ffffe, v0
	v_cvt_u32_f32_e32 v0, v0
.LBB0_11:                               ; %.lr.ph
                                        ; =>This Inner Loop Header: Depth=1
	v_readfirstlane_b32 s8, v0
	s_add_i32 s3, s2, 17
	s_mul_i32 s10, s0, s8
	s_ashr_i32 s9, s3, 31
	s_sub_i32 s10, 0, s10
	s_add_i32 s3, s3, s9
	s_mul_hi_u32 s10, s10, s8
	s_xor_b32 s3, s3, s9
	s_add_i32 s10, s10, s8
	s_mul_hi_u32 s8, s3, s10
	s_mul_i32 s8, s8, s0
	s_sub_i32 s3, s3, s8
	s_sub_i32 s8, s3, s0
	s_cmp_ge_u32 s3, s0
	s_cselect_b32 s3, s8, s3
	s_sub_i32 s8, s3, s0
	s_cmp_ge_u32 s3, s0
	s_cselect_b32 s3, s8, s3
	s_xor_b32 s3, s3, s9
	v_mov_b32_e32 v1, s1
	s_add_i32 s2, s2, 1
	s_add_i32 s1, s1, 4
	s_sub_i32 s3, s3, s9
	v_mov_b32_e32 v2, s3
	s_cmp_eq_u32 s6, s2
	ds_write_b32 v1, v2
	s_cbranch_scc0 .LBB0_11
.LBB0_12:                               ; %._crit_edge
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	s_cmp_gt_i32 s7, 0
	s_cselect_b64 s[8:9], -1, 0
	s_cmp_lt_i32 s7, 1
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_waitcnt lgkmcnt(0)
	s_cbranch_scc1 .LBB0_17
; %bb.13:                               ; %.lr.ph29.preheader
	s_cmp_lt_u32 s7, 8
	s_cbranch_scc1 .LBB0_18
; %bb.14:                               ; %.lr.ph29.preheader.new
	s_and_b32 s4, s7, -8
	v_mov_b32_e32 v0, 0
.LBB0_15:                               ; %.lr.ph29
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_add_i32 s4, s4, -8
	s_cmp_eq_u32 s4, 0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_cbranch_scc0 .LBB0_15
; %bb.16:                               ; %._crit_edge30.loopexit.unr-lcssa
	s_and_b32 s4, s7, 7
	s_cmp_eq_u32 s4, 0
	s_cbranch_scc0 .LBB0_19
	s_branch .LBB0_20
.LBB0_17:
	v_mov_b32_e32 v0, 0
	s_branch .LBB0_20
.LBB0_18:
	v_mov_b32_e32 v0, 0
	s_and_b32 s4, s7, 7
	s_cmp_eq_u32 s4, 0
	s_cbranch_scc1 .LBB0_20
.LBB0_19:                               ; %.lr.ph29.epil
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_add_i32 s4, s4, -1
	s_cmp_lg_u32 s4, 0
	s_cbranch_scc1 .LBB0_19
.LBB0_20:                               ; %._crit_edge30
	;;#ASMSTART
	s_waitcnt 0
	;;#ASMEND
	s_memtime s[4:5]
	s_andn2_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB0_26
; %bb.21:                               ; %.lr.ph34.preheader
	s_cmp_lt_u32 s7, 8
	s_cbranch_scc1 .LBB0_24
; %bb.22:                               ; %.lr.ph34.preheader.new
	s_and_b32 s6, s7, -8
.LBB0_23:                               ; %.lr.ph34
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_add_i32 s6, s6, -8
	s_cmp_eq_u32 s6, 0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_cbranch_scc0 .LBB0_23
.LBB0_24:                               ; %._crit_edge35.loopexit.unr-lcssa
	s_and_b32 s6, s7, 7
	s_cmp_eq_u32 s6, 0
	s_cbranch_scc1 .LBB0_26
.LBB0_25:                               ; %.lr.ph34.epil
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	v_lshlrev_b32_e32 v0, 2, v0
	ds_read_b32 v0, v0
	s_add_i32 s6, s6, -1
	s_cmp_lg_u32 s6, 0
	s_cbranch_scc1 .LBB0_25
.LBB0_26:                               ; %._crit_edge35
	;;#ASMSTART
	s_waitcnt 0
	;;#ASMEND
	s_memtime s[6:7]
	v_mov_b32_e32 v2, 0
	s_waitcnt lgkmcnt(0)
	global_store_dword v2, v0, s[0:1]
	s_sub_u32 s0, s6, s4
	s_subb_u32 s1, s7, s5
	v_mov_b64_e32 v[0:1], s[0:1]
	global_store_dwordx2 v2, v[0:1], s[2:3]
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z16lds_chase_kernelPiPyii
		.amdhsa_group_segment_fixed_size 16384
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 24
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 6
		.amdhsa_next_free_sgpr 17
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z16lds_chase_kernelPiPyii, .Lfunc_end0-_Z16lds_chase_kernelPiPyii
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 2160
; NumSgprs: 21
; NumVgprs: 6
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 16384 bytes/workgroup (compile time only)
; SGPRBlocks: 2
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 21
; NumVGPRsForWavesPerEU: 6
; Occupancy: 4
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.section	.text._Z19global_chase_kernelILb1EEvPKiPiPyi,#alloc,#execinstr
	.protected	_Z19global_chase_kernelILb1EEvPKiPiPyi ; -- Begin function _Z19global_chase_kernelILb1EEvPKiPiPyi
	.globl	_Z19global_chase_kernelILb1EEvPKiPiPyi
	.p2align	8
	.type	_Z19global_chase_kernelILb1EEvPKiPiPyi,@function
_Z19global_chase_kernelILb1EEvPKiPiPyi: ; @_Z19global_chase_kernelILb1EEvPKiPiPyi
; %bb.0:
	s_load_dword s10, s[4:5], 0x18
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	s_load_dwordx2 s[6:7], s[4:5], 0x10
	s_waitcnt lgkmcnt(0)
	s_cmp_gt_i32 s10, 0
	s_cselect_b64 s[8:9], -1, 0
	s_cmp_lt_i32 s10, 1
	s_cbranch_scc1 .LBB1_6
; %bb.1:                                ; %.lr.ph.preheader
	s_cmp_lt_u32 s10, 8
	s_cbranch_scc1 .LBB1_4
; %bb.2:                                ; %.lr.ph.preheader.new
	s_and_b32 s4, s10, -8
.LBB1_3:                                ; %.lr.ph
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_mov_b32_e32 v2, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_add_i32 s4, s4, -8
	s_cmp_eq_u32 s4, 0
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_cbranch_scc0 .LBB1_3
.LBB1_4:                                ; %._crit_edge.loopexit.unr-lcssa
	s_and_b32 s4, s10, 7
	s_cmp_eq_u32 s4, 0
	s_cbranch_scc1 .LBB1_6
.LBB1_5:                                ; %.lr.ph.epil
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_mov_b32_e32 v2, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_add_i32 s4, s4, -1
	s_cmp_lg_u32 s4, 0
	s_cbranch_scc1 .LBB1_5
.LBB1_6:                                ; %._crit_edge
	;;#ASMSTART
	s_waitcnt 0
	;;#ASMEND
	s_memtime s[4:5]
	s_andn2_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB1_12
; %bb.7:                                ; %.lr.ph25.preheader
	s_cmp_lt_u32 s10, 8
	s_cbranch_scc1 .LBB1_10
; %bb.8:                                ; %.lr.ph25.preheader.new
	s_and_b32 s8, s10, -8
	s_waitcnt vmcnt(0)
.LBB1_9:                                ; %.lr.ph25
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_mov_b32_e32 v2, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_add_i32 s8, s8, -8
	s_cmp_eq_u32 s8, 0
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_cbranch_scc0 .LBB1_9
.LBB1_10:                               ; %._crit_edge26.loopexit.unr-lcssa
	s_and_b32 s8, s10, 7
	s_cmp_eq_u32 s8, 0
	s_cbranch_scc1 .LBB1_12
.LBB1_11:                               ; %.lr.ph25.epil
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt vmcnt(0)
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_mov_b32_e32 v2, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v2, v1, vcc
	global_load_dword v0, v[0:1], off
	s_add_i32 s8, s8, -1
	s_cmp_lg_u32 s8, 0
	s_cbranch_scc1 .LBB1_11
.LBB1_12:                               ; %._crit_edge26
	;;#ASMSTART
	s_waitcnt 0
	;;#ASMEND
	s_memtime s[0:1]
	v_mov_b32_e32 v2, 0
	s_waitcnt vmcnt(0)
	global_store_dword v2, v0, s[2:3]
	s_waitcnt lgkmcnt(0)
	s_sub_u32 s0, s0, s4
	s_subb_u32 s1, s1, s5
	v_mov_b64_e32 v[0:1], s[0:1]
	global_store_dwordx2 v2, v[0:1], s[6:7]
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z19global_chase_kernelILb1EEvPKiPiPyi
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 28
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 3
		.amdhsa_next_free_sgpr 11
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._Z19global_chase_kernelILb1EEvPKiPiPyi,#alloc,#execinstr
.Lfunc_end1:
	.size	_Z19global_chase_kernelILb1EEvPKiPiPyi, .Lfunc_end1-_Z19global_chase_kernelILb1EEvPKiPiPyi
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 820
; NumSgprs: 15
; NumVgprs: 3
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 0
; NumSGPRsForWavesPerEU: 15
; NumVGPRsForWavesPerEU: 3
; Occupancy: 10
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.section	.text._Z19global_chase_kernelILb0EEvPKiPiPyi,#alloc,#execinstr
	.protected	_Z19global_chase_kernelILb0EEvPKiPiPyi ; -- Begin function _Z19global_chase_kernelILb0EEvPKiPiPyi
	.globl	_Z19global_chase_kernelILb0EEvPKiPiPyi
	.p2align	8
	.type	_Z19global_chase_kernelILb0EEvPKiPiPyi,@function
_Z19global_chase_kernelILb0EEvPKiPiPyi: ; @_Z19global_chase_kernelILb0EEvPKiPiPyi
; %bb.0:
	s_load_dword s12, s[4:5], 0x18
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	s_load_dwordx2 s[6:7], s[4:5], 0x10
	s_mov_b32 s10, 0
	s_waitcnt lgkmcnt(0)
	s_cmp_gt_i32 s12, 0
	s_cselect_b64 s[8:9], -1, 0
	s_cmp_lt_i32 s12, 1
	s_cbranch_scc1 .LBB2_6
; %bb.1:                                ; %.lr.ph.preheader
	s_cmp_lt_u32 s12, 8
	s_cbranch_scc1 .LBB2_4
; %bb.2:                                ; %.lr.ph.preheader.new
	s_and_b32 s4, s12, -8
.LBB2_3:                                ; %.lr.ph
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_add_i32 s4, s4, -8
	s_cmp_eq_u32 s4, 0
	s_cbranch_scc0 .LBB2_3
.LBB2_4:                                ; %._crit_edge.loopexit.unr-lcssa
	s_and_b32 s4, s12, 7
	s_cmp_eq_u32 s4, 0
	s_cbranch_scc1 .LBB2_6
.LBB2_5:                                ; %.lr.ph.epil
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_add_i32 s4, s4, -1
	s_cmp_lg_u32 s4, 0
	s_cbranch_scc1 .LBB2_5
.LBB2_6:                                ; %._crit_edge
	;;#ASMSTART
	s_waitcnt 0
	;;#ASMEND
	s_memtime s[4:5]
	s_andn2_b64 vcc, exec, s[8:9]
	s_cbranch_vccnz .LBB2_12
; %bb.7:                                ; %.lr.ph25.preheader
	s_cmp_lt_u32 s12, 8
	s_cbranch_scc1 .LBB2_10
; %bb.8:                                ; %.lr.ph25.preheader.new
	s_and_b32 s8, s12, -8
.LBB2_9:                                ; %.lr.ph25
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_add_i32 s8, s8, -8
	s_cmp_eq_u32 s8, 0
	s_cbranch_scc0 .LBB2_9
.LBB2_10:                               ; %._crit_edge26.loopexit.unr-lcssa
	s_and_b32 s8, s12, 7
	s_cmp_eq_u32 s8, 0
	s_cbranch_scc1 .LBB2_12
.LBB2_11:                               ; %.lr.ph25.epil
                                        ; =>This Inner Loop Header: Depth=1
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s11, s10, 31
	s_lshl_b64 s[10:11], s[10:11], 2
	s_add_u32 s10, s0, s10
	s_addc_u32 s11, s1, s11
	s_load_dword s10, s[10:11], 0x0
	s_add_i32 s8, s8, -1
	s_cmp_lg_u32 s8, 0
	s_cbranch_scc1 .LBB2_11
.LBB2_12:                               ; %._crit_edge26
	;;#ASMSTART
	s_waitcnt 0
	;;#ASMEND
	s_memtime s[0:1]
	v_mov_b32_e32 v2, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v0, s10
	global_store_dword v2, v0, s[2:3]
	s_sub_u32 s0, s0, s4
	s_subb_u32 s1, s1, s5
	v_mov_b64_e32 v[0:1], s[0:1]
	global_store_dwordx2 v2, v[0:1], s[6:7]
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z19global_chase_kernelILb0EEvPKiPiPyi
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 28
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 3
		.amdhsa_next_free_sgpr 13
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.section	.text._Z19global_chase_kernelILb0EEvPKiPiPyi,#alloc,#execinstr
.Lfunc_end2:
	.size	_Z19global_chase_kernelILb0EEvPKiPiPyi, .Lfunc_end2-_Z19global_chase_kernelILb0EEvPKiPiPyi
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 732
; NumSgprs: 17
; NumVgprs: 3
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 2
; VGPRBlocks: 0
; NumSGPRsForWavesPerEU: 17
; NumVGPRsForWavesPerEU: 3
; Occupancy: 10
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.ident	"clang version 17.0.0"
	.section	".note.GNU-stack"
	.addrsig
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .actual_access:  write_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .offset:         16
        .size:           4
        .value_kind:     by_value
      - .offset:         20
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 16384
    .kernarg_segment_align: 8
    .kernarg_segment_size: 24
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z16lds_chase_kernelPiPyii
    .private_segment_fixed_size: 0
    .sgpr_count:     21
    .sgpr_spill_count: 0
    .symbol:         _Z16lds_chase_kernelPiPyii.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     6
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  read_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 28
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z19global_chase_kernelILb1EEvPKiPiPyi
    .private_segment_fixed_size: 0
    .sgpr_count:     15
    .sgpr_spill_count: 0
    .symbol:         _Z19global_chase_kernelILb1EEvPKiPiPyi.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     3
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  read_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 28
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z19global_chase_kernelILb0EEvPKiPiPyi
    .private_segment_fixed_size: 0
    .sgpr_count:     17
    .sgpr_spill_count: 0
    .symbol:         _Z19global_chase_kernelILb0EEvPKiPiPyi.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     3
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
