	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936:sramecc+"
	.protected	_Z21valu_fp32_peak_kernelPff ; -- Begin function _Z21valu_fp32_peak_kernelPff
	.globl	_Z21valu_fp32_peak_kernelPff
	.p2align	8
	.type	_Z21valu_fp32_peak_kernelPff,@function
_Z21valu_fp32_peak_kernelPff:           ; @_Z21valu_fp32_peak_kernelPff
; %bb.0:
	s_load_dword s2, s[4:5], 0x8
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v1, 0.5
	v_mov_b32_e32 v2, 0x3e4ccccd
	v_mov_b32_e32 v3, 0x3f19999a
	s_waitcnt lgkmcnt(0)
	s_mov_b32 s3, s2
	v_mov_b64_e32 v[7:8], s[2:3]
	v_mov_b32_e32 v4, 0x3dcccccd
	v_mov_b32_e32 v5, 0x3f333333
	v_mov_b32_e32 v6, 0x3e99999a
	v_mov_b32_e32 v9, 0x3f4ccccd
	v_mov_b32_e32 v10, 0x3ecccccd
	v_pk_add_f32 v[1:2], v[7:8], v[1:2]
	v_pk_add_f32 v[3:4], v[7:8], v[3:4]
	v_pk_add_f32 v[5:6], v[7:8], v[5:6]
	v_pk_add_f32 v[7:8], v[7:8], v[9:10]
	s_movk_i32 s7, 0x1000
	s_mov_b32 s2, 0x3f800347
	s_mov_b32 s8, 0x38d1b717
.LBB0_1:                                ; =>This Inner Loop Header: Depth=1
	s_mov_b32 s3, s2
	s_mov_b32 s9, s8
	v_mov_b64_e32 v[9:10], s[2:3]
	v_mov_b64_e32 v[11:12], s[8:9]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	s_add_i32 s7, s7, -16
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	s_cmp_eq_u32 s7, 0
	v_pk_fma_f32 v[1:2], v[1:2], v[9:10], v[11:12]
	v_pk_fma_f32 v[3:4], v[3:4], v[9:10], v[11:12]
	v_pk_fma_f32 v[5:6], v[5:6], v[9:10], v[11:12]
	v_pk_fma_f32 v[7:8], v[7:8], v[9:10], v[11:12]
	s_cbranch_scc0 .LBB0_1
; %bb.2:
	s_load_dword s2, s[4:5], 0x1c
	v_pk_add_f32 v[1:2], v[1:2], v[3:4]
	v_pk_add_f32 v[1:2], v[5:6], v[1:2]
	v_pk_add_f32 v[1:2], v[7:8], v[1:2]
	v_add_f32_e32 v2, v1, v2
	s_waitcnt lgkmcnt(0)
	s_and_b32 s2, s2, 0xffff
	s_mul_i32 s6, s6, s2
	v_add_u32_e32 v0, s6, v0
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_mov_b32_e32 v3, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v3, v1, vcc
	global_store_dword v[0:1], v2, off
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z21valu_fp32_peak_kernelPff
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 272
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 13
		.amdhsa_next_free_sgpr 10
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z21valu_fp32_peak_kernelPff, .Lfunc_end0-_Z21valu_fp32_peak_kernelPff
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 1056
; NumSgprs: 14
; NumVgprs: 13
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 3
; NumSGPRsForWavesPerEU: 14
; NumVGPRsForWavesPerEU: 13
; Occupancy: 10
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.text
	.protected	_Z21mmac_fp16_peak_kernelPfDF16_ ; -- Begin function _Z21mmac_fp16_peak_kernelPfDF16_
	.globl	_Z21mmac_fp16_peak_kernelPfDF16_
	.p2align	8
	.type	_Z21mmac_fp16_peak_kernelPfDF16_,@function
_Z21mmac_fp16_peak_kernelPfDF16_:       ; @_Z21mmac_fp16_peak_kernelPfDF16_
; %bb.0:
	s_load_dword s2, s[4:5], 0x8
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v17, 0
	s_movk_i32 s7, 0x1000
	s_mov_b32 s8, 0x3c003c00
	s_waitcnt lgkmcnt(0)
	s_pack_ll_b32_b16 s2, s2, s2
	s_mov_b32 s3, s2
	v_mov_b32_e32 v18, v17
	v_mov_b32_e32 v19, v17
	v_mov_b32_e32 v20, v17
	v_mov_b32_e32 v21, v17
	v_mov_b32_e32 v22, v17
	v_mov_b32_e32 v23, v17
	v_mov_b32_e32 v24, v17
	v_mov_b32_e32 v1, v17
	v_mov_b32_e32 v2, v17
	v_mov_b32_e32 v3, v17
	v_mov_b32_e32 v4, v17
	v_mov_b32_e32 v5, v17
	v_mov_b32_e32 v6, v17
	v_mov_b32_e32 v7, v17
	v_mov_b32_e32 v8, v17
	v_mov_b32_e32 v9, v17
	v_mov_b32_e32 v10, v17
	v_mov_b32_e32 v11, v17
	v_mov_b32_e32 v12, v17
	v_mov_b32_e32 v13, v17
	v_mov_b32_e32 v14, v17
	v_mov_b32_e32 v15, v17
	v_mov_b32_e32 v16, v17
	v_mov_b32_e32 v25, v17
	v_mov_b32_e32 v26, v17
	v_mov_b32_e32 v27, v17
	v_mov_b32_e32 v28, v17
	v_mov_b32_e32 v29, v17
	v_mov_b32_e32 v30, v17
	v_mov_b32_e32 v31, v17
	v_mov_b32_e32 v32, v17
.LBB1_1:                                ; =>This Inner Loop Header: Depth=1
	s_mov_b32 s9, s8
	v_mov_b64_e32 v[33:34], s[2:3]
	v_mov_b64_e32 v[35:36], s[8:9]
	s_nop 1
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	s_add_i32 s7, s7, -8
	v_mmac_f32_16x16x16_f16 v[17:20], v[33:34], v[35:36], v[17:20]
	v_mmac_f32_16x16x16_f16 v[21:24], v[33:34], v[35:36], v[21:24]
	v_mmac_f32_16x16x16_f16 v[29:32], v[33:34], v[35:36], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[33:34], v[35:36], v[25:28]
	v_mmac_f32_16x16x16_f16 v[13:16], v[33:34], v[35:36], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[33:34], v[35:36], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[33:34], v[35:36], v[5:8]
	s_cmp_eq_u32 s7, 0
	v_mmac_f32_16x16x16_f16 v[1:4], v[33:34], v[35:36], v[1:4]
	s_cbranch_scc0 .LBB1_1
; %bb.2:
	s_load_dword s2, s[4:5], 0x1c
	v_pk_add_f32 v[17:18], v[21:22], v[17:18]
	v_pk_add_f32 v[9:10], v[13:14], v[9:10]
	v_pk_add_f32 v[19:20], v[23:24], v[19:20]
	v_pk_add_f32 v[17:18], v[29:30], v[17:18]
	v_pk_add_f32 v[11:12], v[15:16], v[11:12]
	v_pk_add_f32 v[5:6], v[9:10], v[5:6]
	v_pk_add_f32 v[19:20], v[31:32], v[19:20]
	v_pk_add_f32 v[17:18], v[25:26], v[17:18]
	v_pk_add_f32 v[7:8], v[11:12], v[7:8]
	v_pk_add_f32 v[1:2], v[5:6], v[1:2]
	s_waitcnt lgkmcnt(0)
	s_and_b32 s2, s2, 0xffff
	v_pk_add_f32 v[19:20], v[27:28], v[19:20]
	v_pk_add_f32 v[3:4], v[7:8], v[3:4]
	v_pk_add_f32 v[1:2], v[1:2], v[17:18]
	s_mul_i32 s6, s6, s2
	v_pk_add_f32 v[3:4], v[3:4], v[19:20]
	v_add_f32_e32 v1, v1, v2
	v_add_u32_e32 v0, s6, v0
	v_add_f32_e32 v1, v3, v1
	v_add_f32_e32 v2, v4, v1
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[0:1], 2, v[0:1]
	v_mov_b32_e32 v3, s1
	v_add_co_u32_e32 v0, vcc, s0, v0
	v_addc_co_u32_e32 v1, vcc, v3, v1, vcc
	global_store_dword v[0:1], v2, off
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z21mmac_fp16_peak_kernelPfDF16_
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 272
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 37
		.amdhsa_next_free_sgpr 10
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end1:
	.size	_Z21mmac_fp16_peak_kernelPfDF16_, .Lfunc_end1-_Z21mmac_fp16_peak_kernelPfDF16_
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 952
; NumSgprs: 14
; NumVgprs: 37
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 9
; NumSGPRsForWavesPerEU: 14
; NumVGPRsForWavesPerEU: 37
; Occupancy: 6
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.text
	.protected	_Z24mmac_fp16_latency_kernelPfPyDF16_ ; -- Begin function _Z24mmac_fp16_latency_kernelPfPyDF16_
	.globl	_Z24mmac_fp16_latency_kernelPfPyDF16_
	.p2align	8
	.type	_Z24mmac_fp16_latency_kernelPfPyDF16_,@function
_Z24mmac_fp16_latency_kernelPfPyDF16_:  ; @_Z24mmac_fp16_latency_kernelPfPyDF16_
; %bb.0:
	s_load_dword s6, s[4:5], 0x10
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v1, 0
	s_memtime s[4:5]
	s_movk_i32 s10, 0x1000
	s_waitcnt lgkmcnt(0)
	s_pack_ll_b32_b16 s6, s6, s6
	s_mov_b32 s7, s6
	s_mov_b32 s8, 0x3c003c00
	v_mov_b32_e32 v2, v1
	v_mov_b32_e32 v3, v1
	v_mov_b32_e32 v4, v1
.LBB2_1:                                ; =>This Inner Loop Header: Depth=1
	s_mov_b32 s9, s8
	v_mov_b64_e32 v[5:6], s[6:7]
	v_mov_b64_e32 v[7:8], s[8:9]
	s_nop 1
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	s_sub_i32 s10, s10, 32
	s_cmp_eq_u32 s10, 0
	v_mmac_f32_16x16x16_f16 v[1:4], v[5:6], v[7:8], v[1:4]
	s_cbranch_scc0 .LBB2_1
; %bb.2:
	s_memtime s[6:7]
	v_cmp_eq_u32_e32 vcc, 0, v0
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB2_4
; %bb.3:
	v_mov_b32_e32 v2, 0
	global_store_dword v2, v1, s[0:1]
	s_waitcnt lgkmcnt(0)
	s_sub_u32 s0, s6, s4
	s_subb_u32 s1, s7, s5
	v_mov_b64_e32 v[0:1], s[0:1]
	global_store_dwordx2 v2, v[0:1], s[2:3]
.LBB2_4:
	s_endpgm
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel _Z24mmac_fp16_latency_kernelPfPyDF16_
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 20
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 9
		.amdhsa_next_free_sgpr 11
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end2:
	.size	_Z24mmac_fp16_latency_kernelPfPyDF16_, .Lfunc_end2-_Z24mmac_fp16_latency_kernelPfPyDF16_
                                        ; -- End function
	.section	.AMDGPU.csdata
; Kernel info:
; codeLenInByte = 408
; NumSgprs: 15
; NumVgprs: 9
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 2
; NumSGPRsForWavesPerEU: 15
; NumVGPRsForWavesPerEU: 9
; Occupancy: 10
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
	.ident	"clang version 17.0.0"
	.section	".note.GNU-stack"
	.addrsig
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .actual_access:  write_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .offset:         8
        .size:           4
        .value_kind:     by_value
      - .offset:         16
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         20
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         24
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         28
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         30
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         32
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         34
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         36
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         38
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         56
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         64
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         72
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         80
        .size:           2
        .value_kind:     hidden_grid_dims
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 272
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z21valu_fp32_peak_kernelPff
    .private_segment_fixed_size: 0
    .sgpr_count:     14
    .sgpr_spill_count: 0
    .symbol:         _Z21valu_fp32_peak_kernelPff.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     13
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  write_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .offset:         8
        .size:           2
        .value_kind:     by_value
      - .offset:         16
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         20
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         24
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         28
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         30
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         32
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         34
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         36
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         38
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         56
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         64
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         72
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         80
        .size:           2
        .value_kind:     hidden_grid_dims
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 272
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z21mmac_fp16_peak_kernelPfDF16_
    .private_segment_fixed_size: 0
    .sgpr_count:     14
    .sgpr_spill_count: 0
    .symbol:         _Z21mmac_fp16_peak_kernelPfDF16_.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     37
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .actual_access:  write_only
        .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .actual_access:  write_only
        .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .offset:         16
        .size:           2
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 20
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 256
    .name:           _Z24mmac_fp16_latency_kernelPfPyDF16_
    .private_segment_fixed_size: 0
    .sgpr_count:     15
    .sgpr_spill_count: 0
    .symbol:         _Z24mmac_fp16_latency_kernelPfPyDF16_.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     9
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   'amdgcn-amd-amdhsa--gfx936:sramecc+'
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
