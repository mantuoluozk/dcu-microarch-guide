	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936"
	.globl	gemm_kernel
	.p2align	8
	.type	gemm_kernel,@function
gemm_kernel:
.Lfunc_begin0:
	.file	1 "experiments/advanced" "08_triton_gemm_mmac.py"
	.loc	1 18 0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_escape 0x0f, 0x03, 0x30, 0x36, 0xe1
	.cfi_undefined 16
	.file	2 "/usr/local/lib/python3.11/site-packages/triton/language" "standard.py"
	.loc	2 40 22 prologue_end
	s_load_dwordx4 s[8:11], s[4:5], 0x18
	s_load_dwordx2 s[12:13], s[4:5], 0x28
.Ltmp0:
	.loc	1 39 46
	v_and_b32_e32 v28, 63, v0
	v_lshrrev_b32_e32 v92, 6, v0
	v_lshlrev_b32_e32 v29, 3, v0
.Ltmp1:
	.loc	2 40 22
	s_waitcnt lgkmcnt(0)
	s_add_i32 s1, s9, 0x7f
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s2, s1, 31
	s_lshr_b32 s2, s2, 25
	s_add_i32 s1, s1, s2
	s_ashr_i32 s2, s1, 7
.Ltmp2:
	.loc	1 32 33 is_stmt 1
	s_lshl_b32 s7, s2, 3
	.loc	1 33 22
	s_ashr_i32 s1, s1, 31
	s_add_i32 s2, s7, s1
	s_xor_b32 s2, s2, s1
	v_cvt_f32_u32_e32 v1, s2
.Ltmp3:
	.loc	2 40 22
	s_add_i32 s0, s8, 0x7f
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s3, s0, 31
	s_lshr_b32 s3, s3, 25
.Ltmp4:
	.loc	1 33 22 is_stmt 1
	v_rcp_iflag_f32_e32 v1, v1
.Ltmp5:
	.loc	2 40 28
	s_add_i32 s0, s0, s3
.Ltmp6:
	.loc	1 33 22
	s_ashr_i32 s3, s6, 31
	s_add_i32 s14, s6, s3
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_xor_b32 s1, s3, s1
	s_xor_b32 s3, s14, s3
	s_sub_i32 s14, 0, s2
	v_readfirstlane_b32 s15, v1
	s_mul_i32 s14, s14, s15
	s_mul_hi_u32 s14, s15, s14
	s_add_i32 s15, s15, s14
	s_mul_hi_u32 s14, s3, s15
	s_mul_i32 s15, s14, s2
	s_sub_i32 s3, s3, s15
.Ltmp7:
	.loc	2 40 28
	s_ashr_i32 s0, s0, 7
.Ltmp8:
	.loc	1 33 22
	s_add_i32 s15, s14, 1
	s_sub_i32 s16, s3, s2
	s_cmp_ge_u32 s3, s2
	s_cselect_b32 s14, s15, s14
	s_cselect_b32 s3, s16, s3
	s_add_i32 s15, s14, 1
	s_cmp_ge_u32 s3, s2
	s_cselect_b32 s2, s15, s14
	s_xor_b32 s2, s2, s1
	s_sub_i32 s16, s2, s1
	.loc	1 34 29
	s_lshl_b32 s18, s16, 3
	.loc	1 35 35
	s_sub_i32 s0, s0, s18
	.loc	1 35 48 is_stmt 0
	s_min_i32 s19, s0, 8
	.loc	1 37 40 is_stmt 1
	s_ashr_i32 s20, s19, 31
	s_add_i32 s0, s19, s20
	s_xor_b32 s21, s0, s20
	v_cvt_f32_u32_e32 v1, s21
	.loc	1 36 34
	s_mul_i32 s16, s16, s7
.Ltmp9:
	.loc	2 40 22
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	s_load_dwordx2 s[14:15], s[4:5], 0x10
.Ltmp10:
	.loc	1 36 34
	s_sub_i32 s4, s6, s16
	.loc	1 37 40
	v_rcp_iflag_f32_e32 v1, v1
	s_ashr_i32 s5, s4, 31
	s_add_i32 s7, s4, s5
	s_xor_b32 s6, s5, s20
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_xor_b32 s5, s7, s5
	s_sub_i32 s7, 0, s21
	s_mov_b32 s17, 0
	v_readfirstlane_b32 s16, v1
	s_mul_i32 s7, s7, s16
	s_mul_hi_u32 s7, s16, s7
	s_add_i32 s16, s16, s7
	s_mul_hi_u32 s7, s5, s16
	s_mul_i32 s16, s7, s21
	s_sub_i32 s5, s5, s16
	s_add_i32 s16, s7, 1
	s_sub_i32 s20, s5, s21
	s_cmp_ge_u32 s5, s21
	s_cselect_b32 s7, s16, s7
	s_cselect_b32 s5, s20, s5
	s_add_i32 s16, s7, 1
	s_cmp_ge_u32 s5, s21
	s_cselect_b32 s5, s16, s7
	s_xor_b32 s5, s5, s6
	s_sub_i32 s5, s5, s6
	.loc	1 36 54
	s_mul_i32 s19, s19, s5
	s_add_i32 s4, s4, s18
	.loc	1 36 27 is_stmt 0
	s_sub_i32 s6, s4, s19
	.loc	1 40 23 is_stmt 1
	s_lshl_b32 s16, s5, 7
.Ltmp11:
	.loc	2 40 22 is_stmt 0
	s_add_i32 s7, s10, 31
.Ltmp12:
	.loc	1 39 46 is_stmt 1
	v_lshrrev_b32_e32 v90, 4, v0
	v_and_b32_e32 v80, 0x78, v29
	.loc	1 47 22
	s_cmp_gt_i32 s7, 31
	v_lshrrev_b32_e32 v1, 3, v0
	v_lshlrev_b32_e32 v2, 4, v92
	v_lshrrev_b32_e32 v94, 4, v28
	v_and_b32_e32 v95, 15, v0
	s_cbranch_scc1 .LBB0_2
	.loc	1 59 21
	v_and_b32_e32 v97, 16, v2
	v_and_or_b32 v96, v1, 16, v95
	s_mov_b64 s[4:5], 0
	s_branch .LBB0_3
.LBB0_2:
	.loc	1 0 21 is_stmt 0
	s_mov_b64 s[4:5], -1
.LBB0_3:
	s_lshl_b32 s20, s6, 7
	v_or_b32_e32 v91, 16, v90
	v_or_b32_e32 v93, s16, v80
	.loc	1 47 22 is_stmt 1
	s_andn2_b64 vcc, exec, s[4:5]
	v_mov_b32_e32 v1, s17
	v_mov_b32_e32 v2, s17
	v_mov_b32_e32 v3, s17
	v_mov_b32_e32 v4, s17
	v_mov_b32_e32 v5, s17
	v_mov_b32_e32 v6, s17
	v_mov_b32_e32 v7, s17
	v_mov_b32_e32 v36, s17
	v_mov_b32_e32 v37, s17
	v_mov_b32_e32 v38, s17
	v_mov_b32_e32 v39, s17
	v_mov_b32_e32 v40, s17
	v_mov_b32_e32 v41, s17
	v_mov_b32_e32 v42, s17
	v_mov_b32_e32 v43, s17
	v_mov_b32_e32 v44, s17
	v_mov_b32_e32 v8, s17
	v_mov_b32_e32 v9, s17
	v_mov_b32_e32 v10, s17
	v_mov_b32_e32 v11, s17
	v_mov_b32_e32 v12, s17
	v_mov_b32_e32 v13, s17
	v_mov_b32_e32 v14, s17
	v_mov_b32_e32 v15, s17
	v_mov_b32_e32 v45, s17
	v_mov_b32_e32 v46, s17
	v_mov_b32_e32 v47, s17
	v_mov_b32_e32 v52, s17
	v_mov_b32_e32 v53, s17
	v_mov_b32_e32 v54, s17
	v_mov_b32_e32 v55, s17
	v_mov_b32_e32 v60, s17
	v_mov_b32_e32 v16, s17
	v_mov_b32_e32 v17, s17
	v_mov_b32_e32 v18, s17
	v_mov_b32_e32 v19, s17
	v_mov_b32_e32 v20, s17
	v_mov_b32_e32 v21, s17
	v_mov_b32_e32 v22, s17
	v_mov_b32_e32 v23, s17
	v_mov_b32_e32 v61, s17
	v_mov_b32_e32 v62, s17
	v_mov_b32_e32 v63, s17
	v_mov_b32_e32 v64, s17
	v_mov_b32_e32 v65, s17
	v_mov_b32_e32 v66, s17
	v_mov_b32_e32 v67, s17
	v_mov_b32_e32 v68, s17
	v_mov_b32_e32 v24, s17
	v_mov_b32_e32 v25, s17
	v_mov_b32_e32 v26, s17
	v_mov_b32_e32 v27, s17
	v_mov_b32_e32 v69, s17
	v_mov_b32_e32 v70, s17
	v_mov_b32_e32 v71, s17
	v_mov_b32_e32 v72, s17
	v_mov_b32_e32 v73, s17
	v_mov_b32_e32 v74, s17
	v_mov_b32_e32 v75, s17
	v_mov_b32_e32 v76, s17
	v_mov_b32_e32 v77, s17
	v_mov_b32_e32 v78, s17
	v_mov_b32_e32 v79, s17
	v_mov_b32_e32 v81, s17
	s_cbranch_vccnz .LBB0_15
	.loc	1 40 58
	s_ashr_i32 s4, s9, 31
	s_add_i32 s5, s9, s4
	s_xor_b32 s5, s5, s4
	v_cvt_f32_u32_e32 v1, s5
	.loc	1 39 58
	s_ashr_i32 s18, s8, 31
	.loc	1 40 58
	s_sub_i32 s19, 0, s5
	v_ashrrev_i32_e32 v2, 31, v93
	v_rcp_iflag_f32_e32 v1, v1
.Ltmp13:
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s17, s7, 31
.Ltmp14:
	.loc	1 40 58
	v_add_u32_e32 v5, v93, v2
.Ltmp15:
	.loc	2 40 28
	s_lshr_b32 s17, s17, 27
.Ltmp16:
	.loc	1 40 58
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	v_xor_b32_e32 v5, v5, v2
.Ltmp17:
	.loc	2 40 28
	s_add_i32 s7, s7, s17
	s_ashr_i32 s17, s7, 5
.Ltmp18:
	.loc	1 40 58
	v_mul_lo_u32 v3, s19, v1
	.loc	1 39 58 is_stmt 1
	s_add_i32 s19, s8, s18
	s_xor_b32 s21, s19, s18
	v_cvt_f32_u32_e32 v4, s21
	.loc	1 40 58
	v_mul_hi_u32 v3, v1, v3
	.loc	1 39 58
	s_sub_i32 s7, 0, s21
	.loc	1 39 46 is_stmt 0
	v_lshrrev_b32_e32 v10, 2, v0
	.loc	1 39 58
	v_rcp_iflag_f32_e32 v4, v4
	.loc	1 40 58 is_stmt 1
	v_add_u32_e32 v1, v1, v3
	v_mul_hi_u32 v1, v5, v1
	.loc	1 39 46
	v_or_b32_e32 v6, s20, v10
	.loc	1 39 58 is_stmt 0
	v_mul_f32_e32 v3, 0x4f7ffffe, v4
	v_cvt_u32_f32_e32 v3, v3
	.loc	1 40 58 is_stmt 1
	v_mul_lo_u32 v1, v1, s5
	.loc	1 39 46
	v_and_b32_e32 v81, 24, v29
	v_lshlrev_b32_e32 v10, 5, v10
	.loc	1 39 58 is_stmt 0
	v_mul_lo_u32 v4, s7, v3
	s_ashr_i32 s7, s20, 31
	.loc	1 40 58 is_stmt 1
	v_sub_u32_e32 v1, v5, v1
	.loc	1 39 58
	v_add_u32_e32 v6, s7, v6
	v_mul_hi_u32 v4, v3, v4
	.loc	1 40 58
	v_subrev_u32_e32 v5, s5, v1
	v_cmp_le_u32_e32 vcc, s5, v1
	.loc	1 39 58
	v_add_u32_e32 v7, 64, v6
	.loc	1 40 58
	v_cndmask_b32_e32 v1, v1, v5, vcc
	.loc	1 39 58
	v_xor_b32_e32 v7, s7, v7
	v_add_u32_e32 v4, v3, v4
	.loc	1 40 58
	v_subrev_u32_e32 v5, s5, v1
	.loc	1 39 58
	v_mul_hi_u32 v3, v7, v4
	.loc	1 40 58
	v_cmp_le_u32_e32 vcc, s5, v1
	v_cndmask_b32_e32 v1, v1, v5, vcc
	v_xor_b32_e32 v1, v1, v2
	v_sub_u32_e32 v1, v1, v2
	.loc	1 39 58
	v_mul_lo_u32 v5, v3, s21
	.loc	1 44 51
	v_mad_u64_u32 v[2:3], s[18:19], v90, s12, v[1:2]
	.loc	1 39 58
	v_xor_b32_e32 v6, s7, v6
	v_mul_hi_u32 v4, v6, v4
	.loc	1 44 51
	v_mad_u64_u32 v[8:9], s[18:19], v91, s12, v[1:2]
	v_lshrrev_b32_e32 v1, 1, v0
	v_and_or_b32 v11, v1, 4, v81
	v_and_b32_e32 v12, 24, v1
	v_xor_b32_e32 v11, v11, v12
	.loc	1 39 58
	v_mul_lo_u32 v4, v4, s21
	v_or_b32_e32 v11, v11, v10
	v_sub_u32_e32 v3, v7, v5
	v_lshl_add_u32 v98, v11, 1, 0
	v_or_b32_e32 v11, 4, v81
	v_and_b32_e32 v1, 28, v1
	v_subrev_u32_e32 v5, s21, v3
	v_cmp_le_u32_e32 vcc, s21, v3
	v_xor_b32_e32 v1, v11, v1
	v_cndmask_b32_e32 v3, v3, v5, vcc
	v_or_b32_e32 v1, v1, v10
	v_subrev_u32_e32 v5, s21, v3
	v_cmp_le_u32_e32 vcc, s21, v3
	v_sub_u32_e32 v4, v6, v4
	v_lshl_add_u32 v99, v1, 1, 0
	v_lshrrev_b32_e32 v1, 3, v0
	v_and_b32_e32 v95, 15, v0
	v_lshrrev_b32_e32 v94, 4, v28
	v_cndmask_b32_e32 v3, v3, v5, vcc
	v_subrev_u32_e32 v5, s21, v4
	v_cmp_le_u32_e32 vcc, s21, v4
	v_and_or_b32 v96, v1, 16, v95
	v_bfe_u32 v0, v0, 1, 3
	v_or_b32_e32 v10, 4, v94
	v_xor_b32_e32 v3, s7, v3
	v_cndmask_b32_e32 v4, v4, v5, vcc
	v_xor_b32_e32 v1, v94, v0
	v_xor_b32_e32 v0, v10, v0
	v_lshlrev_b32_e32 v10, 6, v96
	v_subrev_u32_e32 v3, s7, v3
	v_subrev_u32_e32 v5, s21, v4
	v_cmp_le_u32_e32 vcc, s21, v4
	v_lshl_or_b32 v0, v0, 3, v10
	v_cndmask_b32_e32 v4, v4, v5, vcc
	.loc	1 43 52
	v_mad_u64_u32 v[6:7], s[18:19], v3, s11, v[81:82]
	v_add_u32_e32 v101, 0, v0
	v_lshlrev_b32_e32 v0, 1, v80
	.loc	1 39 58
	v_xor_b32_e32 v4, s7, v4
	v_lshl_or_b32 v0, v90, 8, v0
	v_subrev_u32_e32 v4, s7, v4
	v_add_u32_e32 v102, 0, v0
	v_lshlrev_b32_e32 v0, 4, v92
	.loc	1 43 52
	v_mad_u64_u32 v[4:5], s[18:19], v4, s11, v[81:82]
	v_and_b32_e32 v97, 16, v0
	v_lshlrev_b32_e32 v0, 9, v94
	v_ashrrev_i32_e32 v7, 31, v6
	v_lshl_or_b32 v1, v1, 3, v10
	v_or3_b32 v0, v0, v95, v97
	v_add_u32_e32 v100, 0, v1
	v_lshl_add_u32 v103, v0, 1, 0
	.loc	1 47 22
	v_lshlrev_b64 v[0:1], 1, v[6:7]
	v_ashrrev_i32_e32 v3, 31, v2
	v_ashrrev_i32_e32 v5, 31, v4
	v_lshlrev_b64 v[84:85], 1, v[2:3]
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v2, s1
	v_add_co_u32_e32 v86, vcc, s0, v0
	v_addc_co_u32_e32 v87, vcc, v2, v1, vcc
	v_lshlrev_b64 v[0:1], 1, v[4:5]
	.loc	1 52 28
	s_lshl_b32 s6, s12, 5
	v_ashrrev_i32_e32 v9, 31, v8
	s_ashr_i32 s7, s6, 31
	.loc	1 47 22
	v_lshlrev_b64 v[82:83], 1, v[8:9]
	v_add_co_u32_e32 v88, vcc, s0, v0
	v_mov_b32_e32 v0, 0
	s_mov_b32 s4, 0
	v_addc_co_u32_e32 v89, vcc, v2, v1, vcc
	s_mov_b32 s11, 0x5040100
	s_lshl_b64 s[0:1], s[6:7], 1
	v_mov_b32_e32 v1, v0
	v_mov_b32_e32 v2, v0
	v_mov_b32_e32 v3, v0
	v_mov_b32_e32 v44, v0
	v_mov_b32_e32 v45, v0
	v_mov_b32_e32 v46, v0
	v_mov_b32_e32 v47, v0
	v_mov_b32_e32 v24, v0
	v_mov_b32_e32 v25, v0
	v_mov_b32_e32 v26, v0
	v_mov_b32_e32 v27, v0
	v_mov_b32_e32 v20, v0
	v_mov_b32_e32 v21, v0
	v_mov_b32_e32 v22, v0
	v_mov_b32_e32 v23, v0
	v_mov_b32_e32 v60, v0
	v_mov_b32_e32 v61, v0
	v_mov_b32_e32 v62, v0
	v_mov_b32_e32 v63, v0
	v_mov_b32_e32 v16, v0
	v_mov_b32_e32 v17, v0
	v_mov_b32_e32 v18, v0
	v_mov_b32_e32 v19, v0
	v_mov_b32_e32 v52, v0
	v_mov_b32_e32 v53, v0
	v_mov_b32_e32 v54, v0
	v_mov_b32_e32 v55, v0
	v_mov_b32_e32 v12, v0
	v_mov_b32_e32 v13, v0
	v_mov_b32_e32 v14, v0
	v_mov_b32_e32 v15, v0
	v_mov_b32_e32 v40, v0
	v_mov_b32_e32 v41, v0
	v_mov_b32_e32 v42, v0
	v_mov_b32_e32 v43, v0
	v_mov_b32_e32 v8, v0
	v_mov_b32_e32 v9, v0
	v_mov_b32_e32 v10, v0
	v_mov_b32_e32 v11, v0
	v_mov_b32_e32 v4, v0
	v_mov_b32_e32 v5, v0
	v_mov_b32_e32 v6, v0
	v_mov_b32_e32 v7, v0
	v_mov_b32_e32 v56, v0
	v_mov_b32_e32 v57, v0
	v_mov_b32_e32 v58, v0
	v_mov_b32_e32 v59, v0
	v_mov_b32_e32 v36, v0
	v_mov_b32_e32 v37, v0
	v_mov_b32_e32 v38, v0
	v_mov_b32_e32 v39, v0
	v_mov_b32_e32 v48, v0
	v_mov_b32_e32 v49, v0
	v_mov_b32_e32 v50, v0
	v_mov_b32_e32 v51, v0
	v_mov_b32_e32 v32, v0
	v_mov_b32_e32 v33, v0
	v_mov_b32_e32 v34, v0
	v_mov_b32_e32 v35, v0
	v_mov_b32_e32 v28, v0
	v_mov_b32_e32 v29, v0
	v_mov_b32_e32 v30, v0
	v_mov_b32_e32 v31, v0
	v_add_u32_e32 v104, 0x1000, v103
	v_add_u32_e32 v105, 64, v103
	v_add_u32_e32 v106, 0x1040, v103
	v_add_u32_e32 v107, 0x80, v103
	v_add_u32_e32 v108, 0x1080, v103
	v_add_u32_e32 v109, 0xc0, v103
	v_add_u32_e32 v110, 0x10c0, v103
	s_branch .LBB0_6
.LBB0_5:
	.loc	1 0 22 is_stmt 0
	s_or_b64 exec, exec, s[6:7]
	.loc	1 48 20 is_stmt 1
	s_waitcnt vmcnt(0)
	s_barrier
	ds_write_b64 v98, v[64:65]
	ds_write_b64 v98, v[68:69] offset:4096
	ds_write2st64_b64 v99, v[66:67], v[70:71] offset1:8
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	ds_read2st64_b64 v[64:67], v100 offset1:4
	ds_read2st64_b64 v[68:71], v101 offset1:4
	ds_read2st64_b64 v[111:114], v100 offset0:8 offset1:12
	ds_read2st64_b64 v[115:118], v101 offset0:8 offset1:12
	.loc	1 49 20
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	ds_write_b128 v102, v[72:75]
	ds_write_b128 v102, v[76:79] offset:4096
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	ds_read_u16 v72, v103 offset:512
	ds_read_u16 v73, v103 offset:768
	ds_read_u16 v74, v103 offset:4096
	ds_read_u16 v75, v104 offset:512
	ds_read_u16 v76, v104 offset:768
	ds_read_u16 v78, v105 offset:256
	ds_read_u16 v77, v105 offset:512
	ds_read_u16 v79, v103
	ds_read_u16 v119, v103 offset:64
	ds_read_u16 v121, v103 offset:128
	ds_read_u16 v120, v103 offset:4160
	ds_read_u16 v123, v103 offset:4224
	ds_read_u16 v122, v105 offset:768
	ds_read_u16 v124, v106 offset:256
	ds_read_u16 v125, v106 offset:512
	ds_read_u16 v126, v106 offset:768
	ds_read_u16 v127, v107 offset:256
	ds_read_u16 v128, v107 offset:512
	ds_read_u16 v129, v107 offset:768
	ds_read_u16 v130, v108 offset:256
	ds_read_u16 v131, v103 offset:256
	ds_read_u16 v132, v103 offset:192
	ds_read_u16 v133, v104 offset:256
	ds_read_u16 v134, v103 offset:4288
	ds_read_u16 v135, v108 offset:512
	ds_read_u16 v136, v108 offset:768
	ds_read_u16 v137, v109 offset:256
	ds_read_u16 v138, v109 offset:512
	ds_read_u16 v139, v109 offset:768
	ds_read_u16 v140, v110 offset:256
	ds_read_u16 v141, v110 offset:512
	ds_read_u16 v142, v110 offset:768
	.loc	1 50 27
	s_waitcnt lgkmcnt(14)
	v_perm_b32 v73, v73, v72, s11
	s_waitcnt lgkmcnt(11)
	v_perm_b32 v72, v131, v79, s11
	v_perm_b32 v75, v76, v75, s11
	s_waitcnt lgkmcnt(9)
	v_perm_b32 v74, v133, v74, s11
	v_perm_b32 v77, v122, v77, s11
	v_perm_b32 v76, v78, v119, s11
	v_perm_b32 v79, v126, v125, s11
	v_perm_b32 v78, v124, v120, s11
	v_perm_b32 v120, v129, v128, s11
	v_perm_b32 v119, v127, v121, s11
	s_waitcnt lgkmcnt(6)
	v_perm_b32 v122, v136, v135, s11
	v_perm_b32 v121, v130, v123, s11
	s_waitcnt lgkmcnt(3)
	v_perm_b32 v124, v139, v138, s11
	v_perm_b32 v123, v137, v132, s11
	s_waitcnt lgkmcnt(0)
	v_perm_b32 v126, v142, v141, s11
	v_perm_b32 v125, v140, v134, s11
	s_setprio 1
	v_mmac_f32_16x16x16_f16 v[0:3], v[64:65], v[72:73], v[0:3]
	v_mmac_f32_16x16x16_f16 v[44:47], v[64:65], v[76:77], v[44:47]
	v_mmac_f32_16x16x16_f16 v[24:27], v[64:65], v[119:120], v[24:27]
	v_mmac_f32_16x16x16_f16 v[20:23], v[64:65], v[123:124], v[20:23]
	v_mmac_f32_16x16x16_f16 v[60:63], v[66:67], v[72:73], v[60:63]
	v_mmac_f32_16x16x16_f16 v[16:19], v[66:67], v[76:77], v[16:19]
	v_mmac_f32_16x16x16_f16 v[52:55], v[66:67], v[119:120], v[52:55]
	v_mmac_f32_16x16x16_f16 v[12:15], v[66:67], v[123:124], v[12:15]
	v_mmac_f32_16x16x16_f16 v[40:43], v[111:112], v[72:73], v[40:43]
	v_mmac_f32_16x16x16_f16 v[8:11], v[111:112], v[76:77], v[8:11]
	v_mmac_f32_16x16x16_f16 v[4:7], v[111:112], v[119:120], v[4:7]
	v_mmac_f32_16x16x16_f16 v[56:59], v[111:112], v[123:124], v[56:59]
	v_mmac_f32_16x16x16_f16 v[36:39], v[113:114], v[72:73], v[36:39]
	v_mmac_f32_16x16x16_f16 v[48:51], v[113:114], v[76:77], v[48:51]
	v_mmac_f32_16x16x16_f16 v[32:35], v[113:114], v[119:120], v[32:35]
	v_mmac_f32_16x16x16_f16 v[28:31], v[113:114], v[123:124], v[28:31]
	v_mmac_f32_16x16x16_f16 v[0:3], v[68:69], v[74:75], v[0:3]
	v_mmac_f32_16x16x16_f16 v[44:47], v[68:69], v[78:79], v[44:47]
	v_mmac_f32_16x16x16_f16 v[24:27], v[68:69], v[121:122], v[24:27]
	v_mmac_f32_16x16x16_f16 v[20:23], v[68:69], v[125:126], v[20:23]
	v_mmac_f32_16x16x16_f16 v[60:63], v[70:71], v[74:75], v[60:63]
	v_mmac_f32_16x16x16_f16 v[16:19], v[70:71], v[78:79], v[16:19]
	v_mmac_f32_16x16x16_f16 v[52:55], v[70:71], v[121:122], v[52:55]
	v_mmac_f32_16x16x16_f16 v[12:15], v[70:71], v[125:126], v[12:15]
	v_mmac_f32_16x16x16_f16 v[40:43], v[115:116], v[74:75], v[40:43]
	v_mmac_f32_16x16x16_f16 v[8:11], v[115:116], v[78:79], v[8:11]
	v_mmac_f32_16x16x16_f16 v[4:7], v[115:116], v[121:122], v[4:7]
	v_mmac_f32_16x16x16_f16 v[56:59], v[115:116], v[125:126], v[56:59]
	v_mmac_f32_16x16x16_f16 v[36:39], v[117:118], v[74:75], v[36:39]
	v_mmac_f32_16x16x16_f16 v[48:51], v[117:118], v[78:79], v[48:51]
	v_mmac_f32_16x16x16_f16 v[32:35], v[117:118], v[121:122], v[32:35]
	v_mmac_f32_16x16x16_f16 v[28:31], v[117:118], v[125:126], v[28:31]
	s_setprio 0
	.loc	1 52 18
	s_add_u32 s2, s2, s0
	s_addc_u32 s3, s3, s1
	.loc	1 47 22
	v_add_co_u32_e32 v86, vcc, 64, v86
	v_addc_co_u32_e32 v87, vcc, 0, v87, vcc
	s_add_i32 s17, s17, -1
	s_sub_i32 s10, s10, 32
	v_add_co_u32_e32 v88, vcc, 64, v88
	s_cmp_lg_u32 s17, 0
	v_addc_co_u32_e32 v89, vcc, 0, v89, vcc
	s_cbranch_scc0 .LBB0_14
.LBB0_6:
	.loc	1 0 22 is_stmt 0
	s_mov_b32 s6, s4
	s_mov_b32 s7, s4
	s_mov_b32 s5, s4
	.loc	1 48 20 is_stmt 1
	v_mov_b64_e32 v[66:67], s[6:7]
	.loc	1 48 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s10, v81
	.loc	1 48 20
	v_mov_b64_e32 v[64:65], s[4:5]
	s_and_saveexec_b64 s[18:19], vcc
	s_cbranch_execz .LBB0_8
	global_load_dwordx4 v[64:67], v[88:89], off
.LBB0_8:
	.loc	1 0 20
	s_or_b64 exec, exec, s[18:19]
	.loc	1 48 20
	v_mov_b64_e32 v[70:71], s[6:7]
	v_mov_b64_e32 v[68:69], s[4:5]
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_10
	global_load_dwordx4 v[68:71], v[86:87], off
.LBB0_10:
	.loc	1 0 20
	s_or_b64 exec, exec, s[6:7]
	s_mov_b32 s6, s4
	s_mov_b32 s7, s4
	s_mov_b32 s5, s4
	.loc	1 49 20 is_stmt 1
	v_mov_b64_e32 v[74:75], s[6:7]
	.loc	1 49 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s10, v90
	.loc	1 49 20
	v_mov_b64_e32 v[72:73], s[4:5]
	s_and_saveexec_b64 s[18:19], vcc
	s_cbranch_execz .LBB0_12
	v_mov_b32_e32 v73, s3
	v_add_co_u32_e32 v72, vcc, s2, v84
	v_addc_co_u32_e32 v73, vcc, v73, v85, vcc
	global_load_dwordx4 v[72:75], v[72:73], off
.LBB0_12:
	.loc	1 0 20
	s_or_b64 exec, exec, s[18:19]
	.loc	1 49 20
	v_mov_b64_e32 v[78:79], s[6:7]
	.loc	1 49 51
	v_cmp_gt_i32_e32 vcc, s10, v91
	.loc	1 49 20
	v_mov_b64_e32 v[76:77], s[4:5]
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_5
	v_mov_b32_e32 v77, s3
	v_add_co_u32_e32 v76, vcc, s2, v82
	v_addc_co_u32_e32 v77, vcc, v77, v83, vcc
	global_load_dwordx4 v[76:79], v[76:77], off
	s_branch .LBB0_5
.LBB0_14:
	.loc	1 54 15 is_stmt 1
	v_cvt_f16_f32_e32 v81, v0
	v_cvt_f16_f32_e32 v79, v1
	v_cvt_f16_f32_e32 v78, v2
	v_cvt_f16_f32_e32 v77, v3
	v_cvt_f16_f32_e32 v76, v44
	v_cvt_f16_f32_e32 v75, v45
	v_cvt_f16_f32_e32 v74, v46
	v_cvt_f16_f32_e32 v73, v47
	v_cvt_f16_f32_e32 v72, v24
	v_cvt_f16_f32_e32 v71, v25
	v_cvt_f16_f32_e32 v70, v26
	v_cvt_f16_f32_e32 v69, v27
	v_cvt_f16_f32_e32 v27, v20
	v_cvt_f16_f32_e32 v26, v21
	v_cvt_f16_f32_e32 v25, v22
	v_cvt_f16_f32_e32 v24, v23
	v_cvt_f16_f32_e32 v68, v60
	v_cvt_f16_f32_e32 v67, v61
	v_cvt_f16_f32_e32 v66, v62
	v_cvt_f16_f32_e32 v65, v63
	v_cvt_f16_f32_e32 v64, v16
	v_cvt_f16_f32_e32 v63, v17
	v_cvt_f16_f32_e32 v62, v18
	v_cvt_f16_f32_e32 v61, v19
	v_cvt_f16_f32_e32 v23, v52
	v_cvt_f16_f32_e32 v22, v53
	v_cvt_f16_f32_e32 v21, v54
	v_cvt_f16_f32_e32 v20, v55
	v_cvt_f16_f32_e32 v19, v12
	v_cvt_f16_f32_e32 v18, v13
	v_cvt_f16_f32_e32 v17, v14
	v_cvt_f16_f32_e32 v16, v15
	v_cvt_f16_f32_e32 v60, v40
	v_cvt_f16_f32_e32 v55, v41
	v_cvt_f16_f32_e32 v54, v42
	v_cvt_f16_f32_e32 v53, v43
	v_cvt_f16_f32_e32 v52, v8
	v_cvt_f16_f32_e32 v47, v9
	v_cvt_f16_f32_e32 v46, v10
	v_cvt_f16_f32_e32 v45, v11
	v_cvt_f16_f32_e32 v15, v4
	v_cvt_f16_f32_e32 v14, v5
	v_cvt_f16_f32_e32 v13, v6
	v_cvt_f16_f32_e32 v12, v7
	v_cvt_f16_f32_e32 v11, v56
	v_cvt_f16_f32_e32 v10, v57
	v_cvt_f16_f32_e32 v9, v58
	v_cvt_f16_f32_e32 v8, v59
	v_cvt_f16_f32_e32 v44, v36
	v_cvt_f16_f32_e32 v43, v37
	v_cvt_f16_f32_e32 v42, v38
	v_cvt_f16_f32_e32 v41, v39
	v_cvt_f16_f32_e32 v40, v48
	v_cvt_f16_f32_e32 v39, v49
	v_cvt_f16_f32_e32 v38, v50
	v_cvt_f16_f32_e32 v37, v51
	v_cvt_f16_f32_e32 v36, v32
	v_cvt_f16_f32_e32 v7, v33
	v_cvt_f16_f32_e32 v6, v34
	v_cvt_f16_f32_e32 v5, v35
	v_cvt_f16_f32_e32 v4, v28
	v_cvt_f16_f32_e32 v3, v29
	v_cvt_f16_f32_e32 v2, v30
	v_cvt_f16_f32_e32 v1, v31
.LBB0_15:
	.loc	1 57 21
	s_waitcnt lgkmcnt(0)
	s_mul_i32 s0, s20, s13
	s_ashr_i32 s1, s0, 31
	s_lshl_b64 s[0:1], s[0:1], 1
	s_add_u32 s2, s14, s0
	s_addc_u32 s3, s15, s1
	.loc	1 57 52 is_stmt 0
	s_ashr_i32 s17, s16, 31
	s_lshl_b64 s[0:1], s[16:17], 1
	s_add_u32 s4, s2, s0
	.loc	1 39 33 is_stmt 1
	v_or_b32_e32 v0, s20, v90
	.loc	1 57 52
	s_addc_u32 s5, s3, s1
	v_mad_u64_u32 v[32:33], s[0:1], v90, s13, v[80:81]
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v0
	.loc	1 59 21
	v_or_b32_e32 v0, v97, v94
	s_movk_i32 s2, 0x88
	v_mad_i32_i24 v0, v96, s2, v0
	.loc	1 58 58
	v_cmp_gt_i32_e32 vcc, s9, v93
	.loc	1 59 21
	v_lshl_add_u32 v0, v0, 1, 0
	.loc	1 58 39
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_waitcnt lgkmcnt(0)
	ds_write_b16 v0, v81
	ds_write_b16 v0, v79 offset:8
	ds_write_b16 v0, v78 offset:16
	ds_write_b16 v0, v77 offset:24
	ds_write_b16 v0, v76 offset:64
	ds_write_b16 v0, v75 offset:72
	ds_write_b16 v0, v74 offset:80
	ds_write_b16 v0, v73 offset:88
	ds_write_b16 v0, v72 offset:128
	ds_write_b16 v0, v71 offset:136
	ds_write_b16 v0, v70 offset:144
	ds_write_b16 v0, v69 offset:152
	ds_write_b16 v0, v27 offset:192
	ds_write_b16 v0, v26 offset:200
	ds_write_b16 v0, v25 offset:208
	ds_write_b16 v0, v24 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	v_lshl_add_u32 v24, v92, 2, v94
	v_lshlrev_b32_e32 v25, 3, v95
	v_mad_i32_i24 v24, v24, s2, v25
	v_lshl_add_u32 v33, v24, 1, 0
	ds_read_b128 v[28:31], v33
	ds_read_b128 v[24:27], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v68
	ds_write_b16 v0, v67 offset:8
	ds_write_b16 v0, v66 offset:16
	ds_write_b16 v0, v65 offset:24
	ds_write_b16 v0, v64 offset:64
	ds_write_b16 v0, v63 offset:72
	ds_write_b16 v0, v62 offset:80
	ds_write_b16 v0, v61 offset:88
	ds_write_b16 v0, v23 offset:128
	ds_write_b16 v0, v22 offset:136
	ds_write_b16 v0, v21 offset:144
	ds_write_b16 v0, v20 offset:152
	ds_write_b16 v0, v19 offset:192
	ds_write_b16 v0, v18 offset:200
	ds_write_b16 v0, v17 offset:208
	ds_write_b16 v0, v16 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[20:23], v33
	ds_read_b128 v[16:19], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v60
	ds_write_b16 v0, v55 offset:8
	ds_write_b16 v0, v54 offset:16
	ds_write_b16 v0, v53 offset:24
	ds_write_b16 v0, v52 offset:64
	ds_write_b16 v0, v47 offset:72
	ds_write_b16 v0, v46 offset:80
	ds_write_b16 v0, v45 offset:88
	ds_write_b16 v0, v15 offset:128
	ds_write_b16 v0, v14 offset:136
	ds_write_b16 v0, v13 offset:144
	ds_write_b16 v0, v12 offset:152
	ds_write_b16 v0, v11 offset:192
	ds_write_b16 v0, v10 offset:200
	ds_write_b16 v0, v9 offset:208
	ds_write_b16 v0, v8 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[12:15], v33
	ds_read_b128 v[8:11], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v44
	ds_write_b16 v0, v43 offset:8
	ds_write_b16 v0, v42 offset:16
	ds_write_b16 v0, v41 offset:24
	ds_write_b16 v0, v40 offset:64
	ds_write_b16 v0, v39 offset:72
	ds_write_b16 v0, v38 offset:80
	ds_write_b16 v0, v37 offset:88
	ds_write_b16 v0, v36 offset:128
	ds_write_b16 v0, v7 offset:136
	ds_write_b16 v0, v6 offset:144
	ds_write_b16 v0, v5 offset:152
	ds_write_b16 v0, v4 offset:192
	ds_write_b16 v0, v3 offset:200
	ds_write_b16 v0, v2 offset:208
	ds_write_b16 v0, v1 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[4:7], v33
	ds_read_b128 v[0:3], v33 offset:4352
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_17
	v_ashrrev_i32_e32 v33, 31, v32
	v_lshlrev_b64 v[33:34], 1, v[32:33]
	v_mov_b32_e32 v35, s5
	v_add_co_u32_e64 v33, s[0:1], s4, v33
	v_addc_co_u32_e64 v34, s[0:1], v35, v34, s[0:1]
	s_waitcnt lgkmcnt(14)
	global_store_dwordx4 v[33:34], v[28:31], off
.LBB0_17:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(14)
	v_or_b32_e32 v29, s20, v91
	.loc	1 57 21
	s_lshl_b32 s6, s13, 4
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v29
	v_add_u32_e32 v28, s6, v32
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_19
	v_ashrrev_i32_e32 v29, 31, v28
	v_lshlrev_b64 v[29:30], 1, v[28:29]
	v_mov_b32_e32 v31, s5
	v_add_co_u32_e64 v29, s[0:1], s4, v29
	v_addc_co_u32_e64 v30, s[0:1], v31, v30, s[0:1]
	global_store_dwordx4 v[29:30], v[24:27], off
.LBB0_19:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v25, v90, s20, 32
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v25
	v_add_u32_e32 v24, s6, v28
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_21
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshlrev_b64 v[25:26], 1, v[24:25]
	v_mov_b32_e32 v27, s5
	v_add_co_u32_e64 v25, s[0:1], s4, v25
	v_addc_co_u32_e64 v26, s[0:1], v27, v26, s[0:1]
	global_store_dwordx4 v[25:26], v[20:23], off
.LBB0_21:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v21, v90, s20, 48
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v21
	v_add_u32_e32 v20, s6, v24
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_23
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[21:22], 1, v[20:21]
	v_mov_b32_e32 v23, s5
	v_add_co_u32_e64 v21, s[0:1], s4, v21
	v_addc_co_u32_e64 v22, s[0:1], v23, v22, s[0:1]
	global_store_dwordx4 v[21:22], v[16:19], off
.LBB0_23:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v17, v90, s20, 64
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v17
	v_add_u32_e32 v16, s6, v20
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_25
	v_ashrrev_i32_e32 v17, 31, v16
	v_lshlrev_b64 v[17:18], 1, v[16:17]
	v_mov_b32_e32 v19, s5
	v_add_co_u32_e64 v17, s[0:1], s4, v17
	v_addc_co_u32_e64 v18, s[0:1], v19, v18, s[0:1]
	global_store_dwordx4 v[17:18], v[12:15], off
.LBB0_25:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 46 is_stmt 1
	s_nop 0
	v_or_b32_e32 v14, s20, v90
	.loc	1 39 33 is_stmt 0
	v_or_b32_e32 v13, 0x50, v14
	.loc	1 58 33 is_stmt 1
	v_cmp_gt_i32_e64 s[0:1], s8, v13
	v_add_u32_e32 v12, s6, v16
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_27
	v_ashrrev_i32_e32 v13, 31, v12
	v_lshlrev_b64 v[15:16], 1, v[12:13]
	v_mov_b32_e32 v13, s5
	v_add_co_u32_e64 v15, s[0:1], s4, v15
	v_addc_co_u32_e64 v16, s[0:1], v13, v16, s[0:1]
	global_store_dwordx4 v[15:16], v[8:11], off
.LBB0_27:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or_b32_e32 v9, 0x60, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v9
	v_add_u32_e32 v8, s6, v12
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_29
	v_ashrrev_i32_e32 v9, 31, v8
	v_lshlrev_b64 v[9:10], 1, v[8:9]
	v_mov_b32_e32 v11, s5
	v_add_co_u32_e64 v9, s[0:1], s4, v9
	v_addc_co_u32_e64 v10, s[0:1], v11, v10, s[0:1]
	s_waitcnt lgkmcnt(1)
	global_store_dwordx4 v[9:10], v[4:7], off
.LBB0_29:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(1)
	v_or_b32_e32 v4, 0x70, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v4
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_31
	.loc	1 0 21 is_stmt 0
	v_add_u32_e32 v4, s6, v8
	.loc	1 59 21
	v_ashrrev_i32_e32 v5, 31, v4
	v_lshlrev_b64 v[4:5], 1, v[4:5]
	v_mov_b32_e32 v6, s5
	v_add_co_u32_e32 v4, vcc, s4, v4
	v_addc_co_u32_e32 v5, vcc, v6, v5, vcc
	s_waitcnt lgkmcnt(0)
	global_store_dwordx4 v[4:5], v[0:3], off
.LBB0_31:
	.loc	1 59 4
	s_endpgm
.Ltmp19:
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel gemm_kernel
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 48
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 143
		.amdhsa_next_free_sgpr 22
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	gemm_kernel, .Lfunc_end0-gemm_kernel
	.cfi_endproc

	.section	.debug_abbrev
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.ascii	"\211|"
	.byte	14
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	0
	.byte	0
	.byte	2
	.byte	46
	.byte	0
	.byte	3
	.byte	14
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	49
	.byte	19
	.byte	0
	.byte	0
	.byte	4
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.short	4
	.long	.debug_abbrev
	.byte	8
	.byte	1
	.long	.Linfo_string0
	.short	2
	.long	.Linfo_string1
	.long	.Lline_table_start0
	.long	.Linfo_string2
	.long	.Linfo_string3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.byte	2
	.long	.Linfo_string4
	.byte	1
	.byte	3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.long	46
	.byte	4
	.long	46
	.long	.Ldebug_ranges0
	.byte	1
	.byte	31
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges1
	.byte	1
	.byte	30
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges2
	.byte	1
	.byte	47
	.byte	33
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.debug_ranges
.Ldebug_ranges0:
	.quad	.Lfunc_begin0-.Lfunc_begin0
	.quad	.Ltmp0-.Lfunc_begin0
	.quad	.Ltmp1-.Lfunc_begin0
	.quad	.Ltmp2-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	.Ltmp17-.Lfunc_begin0
	.quad	.Ltmp18-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"triton"
.Linfo_string1:
	.asciz	"08_triton_gemm_mmac.py"
.Linfo_string2:
	.asciz	"experiments/advanced"
.Linfo_string3:
	.asciz	"[llvm:v0.0]"
.Linfo_string4:
	.asciz	"gemm_kernel"
	.section	".note.GNU-stack"
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
      - .offset:         40
        .size:           4
        .value_kind:     by_value
      - .offset:         44
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 48
    .max_flat_workgroup_size: 256
    .name:           gemm_kernel
    .private_segment_fixed_size: 0
    .sgpr_count:     26
    .sgpr_spill_count: 0
    .symbol:         gemm_kernel.kd
    .vgpr_count:     143
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx936
amdhsa.version:
  - 1
  - 1
...

	.end_amdgpu_metadata
	.section	.debug_line
.Lline_table_start0:
