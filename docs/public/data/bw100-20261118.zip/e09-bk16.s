	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936"
	.globl	gemm_kernel
	.p2align	8
	.type	gemm_kernel,@function
gemm_kernel:
.Lfunc_begin0:
	.file	1 "experiments/advanced" "08_triton_gemm_mmac.py"
	.loc	1 18 0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_escape 0x0f, 0x03, 0x30, 0x36, 0xe1
	.cfi_undefined 16
	.file	2 "/usr/local/lib/python3.11/site-packages/triton/language" "standard.py"
	.loc	2 40 22 prologue_end
	s_load_dwordx4 s[8:11], s[4:5], 0x18
	s_load_dwordx2 s[16:17], s[4:5], 0x28
.Ltmp0:
	.loc	1 39 46
	v_and_b32_e32 v13, 8, v0
	v_and_b32_e32 v12, 63, v0
	v_lshrrev_b32_e32 v79, 6, v0
.Ltmp1:
	.loc	2 40 22
	s_waitcnt lgkmcnt(0)
	s_add_i32 s1, s9, 0x7f
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s2, s1, 31
	s_lshr_b32 s2, s2, 25
	s_add_i32 s1, s1, s2
	s_ashr_i32 s2, s1, 7
.Ltmp2:
	.loc	1 32 33 is_stmt 1
	s_lshl_b32 s2, s2, 3
	.loc	1 33 22
	s_ashr_i32 s1, s1, 31
	s_add_i32 s3, s2, s1
	s_xor_b32 s3, s3, s1
	v_cvt_f32_u32_e32 v1, s3
.Ltmp3:
	.loc	2 40 22
	s_add_i32 s0, s8, 0x7f
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s7, s0, 31
	s_lshr_b32 s7, s7, 25
.Ltmp4:
	.loc	1 33 22 is_stmt 1
	v_rcp_iflag_f32_e32 v1, v1
.Ltmp5:
	.loc	2 40 28
	s_add_i32 s0, s0, s7
.Ltmp6:
	.loc	1 33 22
	s_ashr_i32 s7, s6, 31
	s_add_i32 s12, s6, s7
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_xor_b32 s1, s7, s1
	s_xor_b32 s7, s12, s7
	s_sub_i32 s12, 0, s3
	v_readfirstlane_b32 s13, v1
	s_mul_i32 s12, s12, s13
	s_mul_hi_u32 s12, s13, s12
	s_add_i32 s13, s13, s12
	s_mul_hi_u32 s12, s7, s13
	s_mul_i32 s13, s12, s3
	s_sub_i32 s7, s7, s13
.Ltmp7:
	.loc	2 40 28
	s_ashr_i32 s0, s0, 7
.Ltmp8:
	.loc	1 33 22
	s_add_i32 s13, s12, 1
	s_sub_i32 s14, s7, s3
	s_cmp_ge_u32 s7, s3
	s_cselect_b32 s12, s13, s12
	s_cselect_b32 s7, s14, s7
	s_add_i32 s13, s12, 1
	s_cmp_ge_u32 s7, s3
	s_cselect_b32 s3, s13, s12
	s_xor_b32 s3, s3, s1
	s_sub_i32 s1, s3, s1
	.loc	1 34 29
	s_lshl_b32 s7, s1, 3
	.loc	1 35 35
	s_sub_i32 s0, s0, s7
	.loc	1 35 48 is_stmt 0
	s_min_i32 s0, s0, 8
	.loc	1 37 40 is_stmt 1
	s_ashr_i32 s20, s0, 31
	s_add_i32 s3, s0, s20
	s_xor_b32 s21, s3, s20
	v_cvt_f32_u32_e32 v1, s21
	.loc	1 36 34
	s_mul_i32 s1, s1, s2
	s_sub_i32 s1, s6, s1
	.loc	1 37 40
	s_ashr_i32 s2, s1, 31
	v_rcp_iflag_f32_e32 v1, v1
.Ltmp9:
	.loc	2 40 22
	s_load_dwordx4 s[12:15], s[4:5], 0x0
	s_load_dwordx2 s[18:19], s[4:5], 0x10
.Ltmp10:
	.loc	1 37 40
	s_add_i32 s5, s1, s2
	s_xor_b32 s4, s2, s20
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_xor_b32 s2, s5, s2
	s_sub_i32 s5, 0, s21
	.loc	1 39 46
	v_lshlrev_b32_e32 v2, 3, v13
	.loc	1 37 40
	v_readfirstlane_b32 s6, v1
	s_mul_i32 s5, s5, s6
	s_mul_hi_u32 s5, s6, s5
	s_add_i32 s6, s6, s5
	s_mul_hi_u32 s5, s2, s6
	s_mul_i32 s6, s5, s21
	s_sub_i32 s2, s2, s6
	s_add_i32 s6, s5, 1
	s_sub_i32 s20, s2, s21
	s_cmp_ge_u32 s2, s21
	s_cselect_b32 s5, s6, s5
	s_cselect_b32 s2, s20, s2
	s_add_i32 s6, s5, 1
	s_cmp_ge_u32 s2, s21
	s_cselect_b32 s2, s6, s5
	s_xor_b32 s2, s2, s4
	s_sub_i32 s2, s2, s4
	.loc	1 36 54
	s_mul_i32 s0, s0, s2
	s_add_i32 s1, s1, s7
	.loc	1 39 46
	v_lshlrev_b32_e32 v1, 3, v0
	.loc	1 36 27
	s_sub_i32 s5, s1, s0
	.loc	1 39 46
	v_and_b32_e32 v73, 8, v1
	v_and_b32_e32 v1, 48, v1
	.loc	1 40 23
	s_lshl_b32 s4, s2, 7
.Ltmp11:
	.loc	2 40 22 is_stmt 0
	s_add_i32 s2, s10, 15
	s_mov_b32 s3, 0
.Ltmp12:
	.loc	1 39 46 is_stmt 1
	v_or3_b32 v72, v1, v2, v73
	.loc	1 47 22
	s_cmp_gt_i32 s2, 15
	v_lshrrev_b32_e32 v1, 3, v0
	v_lshlrev_b32_e32 v2, 4, v79
	v_lshrrev_b32_e32 v81, 4, v12
	v_and_b32_e32 v82, 15, v0
	s_cbranch_scc1 .LBB0_2
	.loc	1 59 21
	v_and_b32_e32 v84, 16, v2
	v_and_or_b32 v83, v1, 16, v82
	s_mov_b64 s[0:1], 0
	s_branch .LBB0_3
.LBB0_2:
	.loc	1 0 21 is_stmt 0
	s_mov_b64 s[0:1], -1
.LBB0_3:
	s_lshl_b32 s20, s5, 7
	v_lshrrev_b32_e32 v78, 4, v0
	v_or_b32_e32 v80, s4, v72
	.loc	1 47 22 is_stmt 1
	s_andn2_b64 vcc, exec, s[0:1]
	v_mov_b32_e32 v1, s3
	v_mov_b32_e32 v2, s3
	v_mov_b32_e32 v3, s3
	v_mov_b32_e32 v4, s3
	v_mov_b32_e32 v5, s3
	v_mov_b32_e32 v6, s3
	v_mov_b32_e32 v7, s3
	v_mov_b32_e32 v36, s3
	v_mov_b32_e32 v37, s3
	v_mov_b32_e32 v38, s3
	v_mov_b32_e32 v39, s3
	v_mov_b32_e32 v40, s3
	v_mov_b32_e32 v41, s3
	v_mov_b32_e32 v42, s3
	v_mov_b32_e32 v43, s3
	v_mov_b32_e32 v44, s3
	v_mov_b32_e32 v8, s3
	v_mov_b32_e32 v9, s3
	v_mov_b32_e32 v10, s3
	v_mov_b32_e32 v11, s3
	v_mov_b32_e32 v48, s3
	v_mov_b32_e32 v49, s3
	v_mov_b32_e32 v50, s3
	v_mov_b32_e32 v51, s3
	v_mov_b32_e32 v52, s3
	v_mov_b32_e32 v53, s3
	v_mov_b32_e32 v54, s3
	v_mov_b32_e32 v55, s3
	v_mov_b32_e32 v60, s3
	v_mov_b32_e32 v61, s3
	v_mov_b32_e32 v62, s3
	v_mov_b32_e32 v63, s3
	v_mov_b32_e32 v64, s3
	v_mov_b32_e32 v65, s3
	v_mov_b32_e32 v66, s3
	v_mov_b32_e32 v67, s3
	v_mov_b32_e32 v68, s3
	v_mov_b32_e32 v69, s3
	v_mov_b32_e32 v70, s3
	v_mov_b32_e32 v71, s3
	v_mov_b32_e32 v74, s3
	v_mov_b32_e32 v75, s3
	v_mov_b32_e32 v76, s3
	v_mov_b32_e32 v77, s3
	v_mov_b32_e32 v85, s3
	v_mov_b32_e32 v86, s3
	v_mov_b32_e32 v87, s3
	v_mov_b32_e32 v88, s3
	v_mov_b32_e32 v89, s3
	v_mov_b32_e32 v90, s3
	v_mov_b32_e32 v91, s3
	v_mov_b32_e32 v92, s3
	v_mov_b32_e32 v93, s3
	v_mov_b32_e32 v94, s3
	v_mov_b32_e32 v95, s3
	v_mov_b32_e32 v96, s3
	v_mov_b32_e32 v97, s3
	v_mov_b32_e32 v98, s3
	v_mov_b32_e32 v99, s3
	v_mov_b32_e32 v100, s3
	v_mov_b32_e32 v101, s3
	v_mov_b32_e32 v102, s3
	v_mov_b32_e32 v103, s3
	v_mov_b32_e32 v104, s3
	s_cbranch_vccnz .LBB0_11
	.loc	1 40 58
	s_ashr_i32 s0, s9, 31
	s_add_i32 s1, s9, s0
	s_xor_b32 s0, s1, s0
	v_cvt_f32_u32_e32 v1, s0
	.loc	1 39 58
	s_ashr_i32 s3, s8, 31
	.loc	1 40 58
	s_sub_i32 s5, 0, s0
	v_ashrrev_i32_e32 v2, 31, v80
	v_rcp_iflag_f32_e32 v1, v1
	.loc	1 39 46
	v_lshrrev_b32_e32 v3, 1, v0
	.loc	1 40 58
	v_add_u32_e32 v4, v80, v2
	.loc	1 39 46
	v_and_b32_e32 v5, 0x73, v3
	.loc	1 40 58
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	.loc	1 39 46
	v_and_b32_e32 v9, 8, v3
	.loc	1 40 58
	v_xor_b32_e32 v3, v4, v2
.Ltmp13:
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s1, s2, 31
.Ltmp14:
	.loc	1 40 58
	v_mul_lo_u32 v7, s5, v1
	.loc	1 39 58 is_stmt 1
	s_add_i32 s5, s8, s3
	s_xor_b32 s3, s5, s3
	v_cvt_f32_u32_e32 v8, s3
	.loc	1 40 58
	v_mul_hi_u32 v7, v1, v7
.Ltmp15:
	.loc	2 40 28 is_stmt 0
	s_lshr_b32 s1, s1, 28
	s_add_i32 s2, s2, s1
.Ltmp16:
	.loc	1 39 58 is_stmt 1
	v_rcp_iflag_f32_e32 v4, v8
	s_sub_i32 s1, 0, s3
	.loc	1 40 58
	v_add_u32_e32 v1, v1, v7
	v_mul_hi_u32 v1, v3, v1
	.loc	1 39 58
	v_mul_f32_e32 v4, 0x4f7ffffe, v4
	v_cvt_u32_f32_e32 v4, v4
	.loc	1 39 46 is_stmt 0
	v_lshrrev_b32_e32 v6, 1, v13
	v_or3_b32 v8, v6, v5, v9
	.loc	1 39 33
	v_or_b32_e32 v5, s20, v8
	.loc	1 39 58
	v_mul_lo_u32 v7, s1, v4
	s_ashr_i32 s1, s20, 31
	.loc	1 40 58 is_stmt 1
	v_mul_lo_u32 v1, v1, s0
	.loc	1 39 58
	v_add_u32_e32 v5, s1, v5
	v_mul_hi_u32 v7, v4, v7
	v_xor_b32_e32 v5, s1, v5
	.loc	1 40 58
	v_sub_u32_e32 v1, v3, v1
	v_subrev_u32_e32 v3, s0, v1
	.loc	1 39 58
	v_add_u32_e32 v4, v4, v7
	v_mul_hi_u32 v4, v5, v4
	.loc	1 40 58
	v_cmp_le_u32_e32 vcc, s0, v1
	v_cndmask_b32_e32 v1, v1, v3, vcc
	v_subrev_u32_e32 v3, s0, v1
	.loc	1 39 58
	v_mul_lo_u32 v4, v4, s3
	.loc	1 40 58
	v_cmp_le_u32_e32 vcc, s0, v1
	v_cndmask_b32_e32 v1, v1, v3, vcc
	v_xor_b32_e32 v1, v1, v2
	v_sub_u32_e32 v1, v1, v2
	.loc	1 39 58
	v_sub_u32_e32 v2, v5, v4
	v_subrev_u32_e32 v3, s3, v2
	v_cmp_le_u32_e32 vcc, s3, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_subrev_u32_e32 v3, s3, v2
	v_cmp_le_u32_e32 vcc, s3, v2
	v_cndmask_b32_e32 v2, v2, v3, vcc
	v_xor_b32_e32 v2, s1, v2
	v_subrev_u32_e32 v2, s1, v2
	.loc	1 43 52
	v_mad_u64_u32 v[2:3], s[0:1], v2, s11, v[73:74]
	v_lshlrev_b32_e32 v7, 4, v8
	v_and_b32_e32 v82, 15, v0
	.loc	1 44 51
	v_mad_u64_u32 v[4:5], s[0:1], v78, s16, v[1:2]
	v_or_b32_e32 v1, v73, v6
	v_xor_b32_e32 v1, v1, v9
	v_or_b32_e32 v1, v7, v1
	v_lshl_add_u32 v85, v1, 1, 0
	v_or_b32_e32 v1, 4, v73
	v_or_b32_e32 v6, v9, v6
	v_xor_b32_e32 v1, v6, v1
	v_or_b32_e32 v1, v7, v1
	v_lshl_add_u32 v86, v1, 1, 0
	v_lshrrev_b32_e32 v1, 3, v0
	v_lshrrev_b32_e32 v81, 4, v12
	v_and_b32_e32 v0, 12, v0
	v_and_or_b32 v83, v1, 16, v82
	v_lshlrev_b32_e32 v0, 1, v0
	v_lshlrev_b32_e32 v1, 3, v81
	v_xor_b32_e32 v0, v1, v0
	v_lshl_or_b32 v0, v83, 5, v0
	v_add_u32_e32 v87, 0, v0
	v_lshlrev_b32_e32 v0, 1, v72
	v_lshl_or_b32 v0, v78, 8, v0
	v_add_u32_e32 v88, 0, v0
	v_lshlrev_b32_e32 v0, 4, v79
	v_and_b32_e32 v84, 16, v0
	v_lshlrev_b32_e32 v0, 9, v81
	v_ashrrev_i32_e32 v5, 31, v4
	v_or3_b32 v0, v0, v82, v84
	v_lshl_add_u32 v89, v0, 1, 0
	.loc	1 47 22
	v_lshlrev_b64 v[0:1], 1, v[4:5]
	v_ashrrev_i32_e32 v3, 31, v2
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v4, s15
	v_add_co_u32_e32 v74, vcc, s14, v0
	v_addc_co_u32_e32 v75, vcc, v4, v1, vcc
	v_lshlrev_b64 v[0:1], 1, v[2:3]
.Ltmp17:
	.loc	2 40 28
	s_ashr_i32 s5, s2, 4
.Ltmp18:
	.loc	1 52 28
	s_lshl_b32 s2, s16, 4
	s_ashr_i32 s3, s2, 31
	.loc	1 47 22
	v_mov_b32_e32 v2, s13
	v_add_co_u32_e32 v76, vcc, s12, v0
	v_mov_b32_e32 v0, 0
	s_mov_b32 s0, 0
	s_lshl_b64 s[6:7], s[2:3], 1
	v_addc_co_u32_e32 v77, vcc, v2, v1, vcc
	s_mov_b32 s11, 0x5040100
	v_mov_b32_e32 v1, v0
	v_mov_b32_e32 v2, v0
	v_mov_b32_e32 v3, v0
	v_mov_b32_e32 v40, v0
	v_mov_b32_e32 v41, v0
	v_mov_b32_e32 v42, v0
	v_mov_b32_e32 v43, v0
	v_mov_b32_e32 v8, v0
	v_mov_b32_e32 v9, v0
	v_mov_b32_e32 v10, v0
	v_mov_b32_e32 v11, v0
	v_mov_b32_e32 v36, v0
	v_mov_b32_e32 v37, v0
	v_mov_b32_e32 v38, v0
	v_mov_b32_e32 v39, v0
	v_mov_b32_e32 v60, v0
	v_mov_b32_e32 v61, v0
	v_mov_b32_e32 v62, v0
	v_mov_b32_e32 v63, v0
	v_mov_b32_e32 v28, v0
	v_mov_b32_e32 v29, v0
	v_mov_b32_e32 v30, v0
	v_mov_b32_e32 v31, v0
	v_mov_b32_e32 v24, v0
	v_mov_b32_e32 v25, v0
	v_mov_b32_e32 v26, v0
	v_mov_b32_e32 v27, v0
	v_mov_b32_e32 v52, v0
	v_mov_b32_e32 v53, v0
	v_mov_b32_e32 v54, v0
	v_mov_b32_e32 v55, v0
	v_mov_b32_e32 v20, v0
	v_mov_b32_e32 v21, v0
	v_mov_b32_e32 v22, v0
	v_mov_b32_e32 v23, v0
	v_mov_b32_e32 v48, v0
	v_mov_b32_e32 v49, v0
	v_mov_b32_e32 v50, v0
	v_mov_b32_e32 v51, v0
	v_mov_b32_e32 v16, v0
	v_mov_b32_e32 v17, v0
	v_mov_b32_e32 v18, v0
	v_mov_b32_e32 v19, v0
	v_mov_b32_e32 v44, v0
	v_mov_b32_e32 v45, v0
	v_mov_b32_e32 v46, v0
	v_mov_b32_e32 v47, v0
	v_mov_b32_e32 v12, v0
	v_mov_b32_e32 v13, v0
	v_mov_b32_e32 v14, v0
	v_mov_b32_e32 v15, v0
	v_mov_b32_e32 v4, v0
	v_mov_b32_e32 v5, v0
	v_mov_b32_e32 v6, v0
	v_mov_b32_e32 v7, v0
	v_mov_b32_e32 v32, v0
	v_mov_b32_e32 v33, v0
	v_mov_b32_e32 v34, v0
	v_mov_b32_e32 v35, v0
	v_mov_b32_e32 v56, v0
	v_mov_b32_e32 v57, v0
	v_mov_b32_e32 v58, v0
	v_mov_b32_e32 v59, v0
	v_add_u32_e32 v90, 64, v89
	v_add_u32_e32 v91, 0x80, v89
	v_add_u32_e32 v92, 0xc0, v89
	s_branch .LBB0_6
.LBB0_5:
	.loc	1 0 22 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 48 20 is_stmt 1
	s_waitcnt vmcnt(0)
	s_barrier
	ds_write_b64 v85, v[64:65]
	ds_write_b64 v86, v[66:67]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	ds_read2st64_b64 v[64:67], v87 offset1:2
	ds_read2st64_b64 v[93:96], v87 offset0:4 offset1:6
	.loc	1 49 20
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	ds_write_b128 v88, v[68:71]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	ds_read_u16 v68, v89 offset:512
	ds_read_u16 v69, v89 offset:768
	ds_read_u16 v70, v90 offset:256
	ds_read_u16 v71, v89
	ds_read_u16 v97, v89 offset:64
	ds_read_u16 v99, v89 offset:128
	ds_read_u16 v98, v89 offset:256
	ds_read_u16 v101, v89 offset:192
	ds_read_u16 v100, v90 offset:512
	ds_read_u16 v102, v90 offset:768
	ds_read_u16 v103, v91 offset:256
	ds_read_u16 v104, v91 offset:512
	ds_read_u16 v105, v91 offset:768
	ds_read_u16 v106, v92 offset:256
	ds_read_u16 v107, v92 offset:512
	ds_read_u16 v108, v92 offset:768
	.loc	1 50 27
	s_waitcnt lgkmcnt(14)
	v_perm_b32 v69, v69, v68, s11
	s_waitcnt lgkmcnt(9)
	v_perm_b32 v68, v98, v71, s11
	s_waitcnt lgkmcnt(6)
	v_perm_b32 v71, v102, v100, s11
	v_perm_b32 v70, v70, v97, s11
	s_waitcnt lgkmcnt(3)
	v_perm_b32 v98, v105, v104, s11
	v_perm_b32 v97, v103, v99, s11
	s_waitcnt lgkmcnt(0)
	v_perm_b32 v100, v108, v107, s11
	v_perm_b32 v99, v106, v101, s11
	s_setprio 1
	v_mmac_f32_16x16x16_f16 v[0:3], v[64:65], v[68:69], v[0:3]
	v_mmac_f32_16x16x16_f16 v[40:43], v[64:65], v[70:71], v[40:43]
	v_mmac_f32_16x16x16_f16 v[8:11], v[64:65], v[97:98], v[8:11]
	v_mmac_f32_16x16x16_f16 v[36:39], v[64:65], v[99:100], v[36:39]
	v_mmac_f32_16x16x16_f16 v[60:63], v[66:67], v[68:69], v[60:63]
	v_mmac_f32_16x16x16_f16 v[28:31], v[66:67], v[70:71], v[28:31]
	v_mmac_f32_16x16x16_f16 v[24:27], v[66:67], v[97:98], v[24:27]
	v_mmac_f32_16x16x16_f16 v[52:55], v[66:67], v[99:100], v[52:55]
	v_mmac_f32_16x16x16_f16 v[20:23], v[93:94], v[68:69], v[20:23]
	v_mmac_f32_16x16x16_f16 v[48:51], v[93:94], v[70:71], v[48:51]
	v_mmac_f32_16x16x16_f16 v[16:19], v[93:94], v[97:98], v[16:19]
	v_mmac_f32_16x16x16_f16 v[44:47], v[93:94], v[99:100], v[44:47]
	v_mmac_f32_16x16x16_f16 v[12:15], v[95:96], v[68:69], v[12:15]
	v_mmac_f32_16x16x16_f16 v[4:7], v[95:96], v[70:71], v[4:7]
	v_mmac_f32_16x16x16_f16 v[32:35], v[95:96], v[97:98], v[32:35]
	v_mmac_f32_16x16x16_f16 v[56:59], v[95:96], v[99:100], v[56:59]
	s_setprio 0
	.loc	1 47 22
	v_mov_b32_e32 v64, s7
	v_add_co_u32_e32 v74, vcc, s6, v74
	v_addc_co_u32_e32 v75, vcc, v75, v64, vcc
	s_add_i32 s5, s5, -1
	s_add_i32 s10, s10, -16
	v_add_co_u32_e32 v76, vcc, 32, v76
	s_cmp_lg_u32 s5, 0
	v_addc_co_u32_e32 v77, vcc, 0, v77, vcc
	s_cbranch_scc0 .LBB0_10
.LBB0_6:
	.loc	1 0 22 is_stmt 0
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	s_mov_b32 s1, s0
	.loc	1 48 20 is_stmt 1
	v_mov_b64_e32 v[66:67], s[2:3]
	.loc	1 48 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s10, v73
	.loc	1 48 20
	v_mov_b64_e32 v[64:65], s[0:1]
	s_and_saveexec_b64 s[12:13], vcc
	s_cbranch_execz .LBB0_8
	global_load_dwordx4 v[64:67], v[76:77], off
.LBB0_8:
	.loc	1 0 20
	s_or_b64 exec, exec, s[12:13]
	.loc	1 49 20 is_stmt 1
	v_mov_b64_e32 v[70:71], s[2:3]
	.loc	1 49 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s10, v78
	.loc	1 49 20
	v_mov_b64_e32 v[68:69], s[0:1]
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_5
	global_load_dwordx4 v[68:71], v[74:75], off
	s_branch .LBB0_5
.LBB0_10:
	.loc	1 54 15 is_stmt 1
	v_cvt_f16_f32_e32 v104, v0
	v_cvt_f16_f32_e32 v103, v1
	v_cvt_f16_f32_e32 v102, v2
	v_cvt_f16_f32_e32 v101, v3
	v_cvt_f16_f32_e32 v100, v40
	v_cvt_f16_f32_e32 v99, v41
	v_cvt_f16_f32_e32 v98, v42
	v_cvt_f16_f32_e32 v97, v43
	v_cvt_f16_f32_e32 v96, v8
	v_cvt_f16_f32_e32 v95, v9
	v_cvt_f16_f32_e32 v94, v10
	v_cvt_f16_f32_e32 v93, v11
	v_cvt_f16_f32_e32 v92, v36
	v_cvt_f16_f32_e32 v91, v37
	v_cvt_f16_f32_e32 v90, v38
	v_cvt_f16_f32_e32 v89, v39
	v_cvt_f16_f32_e32 v88, v60
	v_cvt_f16_f32_e32 v87, v61
	v_cvt_f16_f32_e32 v86, v62
	v_cvt_f16_f32_e32 v85, v63
	v_cvt_f16_f32_e32 v77, v28
	v_cvt_f16_f32_e32 v76, v29
	v_cvt_f16_f32_e32 v75, v30
	v_cvt_f16_f32_e32 v74, v31
	v_cvt_f16_f32_e32 v71, v24
	v_cvt_f16_f32_e32 v70, v25
	v_cvt_f16_f32_e32 v69, v26
	v_cvt_f16_f32_e32 v68, v27
	v_cvt_f16_f32_e32 v67, v52
	v_cvt_f16_f32_e32 v66, v53
	v_cvt_f16_f32_e32 v65, v54
	v_cvt_f16_f32_e32 v64, v55
	v_cvt_f16_f32_e32 v63, v20
	v_cvt_f16_f32_e32 v62, v21
	v_cvt_f16_f32_e32 v61, v22
	v_cvt_f16_f32_e32 v60, v23
	v_cvt_f16_f32_e32 v55, v48
	v_cvt_f16_f32_e32 v54, v49
	v_cvt_f16_f32_e32 v53, v50
	v_cvt_f16_f32_e32 v52, v51
	v_cvt_f16_f32_e32 v51, v16
	v_cvt_f16_f32_e32 v50, v17
	v_cvt_f16_f32_e32 v49, v18
	v_cvt_f16_f32_e32 v48, v19
	v_cvt_f16_f32_e32 v11, v44
	v_cvt_f16_f32_e32 v10, v45
	v_cvt_f16_f32_e32 v9, v46
	v_cvt_f16_f32_e32 v8, v47
	v_cvt_f16_f32_e32 v44, v12
	v_cvt_f16_f32_e32 v43, v13
	v_cvt_f16_f32_e32 v42, v14
	v_cvt_f16_f32_e32 v41, v15
	v_cvt_f16_f32_e32 v40, v4
	v_cvt_f16_f32_e32 v39, v5
	v_cvt_f16_f32_e32 v38, v6
	v_cvt_f16_f32_e32 v37, v7
	v_cvt_f16_f32_e32 v36, v32
	v_cvt_f16_f32_e32 v7, v33
	v_cvt_f16_f32_e32 v6, v34
	v_cvt_f16_f32_e32 v5, v35
	v_cvt_f16_f32_e32 v4, v56
	v_cvt_f16_f32_e32 v3, v57
	v_cvt_f16_f32_e32 v2, v58
	v_cvt_f16_f32_e32 v1, v59
.LBB0_11:
	.loc	1 57 21
	s_mul_i32 s0, s20, s17
	s_ashr_i32 s1, s0, 31
	s_lshl_b64 s[0:1], s[0:1], 1
	s_waitcnt lgkmcnt(0)
	s_add_u32 s2, s18, s0
	s_addc_u32 s3, s19, s1
	.loc	1 57 52 is_stmt 0
	s_ashr_i32 s5, s4, 31
	s_lshl_b64 s[0:1], s[4:5], 1
	s_add_u32 s4, s2, s0
	.loc	1 39 33 is_stmt 1
	v_or_b32_e32 v0, s20, v78
	.loc	1 57 52
	s_addc_u32 s5, s3, s1
	v_mad_u64_u32 v[32:33], s[0:1], v78, s17, v[72:73]
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v0
	.loc	1 59 21
	v_or_b32_e32 v0, v84, v81
	s_movk_i32 s2, 0x88
	v_mad_i32_i24 v0, v83, s2, v0
	.loc	1 58 58
	v_cmp_gt_i32_e32 vcc, s9, v80
	.loc	1 59 21
	v_lshl_add_u32 v0, v0, 1, 0
	.loc	1 58 39
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_waitcnt lgkmcnt(0)
	ds_write_b16 v0, v104
	ds_write_b16 v0, v103 offset:8
	ds_write_b16 v0, v102 offset:16
	ds_write_b16 v0, v101 offset:24
	ds_write_b16 v0, v100 offset:64
	ds_write_b16 v0, v99 offset:72
	ds_write_b16 v0, v98 offset:80
	ds_write_b16 v0, v97 offset:88
	ds_write_b16 v0, v96 offset:128
	ds_write_b16 v0, v95 offset:136
	ds_write_b16 v0, v94 offset:144
	ds_write_b16 v0, v93 offset:152
	ds_write_b16 v0, v92 offset:192
	ds_write_b16 v0, v91 offset:200
	ds_write_b16 v0, v90 offset:208
	ds_write_b16 v0, v89 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	v_lshl_add_u32 v12, v79, 2, v81
	v_lshlrev_b32_e32 v13, 3, v82
	v_mad_i32_i24 v12, v12, s2, v13
	v_lshl_add_u32 v33, v12, 1, 0
	ds_read_b128 v[28:31], v33
	ds_read_b128 v[24:27], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v88
	ds_write_b16 v0, v87 offset:8
	ds_write_b16 v0, v86 offset:16
	ds_write_b16 v0, v85 offset:24
	ds_write_b16 v0, v77 offset:64
	ds_write_b16 v0, v76 offset:72
	ds_write_b16 v0, v75 offset:80
	ds_write_b16 v0, v74 offset:88
	ds_write_b16 v0, v71 offset:128
	ds_write_b16 v0, v70 offset:136
	ds_write_b16 v0, v69 offset:144
	ds_write_b16 v0, v68 offset:152
	ds_write_b16 v0, v67 offset:192
	ds_write_b16 v0, v66 offset:200
	ds_write_b16 v0, v65 offset:208
	ds_write_b16 v0, v64 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[20:23], v33
	ds_read_b128 v[16:19], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v63
	ds_write_b16 v0, v62 offset:8
	ds_write_b16 v0, v61 offset:16
	ds_write_b16 v0, v60 offset:24
	ds_write_b16 v0, v55 offset:64
	ds_write_b16 v0, v54 offset:72
	ds_write_b16 v0, v53 offset:80
	ds_write_b16 v0, v52 offset:88
	ds_write_b16 v0, v51 offset:128
	ds_write_b16 v0, v50 offset:136
	ds_write_b16 v0, v49 offset:144
	ds_write_b16 v0, v48 offset:152
	ds_write_b16 v0, v11 offset:192
	ds_write_b16 v0, v10 offset:200
	ds_write_b16 v0, v9 offset:208
	ds_write_b16 v0, v8 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[12:15], v33
	ds_read_b128 v[8:11], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v44
	ds_write_b16 v0, v43 offset:8
	ds_write_b16 v0, v42 offset:16
	ds_write_b16 v0, v41 offset:24
	ds_write_b16 v0, v40 offset:64
	ds_write_b16 v0, v39 offset:72
	ds_write_b16 v0, v38 offset:80
	ds_write_b16 v0, v37 offset:88
	ds_write_b16 v0, v36 offset:128
	ds_write_b16 v0, v7 offset:136
	ds_write_b16 v0, v6 offset:144
	ds_write_b16 v0, v5 offset:152
	ds_write_b16 v0, v4 offset:192
	ds_write_b16 v0, v3 offset:200
	ds_write_b16 v0, v2 offset:208
	ds_write_b16 v0, v1 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[4:7], v33
	ds_read_b128 v[0:3], v33 offset:4352
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_13
	v_ashrrev_i32_e32 v33, 31, v32
	v_lshlrev_b64 v[33:34], 1, v[32:33]
	v_mov_b32_e32 v35, s5
	v_add_co_u32_e64 v33, s[0:1], s4, v33
	v_addc_co_u32_e64 v34, s[0:1], v35, v34, s[0:1]
	s_waitcnt lgkmcnt(14)
	global_store_dwordx4 v[33:34], v[28:31], off
.LBB0_13:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(14)
	v_or3_b32 v29, v78, s20, 16
	.loc	1 57 21
	s_lshl_b32 s6, s17, 4
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v29
	v_add_u32_e32 v28, s6, v32
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_15
	v_ashrrev_i32_e32 v29, 31, v28
	v_lshlrev_b64 v[29:30], 1, v[28:29]
	v_mov_b32_e32 v31, s5
	v_add_co_u32_e64 v29, s[0:1], s4, v29
	v_addc_co_u32_e64 v30, s[0:1], v31, v30, s[0:1]
	global_store_dwordx4 v[29:30], v[24:27], off
.LBB0_15:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v25, v78, s20, 32
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v25
	v_add_u32_e32 v24, s6, v28
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_17
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshlrev_b64 v[25:26], 1, v[24:25]
	v_mov_b32_e32 v27, s5
	v_add_co_u32_e64 v25, s[0:1], s4, v25
	v_addc_co_u32_e64 v26, s[0:1], v27, v26, s[0:1]
	global_store_dwordx4 v[25:26], v[20:23], off
.LBB0_17:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v21, v78, s20, 48
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v21
	v_add_u32_e32 v20, s6, v24
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_19
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[21:22], 1, v[20:21]
	v_mov_b32_e32 v23, s5
	v_add_co_u32_e64 v21, s[0:1], s4, v21
	v_addc_co_u32_e64 v22, s[0:1], v23, v22, s[0:1]
	global_store_dwordx4 v[21:22], v[16:19], off
.LBB0_19:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v17, v78, s20, 64
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v17
	v_add_u32_e32 v16, s6, v20
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_21
	v_ashrrev_i32_e32 v17, 31, v16
	v_lshlrev_b64 v[17:18], 1, v[16:17]
	v_mov_b32_e32 v19, s5
	v_add_co_u32_e64 v17, s[0:1], s4, v17
	v_addc_co_u32_e64 v18, s[0:1], v19, v18, s[0:1]
	global_store_dwordx4 v[17:18], v[12:15], off
.LBB0_21:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 46 is_stmt 1
	s_nop 0
	v_or_b32_e32 v14, s20, v78
	.loc	1 39 33 is_stmt 0
	v_or_b32_e32 v13, 0x50, v14
	.loc	1 58 33 is_stmt 1
	v_cmp_gt_i32_e64 s[0:1], s8, v13
	v_add_u32_e32 v12, s6, v16
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_23
	v_ashrrev_i32_e32 v13, 31, v12
	v_lshlrev_b64 v[15:16], 1, v[12:13]
	v_mov_b32_e32 v13, s5
	v_add_co_u32_e64 v15, s[0:1], s4, v15
	v_addc_co_u32_e64 v16, s[0:1], v13, v16, s[0:1]
	global_store_dwordx4 v[15:16], v[8:11], off
.LBB0_23:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or_b32_e32 v9, 0x60, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v9
	v_add_u32_e32 v8, s6, v12
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_25
	v_ashrrev_i32_e32 v9, 31, v8
	v_lshlrev_b64 v[9:10], 1, v[8:9]
	v_mov_b32_e32 v11, s5
	v_add_co_u32_e64 v9, s[0:1], s4, v9
	v_addc_co_u32_e64 v10, s[0:1], v11, v10, s[0:1]
	s_waitcnt lgkmcnt(1)
	global_store_dwordx4 v[9:10], v[4:7], off
.LBB0_25:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(1)
	v_or_b32_e32 v4, 0x70, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v4
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_27
	.loc	1 0 21 is_stmt 0
	v_add_u32_e32 v4, s6, v8
	.loc	1 59 21
	v_ashrrev_i32_e32 v5, 31, v4
	v_lshlrev_b64 v[4:5], 1, v[4:5]
	v_mov_b32_e32 v6, s5
	v_add_co_u32_e32 v4, vcc, s4, v4
	v_addc_co_u32_e32 v5, vcc, v6, v5, vcc
	s_waitcnt lgkmcnt(0)
	global_store_dwordx4 v[4:5], v[0:3], off
.LBB0_27:
	.loc	1 59 4
	s_endpgm
.Ltmp19:
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel gemm_kernel
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 48
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 109
		.amdhsa_next_free_sgpr 22
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	gemm_kernel, .Lfunc_end0-gemm_kernel
	.cfi_endproc

	.section	.debug_abbrev
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.ascii	"\211|"
	.byte	14
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	0
	.byte	0
	.byte	2
	.byte	46
	.byte	0
	.byte	3
	.byte	14
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	49
	.byte	19
	.byte	0
	.byte	0
	.byte	4
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.short	4
	.long	.debug_abbrev
	.byte	8
	.byte	1
	.long	.Linfo_string0
	.short	2
	.long	.Linfo_string1
	.long	.Lline_table_start0
	.long	.Linfo_string2
	.long	.Linfo_string3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.byte	2
	.long	.Linfo_string4
	.byte	1
	.byte	3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.long	46
	.byte	4
	.long	46
	.long	.Ldebug_ranges0
	.byte	1
	.byte	31
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges1
	.byte	1
	.byte	30
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges2
	.byte	1
	.byte	47
	.byte	33
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.debug_ranges
.Ldebug_ranges0:
	.quad	.Lfunc_begin0-.Lfunc_begin0
	.quad	.Ltmp0-.Lfunc_begin0
	.quad	.Ltmp1-.Lfunc_begin0
	.quad	.Ltmp2-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	.Ltmp17-.Lfunc_begin0
	.quad	.Ltmp18-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"triton"
.Linfo_string1:
	.asciz	"08_triton_gemm_mmac.py"
.Linfo_string2:
	.asciz	"experiments/advanced"
.Linfo_string3:
	.asciz	"[llvm:v0.0]"
.Linfo_string4:
	.asciz	"gemm_kernel"
	.section	".note.GNU-stack"
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
      - .offset:         40
        .size:           4
        .value_kind:     by_value
      - .offset:         44
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 48
    .max_flat_workgroup_size: 256
    .name:           gemm_kernel
    .private_segment_fixed_size: 0
    .sgpr_count:     26
    .sgpr_spill_count: 0
    .symbol:         gemm_kernel.kd
    .vgpr_count:     109
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx936
amdhsa.version:
  - 1
  - 1
...

	.end_amdgpu_metadata
	.section	.debug_line
.Lline_table_start0:
