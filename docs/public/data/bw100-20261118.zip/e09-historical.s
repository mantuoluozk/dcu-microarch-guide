	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936"
	.globl	gemm_kernel
	.p2align	8
	.type	gemm_kernel,@function
gemm_kernel:
.Lfunc_begin0:
	.file	1 "experiments/advanced" "08_triton_gemm_mmac.py"
	.loc	1 18 0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_escape 0x0f, 0x03, 0x30, 0x36, 0xe1
	.cfi_undefined 16
	.file	2 "/usr/local/lib/python3.11/site-packages/triton/language" "standard.py"
	.loc	2 40 22 prologue_end
	s_load_dwordx4 s[8:11], s[4:5], 0x18
	s_load_dwordx2 s[16:17], s[4:5], 0x28
	s_mov_b64 s[30:31], s[2:3]
	s_mov_b64 s[28:29], s[0:1]
	s_add_u32 s28, s28, s7
	s_addc_u32 s29, s29, 0
	s_waitcnt lgkmcnt(0)
	s_add_i32 s0, s9, 0xff
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s1, s0, 31
	s_lshr_b32 s1, s1, 24
	s_add_i32 s0, s0, s1
	s_ashr_i32 s1, s0, 8
.Ltmp0:
	.loc	1 33 22 is_stmt 1
	s_ashr_i32 s0, s0, 31
	.loc	1 32 33
	s_lshl_b32 s1, s1, 3
	.loc	1 33 22
	s_add_i32 s2, s1, s0
	s_xor_b32 s2, s2, s0
	v_cvt_f32_u32_e32 v1, s2
	s_ashr_i32 s3, s6, 31
	s_add_i32 s7, s6, s3
	s_xor_b32 s7, s7, s3
	v_rcp_iflag_f32_e32 v1, v1
	s_xor_b32 s0, s3, s0
	s_sub_i32 s3, 0, s2
	.loc	1 39 46
	v_lshrrev_b32_e32 v15, 2, v0
	.loc	1 33 22
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	.loc	1 43 59
	v_lshlrev_b32_e32 v7, 3, v0
	.loc	1 33 22
	v_readfirstlane_b32 s12, v1
	s_mul_i32 s3, s3, s12
	s_mul_hi_u32 s3, s12, s3
	s_add_i32 s12, s12, s3
	s_mul_hi_u32 s3, s7, s12
	s_mul_i32 s12, s3, s2
	s_sub_i32 s7, s7, s12
	s_add_i32 s13, s3, 1
	s_sub_i32 s12, s7, s2
	s_cmp_ge_u32 s7, s2
	s_cselect_b32 s3, s13, s3
	s_cselect_b32 s7, s12, s7
	s_add_i32 s12, s3, 1
	s_cmp_ge_u32 s7, s2
	s_cselect_b32 s2, s12, s3
.Ltmp1:
	.loc	2 40 22
	s_add_i32 s3, s8, 0x7f
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s7, s3, 31
.Ltmp2:
	.loc	1 33 22 is_stmt 1
	s_xor_b32 s2, s2, s0
.Ltmp3:
	.loc	2 40 28
	s_lshr_b32 s7, s7, 25
.Ltmp4:
	.loc	1 33 22
	s_sub_i32 s0, s2, s0
.Ltmp5:
	.loc	2 40 28
	s_add_i32 s3, s3, s7
.Ltmp6:
	.loc	1 34 29
	s_lshl_b32 s2, s0, 3
.Ltmp7:
	.loc	2 40 28
	s_ashr_i32 s3, s3, 7
.Ltmp8:
	.loc	1 35 35
	s_sub_i32 s3, s3, s2
	.loc	1 35 48 is_stmt 0
	s_min_i32 s3, s3, 8
	.loc	1 37 40 is_stmt 1
	s_ashr_i32 s7, s3, 31
	s_add_i32 s12, s3, s7
	s_xor_b32 s12, s12, s7
	v_cvt_f32_u32_e32 v1, s12
	.loc	1 36 34
	s_mul_i32 s0, s0, s1
	s_sub_i32 s0, s6, s0
	.loc	1 37 40
	s_ashr_i32 s1, s0, 31
	v_rcp_iflag_f32_e32 v1, v1
	s_add_i32 s6, s0, s1
	s_xor_b32 s6, s6, s1
	s_xor_b32 s1, s1, s7
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_sub_i32 s7, 0, s12
	v_readfirstlane_b32 s13, v1
	s_mul_i32 s7, s7, s13
	s_mul_hi_u32 s7, s13, s7
	s_add_i32 s13, s13, s7
	s_mul_hi_u32 s7, s6, s13
	s_mul_i32 s13, s7, s12
	s_sub_i32 s6, s6, s13
	s_add_i32 s13, s7, 1
	s_sub_i32 s14, s6, s12
	s_cmp_ge_u32 s6, s12
	s_cselect_b32 s7, s13, s7
	s_cselect_b32 s6, s14, s6
	s_add_i32 s13, s7, 1
	s_cmp_ge_u32 s6, s12
	s_cselect_b32 s6, s13, s7
	.loc	1 39 58
	s_ashr_i32 s7, s8, 31
	s_add_i32 s12, s8, s7
	s_xor_b32 s18, s12, s7
	v_cvt_f32_u32_e32 v1, s18
	.loc	1 36 54
	s_add_i32 s0, s0, s2
	.loc	1 37 40
	s_xor_b32 s2, s6, s1
	s_sub_i32 s20, s2, s1
	.loc	1 39 58
	v_rcp_iflag_f32_e32 v1, v1
	s_sub_i32 s1, 0, s18
	.loc	1 36 54
	s_mul_i32 s3, s3, s20
	.loc	1 36 27 is_stmt 0
	s_sub_i32 s0, s0, s3
	.loc	1 39 58 is_stmt 1
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	.loc	1 39 23 is_stmt 0
	s_lshl_b32 s22, s0, 7
	.loc	1 39 33
	v_or_b32_e32 v3, s22, v15
.Ltmp9:
	.loc	2 40 22 is_stmt 1
	s_load_dwordx4 s[12:15], s[4:5], 0x0
	s_load_dwordx2 s[6:7], s[4:5], 0x10
.Ltmp10:
	.loc	1 39 58
	v_mul_lo_u32 v2, s1, v1
	s_bfe_i32 s1, s0, 0x10018
	v_add_u32_e32 v3, s1, v3
	v_xor_b32_e32 v3, s1, v3
	v_mul_hi_u32 v2, v1, v2
	s_mov_b32 s0, 0
	buffer_store_dword v0, off, s[28:31], 0 offset:4
	v_add_u32_e32 v1, v1, v2
	v_mul_hi_u32 v1, v3, v1
	v_mul_lo_u32 v1, v1, s18
	v_sub_u32_e32 v1, v3, v1
	v_subrev_u32_e32 v2, s18, v1
	v_cmp_le_u32_e32 vcc, s18, v1
	v_cndmask_b32_e32 v1, v1, v2, vcc
	v_subrev_u32_e32 v2, s18, v1
	v_cmp_le_u32_e32 vcc, s18, v1
	v_cndmask_b32_e32 v1, v1, v2, vcc
	v_xor_b32_e32 v1, s1, v1
	v_subrev_u32_e32 v1, s1, v1
	.loc	1 43 59
	v_and_b32_e32 v2, 24, v7
	.loc	1 43 52 is_stmt 0
	v_mad_u64_u32 v[65:66], s[2:3], v1, s11, v[2:3]
.Ltmp11:
	.loc	2 40 22 is_stmt 1
	s_add_i32 s11, s10, 31
	v_mov_b32_e32 v0, v2
.Ltmp12:
	.loc	1 47 22
	s_cmp_gt_i32 s11, 31
	.loc	1 48 51
	buffer_store_dword v0, off, s[28:31], 0 offset:12
	buffer_store_dword v1, off, s[28:31], 0 offset:16
	.loc	1 48 20 is_stmt 0
	v_ashrrev_i32_e32 v66, 31, v65
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	.loc	1 47 22 is_stmt 1
	s_cselect_b64 s[18:19], -1, 0
	.loc	1 48 51
	v_cmp_gt_i32_e32 vcc, s10, v2
	s_mov_b32 s1, s0
	v_lshlrev_b64 v[5:6], 1, v[65:66]
	.loc	1 48 20 is_stmt 0
	v_mov_b64_e32 v[3:4], s[2:3]
	.loc	1 47 22 is_stmt 1
	s_and_b64 s[24:25], vcc, s[18:19]
	.loc	1 48 20
	v_mov_b64_e32 v[1:2], s[0:1]
	s_and_saveexec_b64 s[4:5], s[24:25]
	s_cbranch_execz .LBB0_2
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v2, s13
	v_add_co_u32_e32 v1, vcc, s12, v5
	v_addc_co_u32_e32 v2, vcc, v2, v6, vcc
	global_load_dwordx4 v[1:4], v[1:2], off
.LBB0_2:
	.loc	1 0 20 is_stmt 0
	s_or_b64 exec, exec, s[4:5]
	.loc	1 40 58 is_stmt 1
	s_ashr_i32 s4, s9, 31
	s_add_i32 s5, s9, s4
	s_xor_b32 s5, s5, s4
	v_cvt_f32_u32_e32 v5, s5
	s_sub_i32 s4, 0, s5
	.loc	1 40 46 is_stmt 0
	v_and_b32_e32 v17, 0xf8, v7
	.loc	1 40 58
	v_rcp_iflag_f32_e32 v5, v5
	v_mul_f32_e32 v5, 0x4f7ffffe, v5
	v_cvt_u32_f32_e32 v5, v5
	v_mul_lo_u32 v6, s4, v5
	.loc	1 40 23
	s_lshl_b32 s4, s20, 8
	.loc	1 40 58
	s_bfe_i32 s20, s20, 0x10017
	.loc	1 40 33
	v_or_b32_e32 v0, s4, v17
	buffer_store_dword v0, off, s[28:31], 0 offset:68
	.loc	1 40 58
	v_add_u32_e32 v7, s20, v0
	.loc	1 44 28 is_stmt 1
	buffer_load_dword v0, off, s[28:31], 0 offset:4
	.loc	1 40 58
	v_mul_hi_u32 v6, v5, v6
	v_xor_b32_e32 v7, s20, v7
	v_add_u32_e32 v5, v5, v6
	v_mul_hi_u32 v5, v7, v5
	v_mul_lo_u32 v5, v5, s5
	v_sub_u32_e32 v5, v7, v5
	v_subrev_u32_e32 v6, s5, v5
	v_cmp_le_u32_e32 vcc, s5, v5
	v_cndmask_b32_e32 v5, v5, v6, vcc
	v_subrev_u32_e32 v6, s5, v5
	v_cmp_le_u32_e32 vcc, s5, v5
	v_cndmask_b32_e32 v5, v5, v6, vcc
	v_xor_b32_e32 v5, s20, v5
	v_subrev_u32_e32 v5, s20, v5
	.loc	1 44 28
	s_waitcnt vmcnt(0)
	v_lshrrev_b32_e32 v0, 5, v0
	.loc	1 44 51 is_stmt 0
	v_mad_u64_u32 v[67:68], s[20:21], v0, s16, v[5:6]
	.loc	1 49 51 is_stmt 1
	v_cmp_gt_i32_e32 vcc, s10, v0
	.loc	1 49 20 is_stmt 0
	v_mov_b64_e32 v[7:8], s[2:3]
	v_ashrrev_i32_e32 v68, 31, v67
	v_lshlrev_b64 v[9:10], 1, v[67:68]
	.loc	1 47 22 is_stmt 1
	s_and_b64 s[20:21], vcc, s[18:19]
	.loc	1 49 20
	v_mov_b64_e32 v[5:6], s[0:1]
	buffer_store_dword v0, off, s[28:31], 0 offset:56
	s_and_saveexec_b64 s[0:1], s[20:21]
	s_cbranch_execz .LBB0_4
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v6, s15
	v_add_co_u32_e32 v5, vcc, s14, v9
	v_addc_co_u32_e32 v6, vcc, v6, v10, vcc
	global_load_dwordx4 v[5:8], v[5:6], off
.LBB0_4:
	.loc	1 0 20 is_stmt 0
	s_or_b64 exec, exec, s[0:1]
	.loc	1 44 28 is_stmt 1
	buffer_load_dword v0, off, s[28:31], 0 offset:4
	v_lshl_add_u32 v69, s16, 4, v67
	s_mov_b32 s0, 0
	.loc	1 49 20
	v_ashrrev_i32_e32 v70, 31, v69
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	s_mov_b32 s1, s0
	v_lshlrev_b64 v[13:14], 1, v[69:70]
	v_mov_b64_e32 v[11:12], s[2:3]
	v_mov_b64_e32 v[9:10], s[0:1]
	.loc	1 44 28
	s_waitcnt vmcnt(0)
	v_lshrrev_b32_e32 v0, 5, v0
	v_or_b32_e32 v0, 16, v0
	.loc	1 49 51
	v_cmp_gt_i32_e32 vcc, s10, v0
	.loc	1 47 22
	s_and_b64 s[20:21], vcc, s[18:19]
	buffer_store_dword v0, off, s[28:31], 0 offset:8
	.loc	1 49 20
	s_and_saveexec_b64 s[0:1], s[20:21]
	s_cbranch_execz .LBB0_6
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v10, s15
	v_add_co_u32_e32 v9, vcc, s14, v13
	v_addc_co_u32_e32 v10, vcc, v10, v14, vcc
	global_load_dwordx4 v[9:12], v[9:10], off
.LBB0_6:
	.loc	1 0 20 is_stmt 0
	s_or_b64 exec, exec, s[0:1]
	buffer_load_dword v20, off, s[28:31], 0 offset:4
	.loc	1 39 46 is_stmt 1
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v18, 63, v20
	v_lshrrev_b32_e32 v19, 6, v20
	buffer_load_dword v21, off, s[28:31], 0 offset:12
	s_nop 0
	buffer_load_dword v22, off, s[28:31], 0 offset:16
	.loc	1 48 20
	v_lshrrev_b32_e32 v13, 1, v20
	v_and_b32_e32 v16, 24, v13
	v_lshlrev_b32_e32 v15, 5, v15
	.loc	1 47 22
	s_cmp_gt_i32 s11, 63
	s_waitcnt vmcnt(1)
	v_mov_b32_e32 v0, v21
	.loc	1 48 20
	v_and_or_b32 v14, v13, 4, v0
	v_xor_b32_e32 v14, v14, v16
	v_or_b32_e32 v14, v14, v15
	v_lshl_add_u32 v14, v14, 1, 0
	ds_write_b64 v14, v[1:2]
	v_or_b32_e32 v1, 4, v0
	v_and_b32_e32 v2, 28, v13
	v_xor_b32_e32 v1, v1, v2
	v_or_b32_e32 v1, v1, v15
	v_lshl_add_u32 v0, v1, 1, 0
	buffer_store_dword v0, off, s[28:31], 0 offset:24
	ds_write_b64 v0, v[3:4]
	.loc	1 49 20
	v_lshlrev_b32_e32 v1, 1, v17
	v_lshrrev_b32_e32 v0, 5, v20
	v_lshl_or_b32 v1, v0, 9, v1
	v_add_u32_e32 v71, 0, v1
	v_lshrrev_b32_e32 v1, 4, v20
	v_and_b32_e32 v3, 15, v20
	v_lshrrev_b32_e32 v0, 4, v18
	v_lshlrev_b32_e32 v2, 4, v19
	buffer_store_dword v14, off, s[28:31], 0 offset:20
	ds_write_b128 v71, v[5:8] offset:8192
	ds_write_b128 v71, v[9:12] offset:16384
	buffer_store_dword v18, off, s[28:31], 0 offset:72
	buffer_store_dword v19, off, s[28:31], 0 offset:76
	.loc	1 47 22
	buffer_store_dword v17, off, s[28:31], 0 offset:60
	buffer_store_dword v18, off, s[28:31], 0 offset:64
	s_cbranch_scc1 .LBB0_8
	.loc	1 0 22 is_stmt 0
	buffer_store_dword v0, off, s[28:31], 0 offset:80
	buffer_store_dword v3, off, s[28:31], 0 offset:92
	.loc	1 48 20 is_stmt 1
	v_and_or_b32 v0, v1, 16, v3
	.loc	1 49 20
	buffer_store_dword v0, off, s[28:31], 0 offset:84
	v_and_b32_e32 v0, 48, v2
	s_mov_b64 s[0:1], 0
	s_mov_b32 s2, 0
	buffer_store_dword v0, off, s[28:31], 0 offset:88
	s_branch .LBB0_9
.LBB0_8:
	.loc	1 0 20 is_stmt 0
	s_mov_b64 s[0:1], -1
.LBB0_9:
	buffer_load_dword v0, off, s[28:31], 0 offset:4
	.loc	1 47 22 is_stmt 1
	s_andn2_b64 vcc, exec, s[0:1]
	v_mov_b32_e32 v4, s2
	v_mov_b32_e32 v3, s2
	v_mov_b32_e32 v2, s2
	v_mov_b32_e32 v1, s2
	v_mov_b32_e32 v8, s2
	v_mov_b32_e32 v7, s2
	v_mov_b32_e32 v6, s2
	v_mov_b32_e32 v5, s2
	v_mov_b32_e32 v12, s2
	v_mov_b32_e32 v11, s2
	v_mov_b32_e32 v10, s2
	v_mov_b32_e32 v9, s2
	v_mov_b32_e32 v16, s2
	v_mov_b32_e32 v15, s2
	v_mov_b32_e32 v14, s2
	v_mov_b32_e32 v13, s2
	v_mov_b32_e32 v20, s2
	v_mov_b32_e32 v19, s2
	v_mov_b32_e32 v18, s2
	v_mov_b32_e32 v17, s2
	v_mov_b32_e32 v24, s2
	v_mov_b32_e32 v23, s2
	s_waitcnt vmcnt(7)
	v_mov_b32_e32 v22, s2
	v_mov_b32_e32 v21, s2
	v_mov_b32_e32 v28, s2
	v_mov_b32_e32 v27, s2
	v_mov_b32_e32 v26, s2
	v_mov_b32_e32 v25, s2
	v_mov_b32_e32 v32, s2
	v_mov_b32_e32 v31, s2
	v_mov_b32_e32 v30, s2
	v_mov_b32_e32 v29, s2
	v_mov_b32_e32 v36, s2
	v_mov_b32_e32 v35, s2
	v_mov_b32_e32 v34, s2
	v_mov_b32_e32 v33, s2
	v_mov_b32_e32 v40, s2
	v_mov_b32_e32 v39, s2
	v_mov_b32_e32 v38, s2
	v_mov_b32_e32 v37, s2
	v_mov_b32_e32 v44, s2
	v_mov_b32_e32 v43, s2
	v_mov_b32_e32 v42, s2
	v_mov_b32_e32 v41, s2
	v_mov_b32_e32 v48, s2
	v_mov_b32_e32 v47, s2
	v_mov_b32_e32 v46, s2
	v_mov_b32_e32 v45, s2
	v_mov_b32_e32 v52, s2
	v_mov_b32_e32 v51, s2
	v_mov_b32_e32 v50, s2
	v_mov_b32_e32 v49, s2
	v_mov_b32_e32 v56, s2
	v_mov_b32_e32 v55, s2
	v_mov_b32_e32 v54, s2
	v_mov_b32_e32 v53, s2
	v_mov_b32_e32 v64, s2
	v_mov_b32_e32 v63, s2
	v_mov_b32_e32 v62, s2
	v_mov_b32_e32 v61, s2
	v_mov_b32_e32 v60, s2
	v_mov_b32_e32 v59, s2
	v_mov_b32_e32 v58, s2
	v_mov_b32_e32 v57, s2
	s_waitcnt vmcnt(0)
	v_bfe_u32 v72, v0, 1, 3
	s_cbranch_vccnz .LBB0_18
	.loc	1 0 22 is_stmt 0
	buffer_load_dword v5, off, s[28:31], 0 offset:4
	v_add_u32_e32 v0, 0x2000, v71
.Ltmp13:
	.loc	2 40 28 is_stmt 1
	buffer_store_dword v0, off, s[28:31], 0 offset:28
	s_add_i32 s5, 0, 0x2000
.Ltmp14:
	.loc	1 52 28
	s_lshl_b32 s2, s16, 5
	s_ashr_i32 s3, s2, 31
.Ltmp15:
	.loc	2 40 28
	s_lshr_b32 s1, s11, 5
.Ltmp16:
	.loc	1 47 22
	s_lshl_b64 s[20:21], s[2:3], 1
	v_mov_b32_e32 v57, 0
	s_mov_b32 s0, 0
	v_mov_b32_e32 v58, v57
	v_mov_b32_e32 v59, v57
	v_mov_b32_e32 v60, v57
	v_mov_b32_e32 v61, v57
	v_mov_b32_e32 v62, v57
	v_mov_b32_e32 v63, v57
	v_mov_b32_e32 v64, v57
	v_mov_b32_e32 v53, v57
	v_mov_b32_e32 v54, v57
	v_mov_b32_e32 v55, v57
	v_mov_b32_e32 v56, v57
	v_mov_b32_e32 v49, v57
	v_mov_b32_e32 v50, v57
	v_mov_b32_e32 v51, v57
	v_mov_b32_e32 v52, v57
	v_mov_b32_e32 v45, v57
	v_mov_b32_e32 v46, v57
	v_mov_b32_e32 v47, v57
	v_mov_b32_e32 v48, v57
	v_mov_b32_e32 v41, v57
	v_mov_b32_e32 v42, v57
	v_mov_b32_e32 v43, v57
	v_mov_b32_e32 v44, v57
	v_mov_b32_e32 v37, v57
	v_mov_b32_e32 v38, v57
	v_mov_b32_e32 v39, v57
	v_mov_b32_e32 v40, v57
	v_mov_b32_e32 v33, v57
	v_mov_b32_e32 v34, v57
	v_mov_b32_e32 v35, v57
	v_mov_b32_e32 v36, v57
	v_mov_b32_e32 v29, v57
	v_mov_b32_e32 v30, v57
	v_mov_b32_e32 v31, v57
	v_mov_b32_e32 v32, v57
	v_mov_b32_e32 v25, v57
	v_mov_b32_e32 v26, v57
	v_mov_b32_e32 v27, v57
	v_mov_b32_e32 v28, v57
	v_mov_b32_e32 v21, v57
	v_mov_b32_e32 v22, v57
	v_mov_b32_e32 v23, v57
	v_mov_b32_e32 v24, v57
	v_mov_b32_e32 v17, v57
	v_mov_b32_e32 v18, v57
	v_mov_b32_e32 v19, v57
	v_mov_b32_e32 v20, v57
	v_mov_b32_e32 v13, v57
	v_mov_b32_e32 v14, v57
	v_mov_b32_e32 v15, v57
	v_mov_b32_e32 v16, v57
	v_mov_b32_e32 v9, v57
	v_mov_b32_e32 v10, v57
	v_mov_b32_e32 v11, v57
	v_mov_b32_e32 v12, v57
	v_mov_b32_e32 v7, v57
	v_mov_b32_e32 v8, v57
	s_waitcnt vmcnt(1)
	v_lshrrev_b32_e32 v1, 4, v5
	v_and_b32_e32 v6, 15, v5
	v_and_b32_e32 v0, 63, v5
	v_lshrrev_b32_e32 v4, 4, v0
	v_and_or_b32 v0, v1, 16, v6
	v_xor_b32_e32 v1, v4, v72
	v_or_b32_e32 v2, 4, v4
	v_lshlrev_b32_e32 v3, 6, v0
	v_xor_b32_e32 v2, v2, v72
	v_lshl_or_b32 v1, v1, 3, v3
	buffer_store_dword v0, off, s[28:31], 0 offset:84
	v_add_u32_e32 v0, 0, v1
	v_lshl_or_b32 v1, v2, 3, v3
	buffer_store_dword v0, off, s[28:31], 0 offset:32
	v_add_u32_e32 v0, 0, v1
	buffer_store_dword v0, off, s[28:31], 0 offset:36
	v_lshrrev_b32_e32 v0, 6, v5
	v_lshlrev_b32_e32 v1, 4, v0
	v_and_b32_e32 v0, 48, v1
	v_lshlrev_b32_e32 v1, 10, v4
	v_or3_b32 v1, v1, v6, v0
	v_lshl_add_u32 v103, v1, 1, s5
	v_lshlrev_b64 v[1:2], 1, v[69:70]
	buffer_store_dword v4, off, s[28:31], 0 offset:80
	buffer_store_dword v0, off, s[28:31], 0 offset:88
	buffer_store_dword v6, off, s[28:31], 0 offset:92
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v3, s15
	v_add_co_u32_e32 v0, vcc, s14, v1
	buffer_store_dword v0, off, s[28:31], 0 offset:40
	v_addc_co_u32_e32 v0, vcc, v3, v2, vcc
	v_lshlrev_b64 v[1:2], 1, v[67:68]
	buffer_store_dword v0, off, s[28:31], 0 offset:44
	v_add_co_u32_e32 v0, vcc, s14, v1
	buffer_store_dword v0, off, s[28:31], 0 offset:48
	v_addc_co_u32_e32 v0, vcc, v3, v2, vcc
	v_lshlrev_b64 v[1:2], 1, v[65:66]
	v_mov_b32_e32 v3, s13
	v_add_co_u32_e32 v1, vcc, s12, v1
	v_addc_co_u32_e32 v2, vcc, v2, v3, vcc
	v_add_co_u32_e32 v87, vcc, 64, v1
	v_addc_co_u32_e32 v88, vcc, 0, v2, vcc
	s_add_i32 s5, s1, -1
	s_sub_i32 s14, s10, 32
	s_mov_b32 s15, 0x5040100
	s_mov_b64 s[10:11], s[20:21]
	v_mov_b32_e32 v5, v57
	v_mov_b32_e32 v6, v57
	v_mov_b32_e32 v1, v57
	v_mov_b32_e32 v2, v57
	v_mov_b32_e32 v3, v57
	v_mov_b32_e32 v4, v57
	buffer_store_dword v0, off, s[28:31], 0 offset:52
	s_branch .LBB0_12
.LBB0_11:
	.loc	1 0 22 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 48 20 is_stmt 1
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	s_barrier
	buffer_load_dword v0, off, s[28:31], 0 offset:32
	buffer_load_dword v77, off, s[28:31], 0 offset:36
	v_add_u32_e32 v99, 0x100, v103
	v_mov_b32_e32 v101, v99
	v_add_u32_e32 v105, 0x180, v103
	v_add_u32_e32 v108, 0x2180, v103
	v_mov_b32_e32 v107, v105
	v_mov_b32_e32 v110, v108
	s_waitcnt vmcnt(1)
	ds_read2st64_b64 v[115:118], v0 offset1:4
	s_waitcnt vmcnt(0)
	ds_read2st64_b64 v[119:122], v77 offset1:4
	ds_read2st64_b64 v[81:84], v0 offset0:8 offset1:12
	ds_read2st64_b64 v[77:80], v77 offset0:8 offset1:12
	.loc	1 49 20
	ds_read_u16 v85, v103 offset:1536
	ds_read_u16 v86, v103 offset:8192
	v_add_u32_e32 v0, 0x2000, v103
	v_mov_b32_e32 v100, v0
	ds_read_u16 v89, v0 offset:1536
	v_add_u32_e32 v0, 0x80, v103
	ds_read_u16 v90, v0 offset:512
	ds_read_u16 v91, v0 offset:1024
	ds_read_u16 v92, v103
	ds_read_u16 v93, v103 offset:128
	ds_read_u16 v97, v103 offset:256
	ds_read_u16 v94, v103 offset:8320
	ds_read_u16 v98, v103 offset:8448
	ds_read_u16 v95, v0 offset:1536
	v_add_u32_e32 v0, 0x2080, v103
	ds_read_u16 v127, v0 offset:512
	ds_read_u16 v96, v0 offset:1024
	ds_read_u16 v0, v0 offset:1536
	ds_read_u16 v99, v99 offset:512
	ds_read_u16 v111, v101 offset:1024
	ds_read_u16 v112, v101 offset:1536
	v_add_u32_e32 v101, 0x2100, v103
	v_mov_b32_e32 v104, v101
	ds_read_u16 v113, v101 offset:512
	ds_read_u16 v123, v103 offset:1024
	ds_read_u16 v125, v103 offset:512
	ds_read_u16 v114, v103 offset:384
	ds_read_u16 v126, v100 offset:1024
	ds_read_u16 v100, v100 offset:512
	ds_read_u16 v101, v103 offset:8576
	ds_read_u16 v102, v104 offset:1024
	ds_read_u16 v104, v104 offset:1536
	ds_read_u16 v105, v105 offset:512
	ds_read_u16 v106, v107 offset:1024
	ds_read_u16 v107, v107 offset:1536
	ds_read_u16 v108, v108 offset:512
	ds_read_u16 v109, v110 offset:1024
	ds_read_u16 v110, v110 offset:1536
	.loc	1 50 27
	s_waitcnt lgkmcnt(13)
	v_perm_b32 v124, v85, v123, s15
	s_waitcnt lgkmcnt(12)
	v_perm_b32 v123, v125, v92, s15
	s_waitcnt lgkmcnt(10)
	v_perm_b32 v126, v89, v126, s15
	s_waitcnt lgkmcnt(9)
	v_perm_b32 v125, v100, v86, s15
	v_perm_b32 v92, v95, v91, s15
	v_perm_b32 v91, v90, v93, s15
	v_perm_b32 v96, v0, v96, s15
	v_perm_b32 v95, v127, v94, s15
	v_perm_b32 v94, v112, v111, s15
	v_perm_b32 v93, v99, v97, s15
	s_waitcnt lgkmcnt(6)
	v_perm_b32 v90, v104, v102, s15
	v_perm_b32 v89, v113, v98, s15
	s_waitcnt lgkmcnt(3)
	v_perm_b32 v98, v107, v106, s15
	v_perm_b32 v97, v105, v114, s15
	s_waitcnt lgkmcnt(0)
	v_perm_b32 v86, v110, v109, s15
	v_perm_b32 v85, v108, v101, s15
	s_setprio 1
	v_mmac_f32_16x16x16_f16 v[57:60], v[115:116], v[123:124], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[115:116], v[91:92], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[115:116], v[93:94], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[115:116], v[97:98], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[117:118], v[123:124], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[117:118], v[91:92], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[117:118], v[93:94], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[117:118], v[97:98], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[81:82], v[123:124], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[81:82], v[91:92], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[81:82], v[93:94], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[81:82], v[97:98], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[83:84], v[123:124], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[83:84], v[91:92], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[83:84], v[93:94], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[83:84], v[97:98], v[1:4]
	v_mmac_f32_16x16x16_f16 v[57:60], v[119:120], v[125:126], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[119:120], v[95:96], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[119:120], v[89:90], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[119:120], v[85:86], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[121:122], v[125:126], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[121:122], v[95:96], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[121:122], v[89:90], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[121:122], v[85:86], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[77:78], v[125:126], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[77:78], v[95:96], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[77:78], v[89:90], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[77:78], v[85:86], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[79:80], v[125:126], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[79:80], v[95:96], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[79:80], v[89:90], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[79:80], v[85:86], v[1:4]
	s_setprio 0
	.loc	1 48 20
	s_barrier
	s_barrier
	buffer_load_dword v0, off, s[28:31], 0 offset:20
	s_waitcnt vmcnt(0)
	ds_write_b64 v0, v[65:66]
	buffer_load_dword v0, off, s[28:31], 0 offset:24
	s_waitcnt vmcnt(0)
	ds_write_b64 v0, v[67:68]
	buffer_load_dword v0, off, s[28:31], 0 offset:28
	.loc	1 49 20
	s_waitcnt vmcnt(0)
	ds_write_b128 v0, v[69:72]
	ds_write_b128 v0, v[73:76] offset:8192
	.loc	1 47 22
	s_add_u32 s10, s10, s20
	s_addc_u32 s11, s11, s21
	s_add_i32 s5, s5, -1
	s_sub_i32 s14, s14, 32
	v_add_co_u32_e32 v87, vcc, 64, v87
	s_cmp_lg_u32 s5, 0
	v_addc_co_u32_e32 v88, vcc, 0, v88, vcc
	s_cbranch_scc0 .LBB0_18
.LBB0_12:
	.loc	1 48 51
	buffer_load_dword v65, off, s[28:31], 0 offset:12
	s_nop 0
	buffer_load_dword v66, off, s[28:31], 0 offset:16
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	s_mov_b32 s1, s0
	s_waitcnt vmcnt(1)
	v_cmp_gt_i32_e32 vcc, s14, v65
	.loc	1 48 20 is_stmt 0
	s_waitcnt vmcnt(0)
	v_mov_b64_e32 v[67:68], s[2:3]
	v_mov_b64_e32 v[65:66], s[0:1]
	s_and_saveexec_b64 s[12:13], vcc
	s_cbranch_execz .LBB0_14
	global_load_dwordx4 v[65:68], v[87:88], off
.LBB0_14:
	.loc	1 0 20
	s_or_b64 exec, exec, s[12:13]
	.loc	1 49 51 is_stmt 1
	buffer_load_dword v0, off, s[28:31], 0 offset:4
	.loc	1 49 20 is_stmt 0
	v_mov_b64_e32 v[71:72], s[2:3]
	v_mov_b64_e32 v[69:70], s[0:1]
	.loc	1 49 51
	s_waitcnt vmcnt(0)
	v_lshrrev_b32_e32 v0, 5, v0
	v_cmp_gt_i32_e32 vcc, s14, v0
	.loc	1 49 20
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_16
	buffer_load_dword v0, off, s[28:31], 0 offset:48
	v_mov_b32_e32 v70, s11
	s_waitcnt vmcnt(0)
	v_add_co_u32_e32 v69, vcc, s10, v0
	buffer_load_dword v0, off, s[28:31], 0 offset:52
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v70, vcc, v0, v70, vcc
	global_load_dwordx4 v[69:72], v[69:70], off
.LBB0_16:
	.loc	1 0 20
	s_or_b64 exec, exec, s[2:3]
	.loc	1 49 51
	buffer_load_dword v0, off, s[28:31], 0 offset:8
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	s_mov_b32 s1, s0
	.loc	1 49 20
	v_mov_b64_e32 v[75:76], s[2:3]
	v_mov_b64_e32 v[73:74], s[0:1]
	.loc	1 49 51
	s_waitcnt vmcnt(0)
	v_cmp_gt_i32_e32 vcc, s14, v0
	.loc	1 49 20
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_11
	buffer_load_dword v0, off, s[28:31], 0 offset:40
	v_mov_b32_e32 v74, s11
	s_waitcnt vmcnt(0)
	v_add_co_u32_e32 v73, vcc, s10, v0
	buffer_load_dword v0, off, s[28:31], 0 offset:44
	s_waitcnt vmcnt(0)
	v_addc_co_u32_e32 v74, vcc, v0, v74, vcc
	global_load_dwordx4 v[73:76], v[73:74], off
	s_branch .LBB0_11
.LBB0_18:
	.loc	1 50 27 is_stmt 1
	s_andn2_b64 vcc, exec, s[18:19]
	.loc	1 48 20
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	.loc	1 50 27
	s_cbranch_vccnz .LBB0_20
	.loc	1 0 27 is_stmt 0
	buffer_load_dword v112, off, s[28:31], 0 offset:80
	.loc	1 49 20 is_stmt 1
	buffer_load_dword v0, off, s[28:31], 0 offset:92
	buffer_load_dword v114, off, s[28:31], 0 offset:88
	s_add_i32 s0, 0, 0x2000
	s_waitcnt vmcnt(1)
	v_lshl_or_b32 v0, v112, 10, v0
	s_waitcnt vmcnt(0)
	v_add_u32_e32 v65, v0, v114
	v_or_b32_e32 v0, v0, v114
	v_lshl_add_u32 v65, v65, 1, s0
	v_lshl_add_u32 v0, v0, 1, s0
	ds_read_u16 v0, v0
	ds_read_u16 v95, v65 offset:10112
	ds_read_u16 v91, v65 offset:9984
	ds_read_u16 v87, v65 offset:9856
	ds_read_u16 v83, v65 offset:9728
	ds_read_u16 v96, v65 offset:9600
	ds_read_u16 v92, v65 offset:9472
	ds_read_u16 v88, v65 offset:9344
	ds_read_u16 v84, v65 offset:9216
	ds_read_u16 v97, v65 offset:9088
	ds_read_u16 v93, v65 offset:8960
	ds_read_u16 v89, v65 offset:8832
	ds_read_u16 v85, v65 offset:8704
	ds_read_u16 v98, v65 offset:8576
	ds_read_u16 v94, v65 offset:8448
	ds_read_u16 v90, v65 offset:8320
	ds_read_u16 v86, v65 offset:8192
	ds_read_u16 v99, v65 offset:1920
	ds_read_u16 v100, v65 offset:1792
	ds_read_u16 v101, v65 offset:1664
	ds_read_u16 v81, v65 offset:1536
	ds_read_u16 v102, v65 offset:1408
	ds_read_u16 v103, v65 offset:1280
	ds_read_u16 v104, v65 offset:1152
	ds_read_u16 v82, v65 offset:1024
	ds_read_u16 v105, v65 offset:896
	ds_read_u16 v106, v65 offset:768
	ds_read_u16 v107, v65 offset:640
	ds_read_u16 v108, v65 offset:512
	ds_read_u16 v109, v65 offset:384
	ds_read_u16 v110, v65 offset:256
	ds_read_u16 v111, v65 offset:128
	buffer_load_dword v113, off, s[28:31], 0 offset:84
	.loc	1 48 20
	buffer_load_dword v65, off, s[28:31], 0 offset:4
	.loc	1 50 27
	s_mov_b32 s0, 0x5040100
	s_waitcnt lgkmcnt(7)
	v_perm_b32 v82, v81, v82, s0
	s_waitcnt lgkmcnt(3)
	v_perm_b32 v81, v108, v0, s0
	v_perm_b32 v84, v83, v84, s0
	v_perm_b32 v83, v85, v86, s0
	v_perm_b32 v86, v101, v104, s0
	s_waitcnt lgkmcnt(0)
	v_perm_b32 v85, v107, v111, s0
	v_perm_b32 v88, v87, v88, s0
	v_perm_b32 v87, v89, v90, s0
	v_perm_b32 v90, v100, v103, s0
	v_perm_b32 v89, v106, v110, s0
	v_perm_b32 v92, v91, v92, s0
	v_perm_b32 v91, v93, v94, s0
	v_perm_b32 v94, v99, v102, s0
	v_perm_b32 v93, v105, v109, s0
	v_perm_b32 v96, v95, v96, s0
	v_perm_b32 v95, v97, v98, s0
	.loc	1 48 20
	s_waitcnt vmcnt(1)
	v_lshlrev_b32_e32 v69, 5, v113
	s_waitcnt vmcnt(0)
	v_bfe_u32 v70, v65, 1, 3
	v_or_b32_e32 v65, 4, v112
	v_xor_b32_e32 v65, v65, v70
	v_xor_b32_e32 v70, v112, v70
	v_lshl_add_u32 v65, v65, 2, v69
	v_lshl_add_u32 v69, v70, 2, v69
	v_lshl_add_u32 v73, v65, 1, 0
	v_lshl_add_u32 v77, v69, 1, 0
	ds_read2st64_b64 v[65:68], v73 offset0:8 offset1:12
	ds_read2st64_b64 v[69:72], v77 offset0:8 offset1:12
	ds_read2st64_b64 v[73:76], v73 offset1:4
	ds_read2st64_b64 v[77:80], v77 offset1:4
	.loc	1 50 27
	s_setprio 1
	s_waitcnt lgkmcnt(0)
	v_mmac_f32_16x16x16_f16 v[57:60], v[77:78], v[81:82], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[77:78], v[85:86], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[77:78], v[89:90], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[77:78], v[93:94], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[79:80], v[81:82], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[79:80], v[85:86], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[79:80], v[89:90], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[79:80], v[93:94], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[69:70], v[81:82], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[69:70], v[85:86], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[69:70], v[89:90], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[69:70], v[93:94], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[71:72], v[81:82], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[71:72], v[85:86], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[71:72], v[89:90], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[71:72], v[93:94], v[1:4]
	v_mmac_f32_16x16x16_f16 v[57:60], v[73:74], v[83:84], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[73:74], v[87:88], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[73:74], v[91:92], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[73:74], v[95:96], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[75:76], v[83:84], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[75:76], v[87:88], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[75:76], v[91:92], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[75:76], v[95:96], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[65:66], v[83:84], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[65:66], v[87:88], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[65:66], v[91:92], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[65:66], v[95:96], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[67:68], v[83:84], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[67:68], v[87:88], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[67:68], v[91:92], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[67:68], v[95:96], v[1:4]
	s_setprio 0
	s_branch .LBB0_21
.LBB0_20:
	.loc	1 0 27 is_stmt 0
	buffer_load_dword v112, off, s[28:31], 0 offset:80
	buffer_load_dword v113, off, s[28:31], 0 offset:84
	buffer_load_dword v114, off, s[28:31], 0 offset:88
.LBB0_21:
	buffer_load_dword v91, off, s[28:31], 0 offset:56
	.loc	1 54 15 is_stmt 1
	v_cvt_f16_f32_e32 v86, v9
	v_cvt_f16_f32_e32 v90, v8
	buffer_load_dword v8, off, s[28:31], 0 offset:60
	s_nop 0
	buffer_load_dword v9, off, s[28:31], 0 offset:64
	.loc	1 57 21
	s_mul_i32 s0, s22, s17
	s_ashr_i32 s1, s0, 31
	s_lshl_b64 s[0:1], s[0:1], 1
	s_add_u32 s2, s6, s0
	s_addc_u32 s3, s7, s1
	.loc	1 57 52 is_stmt 0
	s_ashr_i32 s5, s4, 31
	s_lshl_b64 s[0:1], s[4:5], 1
	s_add_u32 s4, s2, s0
	.loc	1 54 15 is_stmt 1
	v_cvt_f16_f32_e32 v65, v33
	v_cvt_f16_f32_e32 v69, v32
	.loc	1 57 52
	s_addc_u32 s5, s3, s1
	.loc	1 54 15
	v_cvt_f16_f32_e32 v57, v57
	v_cvt_f16_f32_e32 v5, v5
	v_cvt_f16_f32_e32 v6, v6
	v_cvt_f16_f32_e32 v7, v7
	v_cvt_f16_f32_e32 v1, v1
	v_cvt_f16_f32_e32 v2, v2
	v_cvt_f16_f32_e32 v3, v3
	v_cvt_f16_f32_e32 v4, v4
	v_cvt_f16_f32_e32 v58, v58
	s_movk_i32 s2, 0x108
	v_cvt_f16_f32_e32 v59, v59
	v_cvt_f16_f32_e32 v60, v60
	v_cvt_f16_f32_e32 v61, v61
	v_cvt_f16_f32_e32 v62, v62
	v_cvt_f16_f32_e32 v63, v63
	v_cvt_f16_f32_e32 v64, v64
	v_cvt_f16_f32_e32 v53, v53
	v_cvt_f16_f32_e32 v54, v54
	v_cvt_f16_f32_e32 v55, v55
	v_cvt_f16_f32_e32 v56, v56
	v_cvt_f16_f32_e32 v49, v49
	v_cvt_f16_f32_e32 v50, v50
	v_cvt_f16_f32_e32 v51, v51
	v_cvt_f16_f32_e32 v52, v52
	v_cvt_f16_f32_e32 v45, v45
	v_cvt_f16_f32_e32 v46, v46
	v_cvt_f16_f32_e32 v47, v47
	v_cvt_f16_f32_e32 v48, v48
	v_cvt_f16_f32_e32 v41, v41
	v_cvt_f16_f32_e32 v42, v42
	v_cvt_f16_f32_e32 v43, v43
	v_cvt_f16_f32_e32 v44, v44
	v_cvt_f16_f32_e32 v37, v37
	v_cvt_f16_f32_e32 v38, v38
	v_cvt_f16_f32_e32 v39, v39
	v_cvt_f16_f32_e32 v40, v40
	v_cvt_f16_f32_e32 v34, v34
	v_cvt_f16_f32_e32 v35, v35
	v_cvt_f16_f32_e32 v36, v36
	v_cvt_f16_f32_e32 v66, v29
	v_cvt_f16_f32_e32 v67, v30
	v_cvt_f16_f32_e32 v68, v31
	v_cvt_f16_f32_e32 v70, v25
	v_cvt_f16_f32_e32 v71, v26
	v_cvt_f16_f32_e32 v72, v27
	v_cvt_f16_f32_e32 v73, v28
	v_cvt_f16_f32_e32 v74, v21
	v_cvt_f16_f32_e32 v75, v22
	v_cvt_f16_f32_e32 v76, v23
	v_cvt_f16_f32_e32 v77, v24
	v_cvt_f16_f32_e32 v78, v17
	v_cvt_f16_f32_e32 v79, v18
	v_cvt_f16_f32_e32 v80, v19
	v_cvt_f16_f32_e32 v81, v20
	v_cvt_f16_f32_e32 v82, v13
	v_cvt_f16_f32_e32 v83, v14
	v_cvt_f16_f32_e32 v84, v15
	v_cvt_f16_f32_e32 v85, v16
	v_cvt_f16_f32_e32 v87, v10
	v_cvt_f16_f32_e32 v88, v11
	v_cvt_f16_f32_e32 v89, v12
	.loc	1 39 33
	s_waitcnt vmcnt(2)
	v_or_b32_e32 v0, s22, v91
	s_waitcnt vmcnt(0)
	v_mov_b32_e32 v9, v8
	.loc	1 57 52
	v_mad_u64_u32 v[32:33], s[0:1], v91, s17, v[9:10]
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v0
	.loc	1 58 58 is_stmt 0
	buffer_load_dword v0, off, s[28:31], 0 offset:68
	.loc	1 59 21 is_stmt 1
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	s_waitcnt lgkmcnt(0)
	.loc	1 58 58
	v_cmp_gt_i32_e32 vcc, s9, v0
	.loc	1 59 21
	v_or_b32_e32 v0, v112, v114
	v_mad_i32_i24 v0, v113, s2, v0
	v_lshl_add_u32 v0, v0, 1, 0
	.loc	1 58 39
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21
	ds_write_b16 v0, v57
	ds_write_b16 v0, v58 offset:8
	ds_write_b16 v0, v59 offset:16
	ds_write_b16 v0, v60 offset:24
	ds_write_b16 v0, v61 offset:128
	ds_write_b16 v0, v62 offset:136
	ds_write_b16 v0, v63 offset:144
	ds_write_b16 v0, v64 offset:152
	ds_write_b16 v0, v53 offset:256
	ds_write_b16 v0, v54 offset:264
	ds_write_b16 v0, v55 offset:272
	ds_write_b16 v0, v56 offset:280
	ds_write_b16 v0, v49 offset:384
	ds_write_b16 v0, v50 offset:392
	ds_write_b16 v0, v51 offset:400
	ds_write_b16 v0, v52 offset:408
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	buffer_load_dword v8, off, s[28:31], 0 offset:72
	buffer_load_dword v10, off, s[28:31], 0 offset:76
	s_waitcnt vmcnt(1)
	v_lshrrev_b32_e32 v8, 5, v8
	s_waitcnt vmcnt(0)
	v_lshl_or_b32 v8, v10, 1, v8
	v_mad_u32_u24 v8, v8, s2, v9
	v_lshl_add_u32 v33, v8, 1, 0
	ds_read_b128 v[28:31], v33
	ds_read_b128 v[24:27], v33 offset:8448
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v45
	ds_write_b16 v0, v46 offset:8
	ds_write_b16 v0, v47 offset:16
	ds_write_b16 v0, v48 offset:24
	ds_write_b16 v0, v41 offset:128
	ds_write_b16 v0, v42 offset:136
	ds_write_b16 v0, v43 offset:144
	ds_write_b16 v0, v44 offset:152
	ds_write_b16 v0, v37 offset:256
	ds_write_b16 v0, v38 offset:264
	ds_write_b16 v0, v39 offset:272
	ds_write_b16 v0, v40 offset:280
	ds_write_b16 v0, v65 offset:384
	ds_write_b16 v0, v34 offset:392
	ds_write_b16 v0, v35 offset:400
	ds_write_b16 v0, v36 offset:408
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[20:23], v33
	ds_read_b128 v[16:19], v33 offset:8448
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v66
	ds_write_b16 v0, v67 offset:8
	ds_write_b16 v0, v68 offset:16
	ds_write_b16 v0, v69 offset:24
	ds_write_b16 v0, v70 offset:128
	ds_write_b16 v0, v71 offset:136
	ds_write_b16 v0, v72 offset:144
	ds_write_b16 v0, v73 offset:152
	ds_write_b16 v0, v74 offset:256
	ds_write_b16 v0, v75 offset:264
	ds_write_b16 v0, v76 offset:272
	ds_write_b16 v0, v77 offset:280
	ds_write_b16 v0, v78 offset:384
	ds_write_b16 v0, v79 offset:392
	ds_write_b16 v0, v80 offset:400
	ds_write_b16 v0, v81 offset:408
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[12:15], v33
	ds_read_b128 v[8:11], v33 offset:8448
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v82
	ds_write_b16 v0, v83 offset:8
	ds_write_b16 v0, v84 offset:16
	ds_write_b16 v0, v85 offset:24
	ds_write_b16 v0, v86 offset:128
	ds_write_b16 v0, v87 offset:136
	ds_write_b16 v0, v88 offset:144
	ds_write_b16 v0, v89 offset:152
	ds_write_b16 v0, v5 offset:256
	ds_write_b16 v0, v6 offset:264
	ds_write_b16 v0, v7 offset:272
	ds_write_b16 v0, v90 offset:280
	ds_write_b16 v0, v1 offset:384
	ds_write_b16 v0, v2 offset:392
	ds_write_b16 v0, v3 offset:400
	ds_write_b16 v0, v4 offset:408
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[4:7], v33
	ds_read_b128 v[0:3], v33 offset:8448
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_23
	v_ashrrev_i32_e32 v33, 31, v32
	v_lshlrev_b64 v[33:34], 1, v[32:33]
	v_mov_b32_e32 v35, s5
	v_add_co_u32_e64 v33, s[0:1], s4, v33
	v_addc_co_u32_e64 v34, s[0:1], v35, v34, s[0:1]
	s_waitcnt lgkmcnt(14)
	global_store_dwordx4 v[33:34], v[28:31], off
.LBB0_23:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(14)
	buffer_load_dword v28, off, s[28:31], 0 offset:8
	.loc	1 57 21
	s_lshl_b32 s6, s17, 4
	.loc	1 39 33
	s_waitcnt vmcnt(0)
	v_or_b32_e32 v29, s22, v28
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v29
	v_add_u32_e32 v28, s6, v32
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_25
	v_ashrrev_i32_e32 v29, 31, v28
	v_lshlrev_b64 v[29:30], 1, v[28:29]
	v_mov_b32_e32 v31, s5
	v_add_co_u32_e64 v29, s[0:1], s4, v29
	v_addc_co_u32_e64 v30, s[0:1], v31, v30, s[0:1]
	global_store_dwordx4 v[29:30], v[24:27], off
.LBB0_25:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	buffer_load_dword v24, off, s[28:31], 0 offset:56
	s_waitcnt vmcnt(0)
	v_or3_b32 v25, v24, s22, 32
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v25
	v_add_u32_e32 v24, s6, v28
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_27
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshlrev_b64 v[25:26], 1, v[24:25]
	v_mov_b32_e32 v27, s5
	v_add_co_u32_e64 v25, s[0:1], s4, v25
	v_addc_co_u32_e64 v26, s[0:1], v27, v26, s[0:1]
	global_store_dwordx4 v[25:26], v[20:23], off
.LBB0_27:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	buffer_load_dword v20, off, s[28:31], 0 offset:56
	s_waitcnt vmcnt(0)
	v_or3_b32 v21, v20, s22, 48
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v21
	v_add_u32_e32 v20, s6, v24
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_29
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[21:22], 1, v[20:21]
	v_mov_b32_e32 v23, s5
	v_add_co_u32_e64 v21, s[0:1], s4, v21
	v_addc_co_u32_e64 v22, s[0:1], v23, v22, s[0:1]
	global_store_dwordx4 v[21:22], v[16:19], off
.LBB0_29:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	buffer_load_dword v16, off, s[28:31], 0 offset:56
	s_waitcnt vmcnt(0)
	v_or3_b32 v17, v16, s22, 64
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v17
	v_add_u32_e32 v16, s6, v20
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_31
	v_ashrrev_i32_e32 v17, 31, v16
	v_lshlrev_b64 v[17:18], 1, v[16:17]
	v_mov_b32_e32 v19, s5
	v_add_co_u32_e64 v17, s[0:1], s4, v17
	v_addc_co_u32_e64 v18, s[0:1], v19, v18, s[0:1]
	global_store_dwordx4 v[17:18], v[12:15], off
.LBB0_31:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 46 is_stmt 1
	buffer_load_dword v12, off, s[28:31], 0 offset:56
	s_waitcnt vmcnt(0)
	v_or_b32_e32 v14, s22, v12
	.loc	1 39 33 is_stmt 0
	v_or_b32_e32 v13, 0x50, v14
	.loc	1 58 33 is_stmt 1
	v_cmp_gt_i32_e64 s[0:1], s8, v13
	v_add_u32_e32 v12, s6, v16
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_33
	v_ashrrev_i32_e32 v13, 31, v12
	v_lshlrev_b64 v[15:16], 1, v[12:13]
	v_mov_b32_e32 v13, s5
	v_add_co_u32_e64 v15, s[0:1], s4, v15
	v_addc_co_u32_e64 v16, s[0:1], v13, v16, s[0:1]
	global_store_dwordx4 v[15:16], v[8:11], off
.LBB0_33:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or_b32_e32 v9, 0x60, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v9
	v_add_u32_e32 v8, s6, v12
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_35
	v_ashrrev_i32_e32 v9, 31, v8
	v_lshlrev_b64 v[9:10], 1, v[8:9]
	v_mov_b32_e32 v11, s5
	v_add_co_u32_e64 v9, s[0:1], s4, v9
	v_addc_co_u32_e64 v10, s[0:1], v11, v10, s[0:1]
	s_waitcnt lgkmcnt(1)
	global_store_dwordx4 v[9:10], v[4:7], off
.LBB0_35:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(1)
	v_or_b32_e32 v4, 0x70, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v4
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_37
	.loc	1 0 21 is_stmt 0
	v_add_u32_e32 v4, s6, v8
	.loc	1 59 21
	v_ashrrev_i32_e32 v5, 31, v4
	v_lshlrev_b64 v[4:5], 1, v[4:5]
	v_mov_b32_e32 v6, s5
	v_add_co_u32_e32 v4, vcc, s4, v4
	v_addc_co_u32_e32 v5, vcc, v6, v5, vcc
	s_waitcnt lgkmcnt(0)
	global_store_dwordx4 v[4:5], v[0:3], off
.LBB0_37:
	.loc	1 59 4
	s_endpgm
.Ltmp17:
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel gemm_kernel
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 96
		.amdhsa_kernarg_size 48
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 1
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 128
		.amdhsa_next_free_sgpr 32
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	gemm_kernel, .Lfunc_end0-gemm_kernel
	.cfi_endproc

	.section	.debug_abbrev
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.ascii	"\211|"
	.byte	14
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	0
	.byte	0
	.byte	2
	.byte	46
	.byte	0
	.byte	3
	.byte	14
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	49
	.byte	19
	.byte	0
	.byte	0
	.byte	4
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.short	4
	.long	.debug_abbrev
	.byte	8
	.byte	1
	.long	.Linfo_string0
	.short	2
	.long	.Linfo_string1
	.long	.Lline_table_start0
	.long	.Linfo_string2
	.long	.Linfo_string3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.byte	2
	.long	.Linfo_string4
	.byte	1
	.byte	3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.long	46
	.byte	4
	.long	46
	.long	.Ldebug_ranges0
	.byte	1
	.byte	31
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges1
	.byte	1
	.byte	30
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges2
	.byte	1
	.byte	47
	.byte	33
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.debug_ranges
.Ldebug_ranges0:
	.quad	.Lfunc_begin0-.Lfunc_begin0
	.quad	.Ltmp0-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp1-.Lfunc_begin0
	.quad	.Ltmp2-.Lfunc_begin0
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"triton"
.Linfo_string1:
	.asciz	"08_triton_gemm_mmac.py"
.Linfo_string2:
	.asciz	"experiments/advanced"
.Linfo_string3:
	.asciz	"[llvm:v0.0]"
.Linfo_string4:
	.asciz	"gemm_kernel"
	.section	".note.GNU-stack"
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
      - .offset:         40
        .size:           4
        .value_kind:     by_value
      - .offset:         44
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 48
    .max_flat_workgroup_size: 512
    .name:           gemm_kernel
    .private_segment_fixed_size: 96
    .sgpr_count:     36
    .sgpr_spill_count: 0
    .symbol:         gemm_kernel.kd
    .vgpr_count:     128
    .vgpr_spill_count: 27
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx936
amdhsa.version:
  - 1
  - 1
...

	.end_amdgpu_metadata
	.section	.debug_line
.Lline_table_start0:
