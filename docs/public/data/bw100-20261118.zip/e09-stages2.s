	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx936"
	.globl	gemm_kernel
	.p2align	8
	.type	gemm_kernel,@function
gemm_kernel:
.Lfunc_begin0:
	.file	1 "experiments/advanced" "08_triton_gemm_mmac.py"
	.loc	1 18 0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_escape 0x0f, 0x03, 0x30, 0x36, 0xe1
	.cfi_undefined 16
	.file	2 "/usr/local/lib/python3.11/site-packages/triton/language" "standard.py"
	.loc	2 40 22 prologue_end
	s_load_dwordx4 s[8:11], s[4:5], 0x18
	s_load_dwordx2 s[16:17], s[4:5], 0x28
.Ltmp0:
	.loc	1 33 22
	s_ashr_i32 s3, s6, 31
	s_add_i32 s7, s6, s3
	s_xor_b32 s7, s7, s3
.Ltmp1:
	.loc	2 40 22
	s_waitcnt lgkmcnt(0)
	s_add_i32 s0, s9, 0x7f
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s1, s0, 31
	s_lshr_b32 s1, s1, 25
	s_add_i32 s0, s0, s1
	s_ashr_i32 s1, s0, 7
.Ltmp2:
	.loc	1 33 22 is_stmt 1
	s_ashr_i32 s0, s0, 31
	.loc	1 32 33
	s_lshl_b32 s1, s1, 3
	.loc	1 33 22
	s_add_i32 s2, s1, s0
	s_xor_b32 s2, s2, s0
	v_cvt_f32_u32_e32 v1, s2
	s_xor_b32 s0, s3, s0
	s_sub_i32 s3, 0, s2
	.loc	1 39 46
	v_lshrrev_b32_e32 v19, 2, v0
	.loc	1 33 22
	v_rcp_iflag_f32_e32 v1, v1
	.loc	1 43 59
	v_lshlrev_b32_e32 v11, 3, v0
	v_and_b32_e32 v82, 24, v11
	.loc	1 33 22
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	v_readfirstlane_b32 s12, v1
	s_mul_i32 s3, s3, s12
	s_mul_hi_u32 s3, s12, s3
	s_add_i32 s12, s12, s3
	s_mul_hi_u32 s3, s7, s12
	s_mul_i32 s12, s3, s2
	s_sub_i32 s7, s7, s12
	s_add_i32 s13, s3, 1
	s_sub_i32 s12, s7, s2
	s_cmp_ge_u32 s7, s2
	s_cselect_b32 s3, s13, s3
	s_cselect_b32 s7, s12, s7
	s_add_i32 s12, s3, 1
	s_cmp_ge_u32 s7, s2
	s_cselect_b32 s2, s12, s3
.Ltmp3:
	.loc	2 40 22
	s_add_i32 s3, s8, 0x7f
	.loc	2 40 28 is_stmt 0
	s_ashr_i32 s7, s3, 31
.Ltmp4:
	.loc	1 33 22 is_stmt 1
	s_xor_b32 s2, s2, s0
.Ltmp5:
	.loc	2 40 28
	s_lshr_b32 s7, s7, 25
.Ltmp6:
	.loc	1 33 22
	s_sub_i32 s0, s2, s0
.Ltmp7:
	.loc	2 40 28
	s_add_i32 s3, s3, s7
.Ltmp8:
	.loc	1 34 29
	s_lshl_b32 s2, s0, 3
.Ltmp9:
	.loc	2 40 28
	s_ashr_i32 s3, s3, 7
.Ltmp10:
	.loc	1 35 35
	s_sub_i32 s3, s3, s2
	.loc	1 35 48 is_stmt 0
	s_min_i32 s3, s3, 8
	.loc	1 37 40 is_stmt 1
	s_ashr_i32 s7, s3, 31
	s_add_i32 s12, s3, s7
	s_xor_b32 s12, s12, s7
	v_cvt_f32_u32_e32 v1, s12
	.loc	1 36 34
	s_mul_i32 s0, s0, s1
	s_sub_i32 s0, s6, s0
	.loc	1 37 40
	s_ashr_i32 s1, s0, 31
	v_rcp_iflag_f32_e32 v1, v1
	s_add_i32 s6, s0, s1
	s_xor_b32 s6, s6, s1
	s_xor_b32 s1, s1, s7
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_sub_i32 s7, 0, s12
	v_readfirstlane_b32 s13, v1
	s_mul_i32 s7, s7, s13
	s_mul_hi_u32 s7, s13, s7
	s_add_i32 s13, s13, s7
	s_mul_hi_u32 s7, s6, s13
	s_mul_i32 s13, s7, s12
	s_sub_i32 s6, s6, s13
	s_add_i32 s13, s7, 1
	s_sub_i32 s14, s6, s12
	s_cmp_ge_u32 s6, s12
	s_cselect_b32 s7, s13, s7
	s_cselect_b32 s6, s14, s6
	s_add_i32 s13, s7, 1
	s_cmp_ge_u32 s6, s12
	s_cselect_b32 s6, s13, s7
	.loc	1 39 58
	s_ashr_i32 s7, s8, 31
	s_add_i32 s12, s8, s7
	s_xor_b32 s20, s12, s7
	v_cvt_f32_u32_e32 v1, s20
	.loc	1 36 54
	s_add_i32 s0, s0, s2
	.loc	1 37 40
	s_xor_b32 s2, s6, s1
	s_sub_i32 s25, s2, s1
	.loc	1 39 58
	v_rcp_iflag_f32_e32 v1, v1
	s_sub_i32 s1, 0, s20
	.loc	1 36 54
	s_mul_i32 s3, s3, s25
	.loc	1 36 27 is_stmt 0
	s_sub_i32 s0, s0, s3
	.loc	1 39 58 is_stmt 1
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	.loc	1 39 23 is_stmt 0
	s_lshl_b32 s24, s0, 7
	.loc	1 39 58
	s_bfe_i32 s26, s0, 0x10018
	.loc	1 39 33
	v_or_b32_e32 v3, s24, v19
	.loc	1 39 58
	v_mul_lo_u32 v2, s1, v1
	v_add_u32_e32 v3, s26, v3
	v_xor_b32_e32 v4, s26, v3
	v_add_u32_e32 v3, 64, v3
	v_mul_hi_u32 v2, v1, v2
.Ltmp11:
	.loc	2 40 22 is_stmt 1
	s_load_dwordx4 s[12:15], s[4:5], 0x0
	s_load_dwordx2 s[18:19], s[4:5], 0x10
.Ltmp12:
	.loc	1 39 58
	v_xor_b32_e32 v8, s26, v3
	s_mov_b32 s0, 0
	v_add_u32_e32 v1, v1, v2
	v_mul_hi_u32 v2, v4, v1
.Ltmp13:
	.loc	2 40 22
	s_add_i32 s21, s10, 31
.Ltmp14:
	.loc	1 47 22
	s_cmp_gt_i32 s21, 31
	s_cselect_b64 s[22:23], -1, 0
	.loc	1 39 58
	v_mul_lo_u32 v2, v2, s20
	s_mov_b32 s1, s0
	v_sub_u32_e32 v2, v4, v2
	v_subrev_u32_e32 v4, s20, v2
	v_cmp_le_u32_e32 vcc, s20, v2
	v_cndmask_b32_e32 v2, v2, v4, vcc
	v_subrev_u32_e32 v4, s20, v2
	v_cmp_le_u32_e32 vcc, s20, v2
	v_cndmask_b32_e32 v2, v2, v4, vcc
	v_xor_b32_e32 v2, s26, v2
	v_subrev_u32_e32 v2, s26, v2
	.loc	1 43 52
	v_mad_u64_u32 v[65:66], s[2:3], v2, s11, v[82:83]
	.loc	1 39 58
	v_mad_u64_u32 v[4:5], s[2:3], v8, v1, 0
	.loc	1 48 20
	v_ashrrev_i32_e32 v66, 31, v65
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	.loc	1 48 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s10, v82
	v_lshlrev_b64 v[6:7], 1, v[65:66]
	.loc	1 48 20
	v_mov_b64_e32 v[3:4], s[2:3]
	.loc	1 47 22 is_stmt 1
	s_and_b64 s[4:5], vcc, s[22:23]
	.loc	1 48 20
	v_mov_b64_e32 v[1:2], s[0:1]
	s_and_saveexec_b64 s[6:7], s[4:5]
	s_cbranch_execz .LBB0_2
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v2, s13
	v_add_co_u32_e32 v1, vcc, s12, v6
	v_addc_co_u32_e32 v2, vcc, v2, v7, vcc
	global_load_dwordx4 v[1:4], v[1:2], off
.LBB0_2:
	.loc	1 0 20 is_stmt 0
	s_or_b64 exec, exec, s[6:7]
	.loc	1 39 58 is_stmt 1
	v_mul_lo_u32 v5, v5, s20
	v_sub_u32_e32 v5, v8, v5
	v_subrev_u32_e32 v6, s20, v5
	v_cmp_le_u32_e32 vcc, s20, v5
	v_cndmask_b32_e32 v5, v5, v6, vcc
	v_subrev_u32_e32 v6, s20, v5
	v_cmp_le_u32_e32 vcc, s20, v5
	v_cndmask_b32_e32 v5, v5, v6, vcc
	v_xor_b32_e32 v5, s26, v5
	v_subrev_u32_e32 v5, s26, v5
	.loc	1 43 52
	v_mad_u64_u32 v[67:68], s[6:7], v5, s11, v[82:83]
	.loc	1 48 20
	v_mov_b64_e32 v[7:8], s[2:3]
	v_mov_b64_e32 v[5:6], s[0:1]
	v_ashrrev_i32_e32 v68, 31, v67
	v_lshlrev_b64 v[9:10], 1, v[67:68]
	s_and_saveexec_b64 s[0:1], s[4:5]
	s_cbranch_execz .LBB0_4
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v6, s13
	v_add_co_u32_e32 v5, vcc, s12, v9
	v_addc_co_u32_e32 v6, vcc, v6, v10, vcc
	global_load_dwordx4 v[5:8], v[5:6], off
.LBB0_4:
	.loc	1 0 20 is_stmt 0
	s_or_b64 exec, exec, s[0:1]
	.loc	1 40 58 is_stmt 1
	s_ashr_i32 s0, s9, 31
	s_add_i32 s1, s9, s0
	s_xor_b32 s2, s1, s0
	v_cvt_f32_u32_e32 v9, s2
	s_sub_i32 s0, 0, s2
	.loc	1 40 23 is_stmt 0
	s_lshl_b32 s20, s25, 7
	.loc	1 39 46 is_stmt 1
	v_and_b32_e32 v81, 0x78, v11
	.loc	1 40 58
	v_rcp_iflag_f32_e32 v9, v9
	s_bfe_i32 s3, s25, 0x10018
	.loc	1 40 33 is_stmt 0
	v_or_b32_e32 v89, s20, v81
	.loc	1 40 58
	v_add_u32_e32 v11, s3, v89
	v_mul_f32_e32 v9, 0x4f7ffffe, v9
	v_cvt_u32_f32_e32 v9, v9
	v_xor_b32_e32 v11, s3, v11
	.loc	1 44 28 is_stmt 1
	v_lshrrev_b32_e32 v87, 4, v0
	s_mov_b32 s4, 0
	.loc	1 40 58
	v_mul_lo_u32 v10, s0, v9
	s_mov_b32 s6, s4
	s_mov_b32 s7, s4
	.loc	1 49 51
	v_cmp_gt_i32_e32 vcc, s10, v87
	.loc	1 40 58
	v_mul_hi_u32 v10, v9, v10
	s_mov_b32 s5, s4
	v_add_u32_e32 v9, v9, v10
	v_mul_hi_u32 v9, v11, v9
	v_mul_lo_u32 v9, v9, s2
	v_sub_u32_e32 v9, v11, v9
	v_subrev_u32_e32 v10, s2, v9
	v_cmp_le_u32_e64 s[0:1], s2, v9
	v_cndmask_b32_e64 v9, v9, v10, s[0:1]
	v_subrev_u32_e32 v10, s2, v9
	v_cmp_le_u32_e64 s[0:1], s2, v9
	v_cndmask_b32_e64 v9, v9, v10, s[0:1]
	v_xor_b32_e32 v9, s3, v9
	v_subrev_u32_e32 v9, s3, v9
	.loc	1 44 51
	v_mad_u64_u32 v[69:70], s[0:1], v87, s16, v[9:10]
	.loc	1 49 20
	v_mov_b64_e32 v[11:12], s[6:7]
	.loc	1 47 22
	s_and_b64 s[2:3], vcc, s[22:23]
	.loc	1 49 20
	v_ashrrev_i32_e32 v70, 31, v69
	v_lshlrev_b64 v[13:14], 1, v[69:70]
	v_mov_b64_e32 v[9:10], s[4:5]
	s_and_saveexec_b64 s[0:1], s[2:3]
	s_cbranch_execz .LBB0_6
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v10, s15
	v_add_co_u32_e32 v9, vcc, s14, v13
	v_addc_co_u32_e32 v10, vcc, v10, v14, vcc
	global_load_dwordx4 v[9:12], v[9:10], off
.LBB0_6:
	.loc	1 0 20 is_stmt 0
	s_or_b64 exec, exec, s[0:1]
	v_lshl_add_u32 v71, s16, 4, v69
	.loc	1 44 28 is_stmt 1
	v_or_b32_e32 v88, 16, v87
	.loc	1 49 20
	v_ashrrev_i32_e32 v72, 31, v71
	.loc	1 49 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s10, v88
	v_lshlrev_b64 v[17:18], 1, v[71:72]
	.loc	1 49 20
	v_mov_b64_e32 v[15:16], s[6:7]
	.loc	1 47 22 is_stmt 1
	s_and_b64 s[2:3], vcc, s[22:23]
	.loc	1 49 20
	v_mov_b64_e32 v[13:14], s[4:5]
	s_and_saveexec_b64 s[0:1], s[2:3]
	s_cbranch_execz .LBB0_8
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v14, s15
	v_add_co_u32_e32 v13, vcc, s14, v17
	v_addc_co_u32_e32 v14, vcc, v14, v18, vcc
	global_load_dwordx4 v[13:16], v[13:14], off
.LBB0_8:
	.loc	1 0 20 is_stmt 0
	s_or_b64 exec, exec, s[0:1]
	.loc	1 39 46 is_stmt 1
	v_and_b32_e32 v73, 63, v0
	v_lshrrev_b32_e32 v90, 6, v0
	.loc	1 48 20
	v_lshrrev_b32_e32 v17, 1, v0
	v_and_or_b32 v18, v17, 4, v82
	v_and_b32_e32 v20, 24, v17
	v_xor_b32_e32 v18, v18, v20
	v_lshlrev_b32_e32 v19, 5, v19
	v_or_b32_e32 v18, v18, v19
	v_lshl_add_u32 v95, v18, 1, 0
	s_waitcnt vmcnt(0)
	ds_write_b64 v95, v[1:2]
	v_or_b32_e32 v1, 4, v82
	v_and_b32_e32 v2, 28, v17
	v_xor_b32_e32 v1, v1, v2
	v_or_b32_e32 v1, v1, v19
	v_lshl_add_u32 v96, v1, 1, 0
	.loc	1 49 20
	v_lshlrev_b32_e32 v1, 1, v81
	v_lshl_or_b32 v1, v87, 8, v1
	.loc	1 48 20
	s_mov_b32 s2, 0
	.loc	1 49 20
	v_add_u32_e32 v74, 0, v1
	.loc	1 47 22
	s_cmp_gt_i32 s21, 63
	v_lshrrev_b32_e32 v1, 3, v0
	v_and_b32_e32 v91, 15, v0
	v_lshrrev_b32_e32 v92, 4, v73
	v_lshlrev_b32_e32 v2, 4, v90
	.loc	1 48 20
	ds_write_b64 v95, v[5:6] offset:4096
	ds_write2st64_b64 v96, v[3:4], v[7:8] offset1:8
	.loc	1 49 20
	ds_write_b128 v74, v[9:12] offset:8192
	ds_write_b128 v74, v[13:16] offset:12288
	.loc	1 47 22
	s_cbranch_scc1 .LBB0_10
	.loc	1 48 20
	v_and_or_b32 v93, v1, 16, v91
	.loc	1 49 20
	v_and_b32_e32 v94, 16, v2
	s_mov_b64 s[0:1], 0
	s_branch .LBB0_11
.LBB0_10:
	.loc	1 0 20 is_stmt 0
	s_mov_b64 s[0:1], -1
.LBB0_11:
	.loc	1 47 22 is_stmt 1
	s_andn2_b64 vcc, exec, s[0:1]
	v_mov_b32_e32 v4, s2
	v_mov_b32_e32 v3, s2
	v_mov_b32_e32 v2, s2
	v_mov_b32_e32 v1, s2
	v_mov_b32_e32 v8, s2
	v_mov_b32_e32 v7, s2
	v_mov_b32_e32 v6, s2
	v_mov_b32_e32 v5, s2
	v_mov_b32_e32 v12, s2
	v_mov_b32_e32 v11, s2
	v_mov_b32_e32 v10, s2
	v_mov_b32_e32 v9, s2
	v_mov_b32_e32 v16, s2
	v_mov_b32_e32 v15, s2
	v_mov_b32_e32 v14, s2
	v_mov_b32_e32 v13, s2
	v_mov_b32_e32 v20, s2
	v_mov_b32_e32 v19, s2
	v_mov_b32_e32 v18, s2
	v_mov_b32_e32 v17, s2
	v_mov_b32_e32 v24, s2
	v_mov_b32_e32 v23, s2
	v_mov_b32_e32 v22, s2
	v_mov_b32_e32 v21, s2
	v_mov_b32_e32 v28, s2
	v_mov_b32_e32 v27, s2
	v_mov_b32_e32 v26, s2
	v_mov_b32_e32 v25, s2
	v_mov_b32_e32 v32, s2
	v_mov_b32_e32 v31, s2
	v_mov_b32_e32 v30, s2
	v_mov_b32_e32 v29, s2
	v_mov_b32_e32 v36, s2
	v_mov_b32_e32 v35, s2
	v_mov_b32_e32 v34, s2
	v_mov_b32_e32 v33, s2
	v_mov_b32_e32 v40, s2
	v_mov_b32_e32 v39, s2
	v_mov_b32_e32 v38, s2
	v_mov_b32_e32 v37, s2
	v_mov_b32_e32 v44, s2
	v_mov_b32_e32 v43, s2
	v_mov_b32_e32 v42, s2
	v_mov_b32_e32 v41, s2
	v_mov_b32_e32 v48, s2
	v_mov_b32_e32 v47, s2
	v_mov_b32_e32 v46, s2
	v_mov_b32_e32 v45, s2
	v_mov_b32_e32 v52, s2
	v_mov_b32_e32 v51, s2
	v_mov_b32_e32 v50, s2
	v_mov_b32_e32 v49, s2
	v_mov_b32_e32 v56, s2
	v_mov_b32_e32 v55, s2
	v_mov_b32_e32 v54, s2
	v_mov_b32_e32 v53, s2
	v_mov_b32_e32 v64, s2
	v_mov_b32_e32 v63, s2
	v_mov_b32_e32 v62, s2
	v_mov_b32_e32 v61, s2
	v_mov_b32_e32 v60, s2
	v_mov_b32_e32 v59, s2
	v_mov_b32_e32 v58, s2
	v_mov_b32_e32 v57, s2
	v_bfe_u32 v75, v0, 1, 3
	s_cbranch_vccnz .LBB0_22
	.loc	1 0 22 is_stmt 0
	v_lshrrev_b32_e32 v1, 3, v0
	v_and_b32_e32 v91, 15, v0
	v_lshrrev_b32_e32 v92, 4, v73
	v_and_or_b32 v93, v1, 16, v91
	v_xor_b32_e32 v1, v92, v75
	v_or_b32_e32 v2, 4, v92
	v_lshlrev_b32_e32 v3, 6, v93
	v_xor_b32_e32 v2, v2, v75
	v_lshl_or_b32 v1, v1, 3, v3
	v_add_u32_e32 v98, 0, v1
	v_lshl_or_b32 v1, v2, 3, v3
	v_add_u32_e32 v99, 0, v1
	v_lshlrev_b32_e32 v1, 4, v90
	v_and_b32_e32 v94, 16, v1
	v_lshlrev_b32_e32 v1, 9, v92
	v_or3_b32 v1, v1, v91, v94
	s_add_i32 s4, 0, 0x2000
	v_lshl_add_u32 v100, v1, 1, s4
	.loc	1 47 22
	v_lshlrev_b64 v[1:2], 1, v[71:72]
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v3, s15
	v_add_co_u32_e32 v108, vcc, s14, v1
	v_addc_co_u32_e32 v109, vcc, v3, v2, vcc
	v_lshlrev_b64 v[1:2], 1, v[69:70]
	.loc	1 52 28 is_stmt 1
	s_lshl_b32 s2, s16, 5
	.loc	1 47 22
	v_add_co_u32_e32 v110, vcc, s14, v1
	v_addc_co_u32_e32 v111, vcc, v3, v2, vcc
	v_lshlrev_b64 v[1:2], 1, v[67:68]
	v_mov_b32_e32 v3, s13
	v_add_co_u32_e32 v1, vcc, s12, v1
	v_addc_co_u32_e32 v2, vcc, v2, v3, vcc
	v_add_co_u32_e32 v83, vcc, 64, v1
	v_addc_co_u32_e32 v84, vcc, 0, v2, vcc
	v_lshlrev_b64 v[1:2], 1, v[65:66]
	s_ashr_i32 s3, s2, 31
	v_add_co_u32_e32 v1, vcc, s12, v1
	v_addc_co_u32_e32 v2, vcc, v2, v3, vcc
.Ltmp15:
	.loc	2 40 28
	s_lshr_b32 s1, s21, 5
.Ltmp16:
	.loc	1 47 22
	s_lshl_b64 s[4:5], s[2:3], 1
	v_add_co_u32_e32 v85, vcc, 64, v1
	v_mov_b32_e32 v57, 0
	v_add_u32_e32 v97, 0x2000, v74
	s_mov_b32 s0, 0
	v_add_u32_e32 v101, 0x1000, v100
	v_add_u32_e32 v102, 64, v100
	v_add_u32_e32 v103, 0x1040, v100
	v_add_u32_e32 v104, 0x80, v100
	v_add_u32_e32 v105, 0x1080, v100
	v_add_u32_e32 v106, 0xc0, v100
	v_add_u32_e32 v107, 0x10c0, v100
	v_addc_co_u32_e32 v86, vcc, 0, v2, vcc
	s_add_i32 s12, s1, -1
	s_sub_i32 s13, s10, 32
	s_mov_b32 s14, 0x5040100
	s_mov_b64 s[6:7], s[4:5]
	v_mov_b32_e32 v58, v57
	v_mov_b32_e32 v59, v57
	v_mov_b32_e32 v60, v57
	v_mov_b32_e32 v61, v57
	v_mov_b32_e32 v62, v57
	v_mov_b32_e32 v63, v57
	v_mov_b32_e32 v64, v57
	v_mov_b32_e32 v53, v57
	v_mov_b32_e32 v54, v57
	v_mov_b32_e32 v55, v57
	v_mov_b32_e32 v56, v57
	v_mov_b32_e32 v49, v57
	v_mov_b32_e32 v50, v57
	v_mov_b32_e32 v51, v57
	v_mov_b32_e32 v52, v57
	v_mov_b32_e32 v45, v57
	v_mov_b32_e32 v46, v57
	v_mov_b32_e32 v47, v57
	v_mov_b32_e32 v48, v57
	v_mov_b32_e32 v41, v57
	v_mov_b32_e32 v42, v57
	v_mov_b32_e32 v43, v57
	v_mov_b32_e32 v44, v57
	v_mov_b32_e32 v37, v57
	v_mov_b32_e32 v38, v57
	v_mov_b32_e32 v39, v57
	v_mov_b32_e32 v40, v57
	v_mov_b32_e32 v33, v57
	v_mov_b32_e32 v34, v57
	v_mov_b32_e32 v35, v57
	v_mov_b32_e32 v36, v57
	v_mov_b32_e32 v29, v57
	v_mov_b32_e32 v30, v57
	v_mov_b32_e32 v31, v57
	v_mov_b32_e32 v32, v57
	v_mov_b32_e32 v25, v57
	v_mov_b32_e32 v26, v57
	v_mov_b32_e32 v27, v57
	v_mov_b32_e32 v28, v57
	v_mov_b32_e32 v21, v57
	v_mov_b32_e32 v22, v57
	v_mov_b32_e32 v23, v57
	v_mov_b32_e32 v24, v57
	v_mov_b32_e32 v17, v57
	v_mov_b32_e32 v18, v57
	v_mov_b32_e32 v19, v57
	v_mov_b32_e32 v20, v57
	v_mov_b32_e32 v13, v57
	v_mov_b32_e32 v14, v57
	v_mov_b32_e32 v15, v57
	v_mov_b32_e32 v16, v57
	v_mov_b32_e32 v9, v57
	v_mov_b32_e32 v10, v57
	v_mov_b32_e32 v11, v57
	v_mov_b32_e32 v12, v57
	v_mov_b32_e32 v5, v57
	v_mov_b32_e32 v6, v57
	v_mov_b32_e32 v7, v57
	v_mov_b32_e32 v8, v57
	v_mov_b32_e32 v1, v57
	v_mov_b32_e32 v2, v57
	v_mov_b32_e32 v3, v57
	v_mov_b32_e32 v4, v57
	s_branch .LBB0_14
.LBB0_13:
	.loc	1 0 22 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 48 20 is_stmt 1
	s_waitcnt vmcnt(0) lgkmcnt(0)
	s_barrier
	s_barrier
	ds_read2st64_b64 v[112:115], v98 offset1:4
	ds_read2st64_b64 v[116:119], v99 offset1:4
	ds_read2st64_b64 v[120:123], v98 offset0:8 offset1:12
	ds_read2st64_b64 v[124:127], v99 offset0:8 offset1:12
	.loc	1 49 20
	ds_read_u16 v128, v100 offset:512
	ds_read_u16 v129, v100 offset:768
	ds_read_u16 v130, v100 offset:4096
	ds_read_u16 v131, v101 offset:512
	ds_read_u16 v132, v101 offset:768
	ds_read_u16 v134, v102 offset:256
	ds_read_u16 v133, v102 offset:512
	ds_read_u16 v135, v100
	ds_read_u16 v136, v100 offset:64
	ds_read_u16 v138, v100 offset:128
	ds_read_u16 v137, v100 offset:4160
	ds_read_u16 v140, v100 offset:4224
	ds_read_u16 v139, v102 offset:768
	ds_read_u16 v141, v103 offset:256
	ds_read_u16 v142, v103 offset:512
	ds_read_u16 v143, v103 offset:768
	ds_read_u16 v144, v104 offset:256
	ds_read_u16 v145, v104 offset:512
	ds_read_u16 v146, v104 offset:768
	ds_read_u16 v147, v105 offset:256
	ds_read_u16 v148, v100 offset:256
	ds_read_u16 v149, v100 offset:192
	ds_read_u16 v150, v101 offset:256
	ds_read_u16 v151, v100 offset:4288
	ds_read_u16 v152, v105 offset:512
	ds_read_u16 v153, v105 offset:768
	ds_read_u16 v154, v106 offset:256
	ds_read_u16 v155, v106 offset:512
	ds_read_u16 v156, v106 offset:768
	ds_read_u16 v157, v107 offset:256
	ds_read_u16 v158, v107 offset:512
	ds_read_u16 v159, v107 offset:768
	.loc	1 50 27
	s_waitcnt lgkmcnt(14)
	v_perm_b32 v129, v129, v128, s14
	s_waitcnt lgkmcnt(11)
	v_perm_b32 v128, v148, v135, s14
	v_perm_b32 v131, v132, v131, s14
	s_waitcnt lgkmcnt(9)
	v_perm_b32 v130, v150, v130, s14
	v_perm_b32 v133, v139, v133, s14
	v_perm_b32 v132, v134, v136, s14
	v_perm_b32 v135, v143, v142, s14
	v_perm_b32 v134, v141, v137, s14
	v_perm_b32 v137, v146, v145, s14
	v_perm_b32 v136, v144, v138, s14
	s_waitcnt lgkmcnt(6)
	v_perm_b32 v139, v153, v152, s14
	v_perm_b32 v138, v147, v140, s14
	s_waitcnt lgkmcnt(3)
	v_perm_b32 v141, v156, v155, s14
	v_perm_b32 v140, v154, v149, s14
	s_waitcnt lgkmcnt(0)
	v_perm_b32 v143, v159, v158, s14
	v_perm_b32 v142, v157, v151, s14
	s_setprio 1
	v_mmac_f32_16x16x16_f16 v[57:60], v[112:113], v[128:129], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[112:113], v[132:133], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[112:113], v[136:137], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[112:113], v[140:141], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[114:115], v[128:129], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[114:115], v[132:133], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[114:115], v[136:137], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[114:115], v[140:141], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[120:121], v[128:129], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[120:121], v[132:133], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[120:121], v[136:137], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[120:121], v[140:141], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[122:123], v[128:129], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[122:123], v[132:133], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[122:123], v[136:137], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[122:123], v[140:141], v[1:4]
	v_mmac_f32_16x16x16_f16 v[57:60], v[116:117], v[130:131], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[116:117], v[134:135], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[116:117], v[138:139], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[116:117], v[142:143], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[118:119], v[130:131], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[118:119], v[134:135], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[118:119], v[138:139], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[118:119], v[142:143], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[124:125], v[130:131], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[124:125], v[134:135], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[124:125], v[138:139], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[124:125], v[142:143], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[126:127], v[130:131], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[126:127], v[134:135], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[126:127], v[138:139], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[126:127], v[142:143], v[1:4]
	s_setprio 0
	.loc	1 48 20
	s_barrier
	s_barrier
	ds_write_b64 v95, v[65:66]
	ds_write_b64 v95, v[69:70] offset:4096
	ds_write2st64_b64 v96, v[67:68], v[71:72] offset1:8
	.loc	1 49 20
	ds_write_b128 v97, v[73:76]
	ds_write_b128 v97, v[77:80] offset:4096
	.loc	1 47 22
	v_add_co_u32_e32 v83, vcc, 64, v83
	s_add_u32 s6, s6, s4
	v_addc_co_u32_e32 v84, vcc, 0, v84, vcc
	s_addc_u32 s7, s7, s5
	s_add_i32 s12, s12, -1
	s_sub_i32 s13, s13, 32
	v_add_co_u32_e32 v85, vcc, 64, v85
	s_cmp_lg_u32 s12, 0
	v_addc_co_u32_e32 v86, vcc, 0, v86, vcc
	s_cbranch_scc0 .LBB0_22
.LBB0_14:
	.loc	1 0 22 is_stmt 0
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	s_mov_b32 s1, s0
	.loc	1 48 20 is_stmt 1
	v_mov_b64_e32 v[67:68], s[2:3]
	.loc	1 48 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s13, v82
	.loc	1 48 20
	v_mov_b64_e32 v[65:66], s[0:1]
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB0_16
	global_load_dwordx4 v[65:68], v[85:86], off
.LBB0_16:
	.loc	1 0 20
	s_or_b64 exec, exec, s[10:11]
	.loc	1 48 20
	v_mov_b64_e32 v[71:72], s[2:3]
	v_mov_b64_e32 v[69:70], s[0:1]
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_18
	global_load_dwordx4 v[69:72], v[83:84], off
.LBB0_18:
	.loc	1 0 20
	s_or_b64 exec, exec, s[2:3]
	s_mov_b32 s2, s0
	s_mov_b32 s3, s0
	s_mov_b32 s1, s0
	.loc	1 49 20 is_stmt 1
	v_mov_b64_e32 v[75:76], s[2:3]
	.loc	1 49 51 is_stmt 0
	v_cmp_gt_i32_e32 vcc, s13, v87
	.loc	1 49 20
	v_mov_b64_e32 v[73:74], s[0:1]
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB0_20
	v_mov_b32_e32 v74, s7
	v_add_co_u32_e32 v73, vcc, s6, v110
	v_addc_co_u32_e32 v74, vcc, v111, v74, vcc
	global_load_dwordx4 v[73:76], v[73:74], off
.LBB0_20:
	.loc	1 0 20
	s_or_b64 exec, exec, s[10:11]
	.loc	1 49 20
	v_mov_b64_e32 v[79:80], s[2:3]
	.loc	1 49 51
	v_cmp_gt_i32_e32 vcc, s13, v88
	.loc	1 49 20
	v_mov_b64_e32 v[77:78], s[0:1]
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB0_13
	v_mov_b32_e32 v78, s7
	v_add_co_u32_e32 v77, vcc, s6, v108
	v_addc_co_u32_e32 v78, vcc, v109, v78, vcc
	global_load_dwordx4 v[77:80], v[77:78], off
	s_branch .LBB0_13
.LBB0_22:
	.loc	1 50 27 is_stmt 1
	s_andn2_b64 vcc, exec, s[22:23]
	.loc	1 48 20
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_barrier
	.loc	1 50 27
	s_cbranch_vccnz .LBB0_24
	.loc	1 49 20
	v_lshl_or_b32 v65, v92, 9, v91
	s_add_i32 s0, 0, 0x2000
	v_add_u32_e32 v66, v65, v94
	v_or_b32_e32 v65, v65, v94
	v_lshl_add_u32 v65, v65, 1, s0
	v_lshl_add_u32 v66, v66, 1, s0
	ds_read_u16 v82, v65
	ds_read_u16 v86, v66 offset:5056
	ds_read_u16 v101, v66 offset:4992
	ds_read_u16 v97, v66 offset:4928
	ds_read_u16 v84, v66 offset:4864
	ds_read_u16 v105, v66 offset:4800
	ds_read_u16 v102, v66 offset:4736
	ds_read_u16 v98, v66 offset:4672
	ds_read_u16 v85, v66 offset:4608
	ds_read_u16 v107, v66 offset:4544
	ds_read_u16 v103, v66 offset:4480
	ds_read_u16 v99, v66 offset:4416
	ds_read_u16 v95, v66 offset:4352
	ds_read_u16 v108, v66 offset:4288
	ds_read_u16 v104, v66 offset:4224
	ds_read_u16 v100, v66 offset:4160
	ds_read_u16 v96, v66 offset:4096
	ds_read_u16 v106, v66 offset:960
	ds_read_u16 v109, v66 offset:896
	ds_read_u16 v110, v66 offset:832
	ds_read_u16 v83, v66 offset:768
	ds_read_u16 v111, v66 offset:704
	ds_read_u16 v112, v66 offset:640
	ds_read_u16 v113, v66 offset:576
	ds_read_u16 v114, v66 offset:512
	ds_read_u16 v115, v66 offset:448
	ds_read_u16 v116, v66 offset:384
	ds_read_u16 v117, v66 offset:320
	ds_read_u16 v118, v66 offset:256
	ds_read_u16 v119, v66 offset:192
	ds_read_u16 v120, v66 offset:128
	ds_read_u16 v121, v66 offset:64
	.loc	1 48 20
	v_bfe_u32 v0, v0, 1, 3
	v_or_b32_e32 v65, 4, v92
	v_lshlrev_b32_e32 v69, 5, v93
	v_xor_b32_e32 v65, v65, v0
	v_xor_b32_e32 v0, v92, v0
	v_lshl_add_u32 v65, v65, 2, v69
	v_lshl_add_u32 v0, v0, 2, v69
	v_lshl_add_u32 v73, v65, 1, 0
	v_lshl_add_u32 v0, v0, 1, 0
	ds_read2st64_b64 v[65:68], v73 offset0:8 offset1:12
	ds_read2st64_b64 v[69:72], v0 offset0:8 offset1:12
	ds_read2st64_b64 v[73:76], v73 offset1:4
	ds_read2st64_b64 v[77:80], v0 offset1:4
	.loc	1 50 27
	s_mov_b32 s0, 0x5040100
	s_waitcnt lgkmcnt(7)
	v_perm_b32 v82, v118, v82, s0
	v_perm_b32 v83, v83, v114, s0
	v_perm_b32 v85, v84, v85, s0
	v_perm_b32 v84, v95, v96, s0
	v_perm_b32 v96, v110, v113, s0
	s_waitcnt lgkmcnt(4)
	v_perm_b32 v95, v117, v121, s0
	v_perm_b32 v98, v97, v98, s0
	v_perm_b32 v97, v99, v100, s0
	v_perm_b32 v100, v109, v112, s0
	v_perm_b32 v99, v116, v120, s0
	v_perm_b32 v102, v101, v102, s0
	v_perm_b32 v101, v103, v104, s0
	v_perm_b32 v104, v106, v111, s0
	v_perm_b32 v103, v115, v119, s0
	v_perm_b32 v106, v86, v105, s0
	v_perm_b32 v105, v107, v108, s0
	s_setprio 1
	s_waitcnt lgkmcnt(0)
	v_mmac_f32_16x16x16_f16 v[57:60], v[77:78], v[82:83], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[77:78], v[95:96], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[77:78], v[99:100], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[77:78], v[103:104], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[79:80], v[82:83], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[79:80], v[95:96], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[79:80], v[99:100], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[79:80], v[103:104], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[69:70], v[82:83], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[69:70], v[95:96], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[69:70], v[99:100], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[69:70], v[103:104], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[71:72], v[82:83], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[71:72], v[95:96], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[71:72], v[99:100], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[71:72], v[103:104], v[1:4]
	v_mmac_f32_16x16x16_f16 v[57:60], v[73:74], v[84:85], v[57:60]
	v_mmac_f32_16x16x16_f16 v[61:64], v[73:74], v[97:98], v[61:64]
	v_mmac_f32_16x16x16_f16 v[53:56], v[73:74], v[101:102], v[53:56]
	v_mmac_f32_16x16x16_f16 v[49:52], v[73:74], v[105:106], v[49:52]
	v_mmac_f32_16x16x16_f16 v[45:48], v[75:76], v[84:85], v[45:48]
	v_mmac_f32_16x16x16_f16 v[41:44], v[75:76], v[97:98], v[41:44]
	v_mmac_f32_16x16x16_f16 v[37:40], v[75:76], v[101:102], v[37:40]
	v_mmac_f32_16x16x16_f16 v[33:36], v[75:76], v[105:106], v[33:36]
	v_mmac_f32_16x16x16_f16 v[29:32], v[65:66], v[84:85], v[29:32]
	v_mmac_f32_16x16x16_f16 v[25:28], v[65:66], v[97:98], v[25:28]
	v_mmac_f32_16x16x16_f16 v[21:24], v[65:66], v[101:102], v[21:24]
	v_mmac_f32_16x16x16_f16 v[17:20], v[65:66], v[105:106], v[17:20]
	v_mmac_f32_16x16x16_f16 v[13:16], v[67:68], v[84:85], v[13:16]
	v_mmac_f32_16x16x16_f16 v[9:12], v[67:68], v[97:98], v[9:12]
	v_mmac_f32_16x16x16_f16 v[5:8], v[67:68], v[101:102], v[5:8]
	v_mmac_f32_16x16x16_f16 v[1:4], v[67:68], v[105:106], v[1:4]
	s_setprio 0
.LBB0_24:
	.loc	1 57 21
	s_mul_i32 s0, s24, s17
	s_ashr_i32 s1, s0, 31
	s_lshl_b64 s[0:1], s[0:1], 1
	.loc	1 54 15
	v_cvt_f16_f32_e32 v82, v20
	.loc	1 57 21
	s_add_u32 s2, s18, s0
	s_addc_u32 s3, s19, s1
	.loc	1 57 52 is_stmt 0
	s_ashr_i32 s21, s20, 31
	s_lshl_b64 s[0:1], s[20:21], 1
	s_add_u32 s4, s2, s0
	.loc	1 39 33 is_stmt 1
	v_or_b32_e32 v0, s24, v87
	.loc	1 54 15
	v_cvt_f16_f32_e32 v57, v57
	v_cvt_f16_f32_e32 v65, v33
	v_cvt_f16_f32_e32 v69, v32
	v_cvt_f16_f32_e32 v5, v5
	v_cvt_f16_f32_e32 v6, v6
	v_cvt_f16_f32_e32 v7, v7
	v_cvt_f16_f32_e32 v1, v1
	v_cvt_f16_f32_e32 v2, v2
	v_cvt_f16_f32_e32 v3, v3
	v_cvt_f16_f32_e32 v4, v4
	.loc	1 57 52
	s_addc_u32 s5, s3, s1
	v_mad_u64_u32 v[32:33], s[0:1], v87, s17, v[81:82]
	.loc	1 54 15
	v_cvt_f16_f32_e32 v58, v58
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v0
	.loc	1 59 21
	v_or_b32_e32 v0, v92, v94
	s_movk_i32 s2, 0x88
	.loc	1 54 15
	v_cvt_f16_f32_e32 v59, v59
	.loc	1 59 21
	v_mad_i32_i24 v0, v93, s2, v0
	.loc	1 54 15
	v_cvt_f16_f32_e32 v60, v60
	.loc	1 58 58
	v_cmp_gt_i32_e32 vcc, s9, v89
	.loc	1 59 21
	v_lshl_add_u32 v0, v0, 1, 0
	.loc	1 54 15
	v_cvt_f16_f32_e32 v61, v61
	v_cvt_f16_f32_e32 v62, v62
	v_cvt_f16_f32_e32 v63, v63
	v_cvt_f16_f32_e32 v64, v64
	v_cvt_f16_f32_e32 v53, v53
	v_cvt_f16_f32_e32 v54, v54
	v_cvt_f16_f32_e32 v55, v55
	v_cvt_f16_f32_e32 v56, v56
	v_cvt_f16_f32_e32 v49, v49
	v_cvt_f16_f32_e32 v50, v50
	v_cvt_f16_f32_e32 v51, v51
	v_cvt_f16_f32_e32 v52, v52
	v_cvt_f16_f32_e32 v45, v45
	v_cvt_f16_f32_e32 v46, v46
	v_cvt_f16_f32_e32 v47, v47
	v_cvt_f16_f32_e32 v48, v48
	v_cvt_f16_f32_e32 v41, v41
	v_cvt_f16_f32_e32 v42, v42
	v_cvt_f16_f32_e32 v43, v43
	v_cvt_f16_f32_e32 v44, v44
	v_cvt_f16_f32_e32 v37, v37
	v_cvt_f16_f32_e32 v38, v38
	v_cvt_f16_f32_e32 v39, v39
	v_cvt_f16_f32_e32 v40, v40
	v_cvt_f16_f32_e32 v34, v34
	v_cvt_f16_f32_e32 v35, v35
	v_cvt_f16_f32_e32 v36, v36
	v_cvt_f16_f32_e32 v66, v29
	v_cvt_f16_f32_e32 v67, v30
	v_cvt_f16_f32_e32 v68, v31
	v_cvt_f16_f32_e32 v70, v25
	v_cvt_f16_f32_e32 v71, v26
	v_cvt_f16_f32_e32 v72, v27
	v_cvt_f16_f32_e32 v73, v28
	v_cvt_f16_f32_e32 v74, v21
	v_cvt_f16_f32_e32 v75, v22
	v_cvt_f16_f32_e32 v76, v23
	v_cvt_f16_f32_e32 v77, v24
	v_cvt_f16_f32_e32 v78, v17
	v_cvt_f16_f32_e32 v79, v18
	v_cvt_f16_f32_e32 v80, v19
	v_cvt_f16_f32_e32 v83, v13
	v_cvt_f16_f32_e32 v84, v14
	v_cvt_f16_f32_e32 v85, v15
	v_cvt_f16_f32_e32 v86, v16
	v_cvt_f16_f32_e32 v95, v9
	v_cvt_f16_f32_e32 v96, v10
	v_cvt_f16_f32_e32 v97, v11
	v_cvt_f16_f32_e32 v98, v12
	v_cvt_f16_f32_e32 v99, v8
	.loc	1 58 39
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_waitcnt lgkmcnt(0)
	ds_write_b16 v0, v57
	ds_write_b16 v0, v58 offset:8
	ds_write_b16 v0, v59 offset:16
	ds_write_b16 v0, v60 offset:24
	ds_write_b16 v0, v61 offset:64
	ds_write_b16 v0, v62 offset:72
	ds_write_b16 v0, v63 offset:80
	ds_write_b16 v0, v64 offset:88
	ds_write_b16 v0, v53 offset:128
	ds_write_b16 v0, v54 offset:136
	ds_write_b16 v0, v55 offset:144
	ds_write_b16 v0, v56 offset:152
	ds_write_b16 v0, v49 offset:192
	ds_write_b16 v0, v50 offset:200
	ds_write_b16 v0, v51 offset:208
	ds_write_b16 v0, v52 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	v_lshl_add_u32 v8, v90, 2, v92
	v_lshlrev_b32_e32 v9, 3, v91
	v_mad_i32_i24 v8, v8, s2, v9
	v_lshl_add_u32 v33, v8, 1, 0
	ds_read_b128 v[28:31], v33
	ds_read_b128 v[24:27], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v45
	ds_write_b16 v0, v46 offset:8
	ds_write_b16 v0, v47 offset:16
	ds_write_b16 v0, v48 offset:24
	ds_write_b16 v0, v41 offset:64
	ds_write_b16 v0, v42 offset:72
	ds_write_b16 v0, v43 offset:80
	ds_write_b16 v0, v44 offset:88
	ds_write_b16 v0, v37 offset:128
	ds_write_b16 v0, v38 offset:136
	ds_write_b16 v0, v39 offset:144
	ds_write_b16 v0, v40 offset:152
	ds_write_b16 v0, v65 offset:192
	ds_write_b16 v0, v34 offset:200
	ds_write_b16 v0, v35 offset:208
	ds_write_b16 v0, v36 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[20:23], v33
	ds_read_b128 v[16:19], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v66
	ds_write_b16 v0, v67 offset:8
	ds_write_b16 v0, v68 offset:16
	ds_write_b16 v0, v69 offset:24
	ds_write_b16 v0, v70 offset:64
	ds_write_b16 v0, v71 offset:72
	ds_write_b16 v0, v72 offset:80
	ds_write_b16 v0, v73 offset:88
	ds_write_b16 v0, v74 offset:128
	ds_write_b16 v0, v75 offset:136
	ds_write_b16 v0, v76 offset:144
	ds_write_b16 v0, v77 offset:152
	ds_write_b16 v0, v78 offset:192
	ds_write_b16 v0, v79 offset:200
	ds_write_b16 v0, v80 offset:208
	ds_write_b16 v0, v82 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[12:15], v33
	ds_read_b128 v[8:11], v33 offset:4352
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_write_b16 v0, v83
	ds_write_b16 v0, v84 offset:8
	ds_write_b16 v0, v85 offset:16
	ds_write_b16 v0, v86 offset:24
	ds_write_b16 v0, v95 offset:64
	ds_write_b16 v0, v96 offset:72
	ds_write_b16 v0, v97 offset:80
	ds_write_b16 v0, v98 offset:88
	ds_write_b16 v0, v5 offset:128
	ds_write_b16 v0, v6 offset:136
	ds_write_b16 v0, v7 offset:144
	ds_write_b16 v0, v99 offset:152
	ds_write_b16 v0, v1 offset:192
	ds_write_b16 v0, v2 offset:200
	ds_write_b16 v0, v3 offset:208
	ds_write_b16 v0, v4 offset:216
	;;#ASMSTART
	s_waitcnt lgkmcnt(0) 
	s_barrier 
	;;#ASMEND
	ds_read_b128 v[4:7], v33
	ds_read_b128 v[0:3], v33 offset:4352
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_26
	v_ashrrev_i32_e32 v33, 31, v32
	v_lshlrev_b64 v[33:34], 1, v[32:33]
	v_mov_b32_e32 v35, s5
	v_add_co_u32_e64 v33, s[0:1], s4, v33
	v_addc_co_u32_e64 v34, s[0:1], v35, v34, s[0:1]
	s_waitcnt lgkmcnt(14)
	global_store_dwordx4 v[33:34], v[28:31], off
.LBB0_26:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(14)
	v_or_b32_e32 v29, s24, v88
	.loc	1 57 21
	s_lshl_b32 s6, s17, 4
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v29
	v_add_u32_e32 v28, s6, v32
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_28
	v_ashrrev_i32_e32 v29, 31, v28
	v_lshlrev_b64 v[29:30], 1, v[28:29]
	v_mov_b32_e32 v31, s5
	v_add_co_u32_e64 v29, s[0:1], s4, v29
	v_addc_co_u32_e64 v30, s[0:1], v31, v30, s[0:1]
	global_store_dwordx4 v[29:30], v[24:27], off
.LBB0_28:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v25, v87, s24, 32
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v25
	v_add_u32_e32 v24, s6, v28
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_30
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshlrev_b64 v[25:26], 1, v[24:25]
	v_mov_b32_e32 v27, s5
	v_add_co_u32_e64 v25, s[0:1], s4, v25
	v_addc_co_u32_e64 v26, s[0:1], v27, v26, s[0:1]
	global_store_dwordx4 v[25:26], v[20:23], off
.LBB0_30:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v21, v87, s24, 48
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v21
	v_add_u32_e32 v20, s6, v24
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_32
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[21:22], 1, v[20:21]
	v_mov_b32_e32 v23, s5
	v_add_co_u32_e64 v21, s[0:1], s4, v21
	v_addc_co_u32_e64 v22, s[0:1], v23, v22, s[0:1]
	global_store_dwordx4 v[21:22], v[16:19], off
.LBB0_32:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or3_b32 v17, v87, s24, 64
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v17
	v_add_u32_e32 v16, s6, v20
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_34
	v_ashrrev_i32_e32 v17, 31, v16
	v_lshlrev_b64 v[17:18], 1, v[16:17]
	v_mov_b32_e32 v19, s5
	v_add_co_u32_e64 v17, s[0:1], s4, v17
	v_addc_co_u32_e64 v18, s[0:1], v19, v18, s[0:1]
	global_store_dwordx4 v[17:18], v[12:15], off
.LBB0_34:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 46 is_stmt 1
	s_nop 0
	v_or_b32_e32 v14, s24, v87
	.loc	1 39 33 is_stmt 0
	v_or_b32_e32 v13, 0x50, v14
	.loc	1 58 33 is_stmt 1
	v_cmp_gt_i32_e64 s[0:1], s8, v13
	v_add_u32_e32 v12, s6, v16
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_36
	v_ashrrev_i32_e32 v13, 31, v12
	v_lshlrev_b64 v[15:16], 1, v[12:13]
	v_mov_b32_e32 v13, s5
	v_add_co_u32_e64 v15, s[0:1], s4, v15
	v_addc_co_u32_e64 v16, s[0:1], v13, v16, s[0:1]
	global_store_dwordx4 v[15:16], v[8:11], off
.LBB0_36:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_nop 0
	v_or_b32_e32 v9, 0x60, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v9
	v_add_u32_e32 v8, s6, v12
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_38
	v_ashrrev_i32_e32 v9, 31, v8
	v_lshlrev_b64 v[9:10], 1, v[8:9]
	v_mov_b32_e32 v11, s5
	v_add_co_u32_e64 v9, s[0:1], s4, v9
	v_addc_co_u32_e64 v10, s[0:1], v11, v10, s[0:1]
	s_waitcnt lgkmcnt(1)
	global_store_dwordx4 v[9:10], v[4:7], off
.LBB0_38:
	.loc	1 0 21 is_stmt 0
	s_or_b64 exec, exec, s[2:3]
	.loc	1 39 33 is_stmt 1
	s_waitcnt lgkmcnt(1)
	v_or_b32_e32 v4, 0x70, v14
	.loc	1 58 33
	v_cmp_gt_i32_e64 s[0:1], s8, v4
	.loc	1 58 39 is_stmt 0
	s_and_b64 s[0:1], vcc, s[0:1]
	.loc	1 59 21 is_stmt 1
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB0_40
	.loc	1 0 21 is_stmt 0
	v_add_u32_e32 v4, s6, v8
	.loc	1 59 21
	v_ashrrev_i32_e32 v5, 31, v4
	v_lshlrev_b64 v[4:5], 1, v[4:5]
	v_mov_b32_e32 v6, s5
	v_add_co_u32_e32 v4, vcc, s4, v4
	v_addc_co_u32_e32 v5, vcc, v6, v5, vcc
	s_waitcnt lgkmcnt(0)
	global_store_dwordx4 v[4:5], v[0:3], off
.LBB0_40:
	.loc	1 59 4
	s_endpgm
.Ltmp17:
	.section	.rodata,#alloc
	.p2align	6, 0x0
	.amdhsa_kernel gemm_kernel
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 48
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 160
		.amdhsa_next_free_sgpr 27
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	gemm_kernel, .Lfunc_end0-gemm_kernel
	.cfi_endproc

	.section	.debug_abbrev
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.ascii	"\211|"
	.byte	14
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	0
	.byte	0
	.byte	2
	.byte	46
	.byte	0
	.byte	3
	.byte	14
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	49
	.byte	19
	.byte	0
	.byte	0
	.byte	4
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.short	4
	.long	.debug_abbrev
	.byte	8
	.byte	1
	.long	.Linfo_string0
	.short	2
	.long	.Linfo_string1
	.long	.Lline_table_start0
	.long	.Linfo_string2
	.long	.Linfo_string3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.byte	2
	.long	.Linfo_string4
	.byte	1
	.byte	3
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.long	46
	.byte	4
	.long	46
	.long	.Ldebug_ranges0
	.byte	1
	.byte	31
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges1
	.byte	1
	.byte	30
	.byte	27
	.byte	4
	.long	46
	.long	.Ldebug_ranges2
	.byte	1
	.byte	47
	.byte	33
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.debug_ranges
.Ldebug_ranges0:
	.quad	.Lfunc_begin0-.Lfunc_begin0
	.quad	.Ltmp0-.Lfunc_begin0
	.quad	.Ltmp1-.Lfunc_begin0
	.quad	.Ltmp2-.Lfunc_begin0
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"triton"
.Linfo_string1:
	.asciz	"08_triton_gemm_mmac.py"
.Linfo_string2:
	.asciz	"experiments/advanced"
.Linfo_string3:
	.asciz	"[llvm:v0.0]"
.Linfo_string4:
	.asciz	"gemm_kernel"
	.section	".note.GNU-stack"
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .offset:         24
        .size:           4
        .value_kind:     by_value
      - .offset:         28
        .size:           4
        .value_kind:     by_value
      - .offset:         32
        .size:           4
        .value_kind:     by_value
      - .offset:         36
        .size:           4
        .value_kind:     by_value
      - .offset:         40
        .size:           4
        .value_kind:     by_value
      - .offset:         44
        .size:           4
        .value_kind:     by_value
    .fp64_status:    0
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 48
    .max_flat_workgroup_size: 256
    .name:           gemm_kernel
    .private_segment_fixed_size: 0
    .sgpr_count:     31
    .sgpr_spill_count: 0
    .symbol:         gemm_kernel.kd
    .vgpr_count:     160
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx936
amdhsa.version:
  - 1
  - 1
...

	.end_amdgpu_metadata
	.section	.debug_line
.Lline_table_start0:
